package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;
import cl.equifax.kpiservices.ifcwebadmin.entities.StructureRequest;

public interface StructureService {

	List<Structure> findAll();

	PageDetail findAll(String filter, Integer page, Integer size);

	StructureRequest create(StructureRequest request);

	StructureRequest edit(Integer id, StructureRequest request);

	StructureRequest updateIndexFile(Integer id, Integer fileId, String user);

	StructureRequest delete(Integer id, String user);

}