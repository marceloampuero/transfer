package cl.equifax.kpiservices.ifcwebadmin.models;

import java.util.List;

public class AccessResponse {

	private String estadoUsuario;
	private String codigoClienteUsuario;
	private String rutCliente;
	private Integer cantidadMaximaConexiones;
	private String indicadorCambioClave;
	private Integer diasRestantesCambioClave;
	private String tipoUsuario;
	private String mercadoPertenece;
	private Integer codigoEjecutivoAtiende;
	private Integer tipoContabilizacion;

	List<AccesoAplicacion> accesoPorAplicacions;

	public List<AccesoAplicacion> getAccesoPorAplicacions() {
		return accesoPorAplicacions;
	}

	public void setAccesoPorAplicacions(List<AccesoAplicacion> accesoPorAplicacions) {
		this.accesoPorAplicacions = accesoPorAplicacions;
	}

	public String getEstadoUsuario() {
		return estadoUsuario;
	}

	public void setEstadoUsuario(String estadoUsuario) {
		this.estadoUsuario = estadoUsuario;
	}

	public String getCodigoClienteUsuario() {
		return codigoClienteUsuario;
	}

	public void setCodigoClienteUsuario(String codigoClienteUsuario) {
		this.codigoClienteUsuario = codigoClienteUsuario;
	}

	public String getRutCliente() {
		return rutCliente;
	}

	public void setRutCliente(String rutCliente) {
		this.rutCliente = rutCliente;
	}

	public Integer getCantidadMaximaConexiones() {
		return cantidadMaximaConexiones;
	}

	public void setCantidadMaximaConexiones(Integer cantidadMaximaConexiones) {
		this.cantidadMaximaConexiones = cantidadMaximaConexiones;
	}

	public String getIndicadorCambioClave() {
		return indicadorCambioClave;
	}

	public void setIndicadorCambioClave(String indicadorCambioClave) {
		this.indicadorCambioClave = indicadorCambioClave;
	}

	public Integer getDiasRestantesCambioClave() {
		return diasRestantesCambioClave;
	}

	public void setDiasRestantesCambioClave(Integer diasRestantesCambioClave) {
		this.diasRestantesCambioClave = diasRestantesCambioClave;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getMercadoPertenece() {
		return mercadoPertenece;
	}

	public void setMercadoPertenece(String mercadoPertenece) {
		this.mercadoPertenece = mercadoPertenece;
	}

	public Integer getCodigoEjecutivoAtiende() {
		return codigoEjecutivoAtiende;
	}

	public void setCodigoEjecutivoAtiende(Integer codigoEjecutivoAtiende) {
		this.codigoEjecutivoAtiende = codigoEjecutivoAtiende;
	}

	public Integer getTipoContabilizacion() {
		return tipoContabilizacion;
	}

	public void setTipoContabilizacion(Integer tipoContabilizacion) {
		this.tipoContabilizacion = tipoContabilizacion;
	}

}
