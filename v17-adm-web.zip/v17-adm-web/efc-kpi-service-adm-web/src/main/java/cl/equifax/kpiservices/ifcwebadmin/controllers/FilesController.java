package cl.equifax.kpiservices.ifcwebadmin.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

import cl.equifax.kpiservices.ifcwebadmin.utils.EFXAuthUtils;

@Controller
@RequestMapping("/files")
public class FilesController {

	private static final String SERVICE_NAME = "BBE-KPI-SERVICES-INDEX-CONSUMER";

	private static final String FILES_PAGE = "files/files";
	private static final String ERROR_PAGE = "error/error";

	@Autowired
	private EurekaClient discoveryClient;

	@GetMapping
	public String render(Model model, Authentication authentication) {

		if (EFXAuthUtils.hasRole(authentication, "P03") && !EFXAuthUtils.hasRole(authentication, "P01")
				&& !EFXAuthUtils.hasRole(authentication, "P02")) {
			return ERROR_PAGE;
		}

		InstanceInfo instance = discoveryClient.getNextServerFromEureka(SERVICE_NAME, false);
		String kpiServiceUrl = instance.getHomePageUrl();

		model.addAttribute("kpiServiceUrl", kpiServiceUrl);

		model.addAttribute("userName", authentication.getName());
		model.addAttribute("userUserName", authentication.getName());

		return FILES_PAGE;
	}
}
