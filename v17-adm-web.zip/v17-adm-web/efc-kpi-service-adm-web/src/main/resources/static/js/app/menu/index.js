$(document).ready(function($){
	
	function MenusViewModel(){
		var self = this;
		
		self.url = '/api/users';
		self.user = ko.observable();
		self.password = ko.observable();
		
		 
	    self.init = async function (e, a) {
	    	let nameActive = window.location.pathname.split("/")[1];
	    	 $('list-group li').each(function(){
	    	        $(this).removeClass('active');     
    	    });
	    	$("#"+ nameActive).addClass('active');
	    	
	    	
	    }; 
		
	}
	
	var menuViewModel = new MenusViewModel();
	menuViewModel.init();
    ko.applyBindings(menuViewModel, $('.menu')[0]);
    
    window.menuViewModel = menuViewModel;
	
});