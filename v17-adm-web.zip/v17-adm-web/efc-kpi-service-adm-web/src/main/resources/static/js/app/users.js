$(document).ready(function($){
	
	window.baseUrl = location.href.substring(0,location.href.search('gmac-web-ic') + 11);
	
	$('input[type=file]').change(function () {
	    console.log(this.files[0].name);
	    viewModel.initFile(this.files[0]);
	    
	});
	
	toastr.options = {
	  "closeButton": false,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-bottom-full-width",
	  "preventDuplicates": false,
	  "onclick": null,
	  "showDuration": "300",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};
	
	ko.bindingHandlers.sort = {
		init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';
			
			element.onclick = function(){
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;
				
				
				
				bindingContext.$data.sortField(prop);
				asc = !asc;
				
				data.sort(function(left, right){
					var rec1 = left;
					var rec2 = right;
					
					if(!asc) {
						rec1 = right;
						rec2 = left;
					}
					
					var props = prop.split('.');
					for(var i in props){
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if(parenIndex > 0){
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}
					
					rec1 = rec1.toString();
					rec2 = rec2.toString();
					
					rec1 = parseInt(rec1.replace(/\./g,'').replace(/,/g,''),10);
					rec2 = parseInt(rec2.replace(/\./g,'').replace(/,/g,''),10);
					
					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
	        };
	    }
	};
	
	ko.bindingHandlers.executeOnEnter = {
		    init: function (element, valueAccessor, allBindings, viewModel) {

		        var bindings = allBindings();
		        $(element).keypress(function (event) {
		            var keyCode = (event.which ? event.which : event.keyCode);
		            if (keyCode === 13) {
		                bindings.executeOnEnter.call(viewModel, viewModel, element);
		                return false;
		            }
		            return true;
		        });
		    },
		    update: function () {}
	};
	
	

	ko.extenders.formatted = function(target, precision) {
	    //create a writable computed observable to intercept writes to our observable
	    var result = ko.pureComputed({
	        read: function () {
	        	
	        	if(!(target && target())){
	        		return '';
	        	}
	        	
	        	var newValue = target().toString();
	        	var val = parseInt(newValue.replace(/\./g,'').replace(/,/g,''));
	        	
	        	if (isNaN(val)){
	        		val = '';
	        	}
	        	
	        	var numberFormat = new Intl.NumberFormat();
	        	
	        	var nf = numberFormat.format(val);
	        	
	            return nf;
	        },  //always return the original observables value
	        write: target
	    }).extend({ notify: 'always' });
	 
	    //initialize with current value to make sure it is rounded appropriately
	    result(target());
	 
	    //return the new computed observable
	    return result;
	};
	
	var getHeaders = function () {
		
		return {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'X-Requested-With': 'XMLHttpRequest',
			'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
		};
	};
	
	function Pagination () {
		
		var self = this;
		
		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);
		
		self.hasNext = ko.pureComputed(function() {
		    return self.number() < self.totalPages();
		}, self);
		
		self.hasPrevious = ko.pureComputed(function() {
		    return self.number() > 1;
		}, self);
		
	
	}
	
	
	
	function Franchisee(){
		var self = this;
		
		self.id = ko.observable();
		self.code = ko.observable();
		self.name = ko.observable();
		
	}
	
	function FileEntity(){
		var self = this;
		
		self.name = '';
		self.lastModified = '';
		
		
	}
	
	
	function Entity(){
		var self = this;
		
		self.id = ko.observable();
		
		
		self.userName = ko.observable();
		self.name = ko.observable();
		  
		self.razonSocial = ko.observable();
		self.rutEmpresa = ko.observable();
		self.operacion = ko.observable();
		self.codigoCliente = ko.observable();
		self.tipoContrato = ko.observable();
		self.aportante = ko.observable();
		self.fechaActualizacion = ko.observable();
		self.nombre = ko.observable();
		self.paterno = ko.observable();
		 
		self.materno = ko.observable();
		self.rut = ko.observable();
		self.area = ko.observable();
		self.cargo = ko.observable();
		self.email = ko.observable();
		self.telefono = ko.observable();
		self.status = ko.observable();
		self.branch = ko.observable();
		self.role = ko.observable();
		
		
	}
	
	
	
	function ViewModel(){
		var self = this;
		
		self.url = '/api/users';
		
		self.pagination = ko.observable(new Pagination());
		//self.forms = ko.observable(new FormsView());
		
		self.list = ko.observableArray([]);
		
		self.franchiseeList = ko.observableArray([]);
		
		self.branchesList = ko.observableArray([]);
		self.roleList = ko.observableArray([]);
		
		self.importList = ko.observableArray([]);
		
		
		self.size = ko.observable(10);
		self.filter = ko.observable('');
		
		self.selectedFile = ko.observable(new FileEntity());
		
		//self.forms().current(new Entity());
		
		self.isCreateVisible = ko.observable(false);
		self.isEditVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		self.isImportVisible = ko.observable(false);
		
		self.current = ko.observable(new Entity());
		self.currentEdit = ko.observable(new Entity());
		
		self.showCreate = function () {
			self.current(new Entity());
			self.isCreateVisible(true);
			self.isEditVisible(false);
			self.isListVisible(false);
			self.isImportVisible(false);
			
			
		};
		
		self.showEdit = function (item) {
			
			self.currentEdit(item);
			
			self.isCreateVisible(false);
			self.isEditVisible(true);
			self.isListVisible(false);
			self.isImportVisible(false);
			
			
		};
		
		self.showList = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(true);
			self.isImportVisible(false);
			
			self.current(new Entity());
			
		};
		
		self.showImport = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(false);
			self.isImportVisible(true);
			self.selectedFile(new FileEntity());
			self.importList([]);
			
			self.current(new Entity());
			
		};
		
		
		
		self.init = async function() {
			await self.getBranches();
			await self.getRoles();
			self.getAll(0);
			
			
		};
		
		self.initFile = function (file){
			self.selectedFile(file);
			
			var csvFile = file;
			
			
			getAsText(csvFile);
			
		};
		
		var getAsText = function(csvFile){
			
			var reader = new FileReader();
		    // Read file into memory as UTF-8      
		    reader.readAsText(csvFile);
		    // Handle errors load
		    reader.onload = loadHandler;
		    reader.onerror = errorHandler;
			
		};
		
		var loadHandler = function loadHandler(event) {
	      var csv = event.target.result;
	      var lines = processData(csv);
	      
	      var iList = [];
	      for (var i=0; i<lines.length; i++) {
	    	  
	    	  	if (i == 0){
	    	  		continue;
	    	  	}
	    	  	
	    	  	var line = lines[i];
	    	  	
	    	  	if (line.length < 10){
	    	  		continue;
	    	  	}
	    	  	
	    	  	let obj = new Entity();
				  
		    obj.userName(line[0]);
		    obj.role(line[1]);
		    obj.nombre(line[2]);
		    obj.paterno(line[3]);
		    obj.materno(line[4]);
		    obj.email(line[5]);
		    obj.area(line[6]);
		    obj.cargo(line[7]);
		    obj.branch(line[8]);
		    obj.telefono(line[9]);
		   			  
		    iList.push(obj);
	    	  	
	      }
	      
	      self.importList(iList);
	      
	      
	      
	    }

		var processData = function processData(csv) {
	        var allTextLines = csv.split(/\r\n|\n/);
	        
	        
	        var lines = [];
	        for (var i=0; i<allTextLines.length; i++) {
	            var data = allTextLines[i].split(',');
	                var tarr = [];
	                for (var j=0; j<data.length; j++) {
	                    tarr.push(data[j]);
	                }
	                lines.push(tarr);
	        }
	        
	        
	      return lines;
	    }

		 var errorHandler = function errorHandler(evt) {
	      if(evt.target.error.name == "NotReadableError") {
	          console.log("Can't read file !");
	      }
	    }

		
		self.showFileSelection = function(){
			
			document.getElementById('input-file-selected').click();
			
		};
		
		
		self.searchFilter = function() {
			
			self.getAll(0);
		};
		
		self.updateList = function(){
			self.getAll(self.pagination().number()-1)
		};
		
		
		self.getAll = async function(page) {
			
			var requestUrl = baseUrl + self.url + `?page=${page}&size=${self.size()}&filter=${self.filter()}`;
			
			self.list([]);
		    
		    let req = {
				method: 'GET',
				headers: getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
		    
		    try {
		    	const res =  await fetch(requestUrl, req);
			    const data = await res.json();
			    
			    let page = new Pagination();
			    page.size(data.size);
			    page.number(data.number + 1);
			    page.numberOfElements(data.numberOfElements);
			    page.totalPages(data.totalPages);
			    page.totalElements(data.totalElements);
			    page.first(data.first);
			    page.last(data.last);
			  
			    self.pagination(page);
			    
			    let contents = [];
				  
				  data.content.forEach(element => {
					  if (element.role.id === 7) {
						  return;
					  }
					  
					  let obj = new Entity();
					  
					  obj.id(element.id);
					  obj.userName(element.userName);
					  obj.name(element.name);
					  
					  obj.razonSocial(element.razonSocial);
					  obj.rutEmpresa(element.rutEmpresa);
					  obj.operacion(element.operacion);
					  obj.codigoCliente(element.codigoCliente);
					  obj.tipoContrato(element.tipoContrato);
					  obj.aportante(element.aportante);
					  obj.fechaActualizacion(element.fechaActualizacion);
					  obj.nombre(element.nombre);
					  obj.paterno(element.paterno);
					 
					  obj.materno(element.materno);
					  obj.rut(element.rut);
					  obj.area(element.area);
					  obj.cargo(element.cargo);
					  obj.email(element.email);
					  obj.telefono(element.telefono);
					  obj.status(element.status);
					  
					  obj.branch(self.findBranch(element.branch.id));
					  obj.role(self.findRole(element.role.id));
					  			  
					  contents.push(obj);
					  
				  });
				  
				  self.list(contents);
			    
		    }catch (e){
		    	console.error(e);
		    }
		    
		    	
		};
		
		self.findBranch = function(id){
			var brList = self.branchesList();
			var result = brList.find(x => x.id == id);
				
			return result;
			
		}
		
		self.findRole = function(id){
			var rrList = self.roleList();
			var result = rrList.find(x => x.id == id);
				
			return result;
			
		}
		
		self.getBranches = async function(page) {
			
			var requestUrl = baseUrl + '/api/branches/all';
			
			self.franchiseeList([]);
		    
		    let req = {
				method: 'GET',
				headers: getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
		    
		    try {
		    	const res =  await fetch(requestUrl, req);
			    const data = await res.json();
			    
			    self.branchesList(data);
			    
			    
		    }catch (e){
		    	console.error(e);
		    }
		    
		    	
		};
		
		self.getRoles = async function(page) {
			
			var requestUrl = baseUrl + '/api/roles/all';
			
			self.franchiseeList([]);
		    
		    let req = {
				method: 'GET',
				headers: getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
		    
		    try {
		    	const res =  await fetch(requestUrl, req);
			    const data = await res.json();
			    
			    self.roleList(data);
			    
			    
		    }catch (e){
		    	console.error(e);
		    }
		    
		    	
		};
		
		self.next = function () {
			
			if (self.pagination().last()){
				return;
			}
			
			if (self.pagination().number() < self.pagination().totalPages()){
				self.getAll(self.pagination().number());
			}
			
		};
		
		self.previous = function () {
			
			if (self.pagination().first()){
				return;
			}
			
			self.getAll(self.pagination().number()-2);
			
		};
		
		self.enableSave = ko.pureComputed(function() {
			return self.current().userName() 
				&& self.current().role() 
				&& self.current().branch() 
				&& self.current().nombre() 
				&& self.current().paterno();
		}, self);
		 
		self.enableUpdate = ko.pureComputed(function() {
			return self.currentEdit().userName() 
			&& self.currentEdit().role() 
			&& self.currentEdit().branch() 
			&& self.currentEdit().nombre() 
			&& self.currentEdit().paterno();
		}, self);
		
		self.enableImport = ko.pureComputed(function() {
			return self.importList().length > 0;
		}, self);
		
		
		
		self.save = async function(){
			
			var requestUrl = baseUrl + self.url;
			
			var body = ko.toJSON(self.current);
			
			var req = {
				method: 'POST',
				headers: getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al Guardar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Creación Exitosa');
		      self.current(new Entity());
		      
		      self.getAll(0);
		      self.showList();
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al Guardar');

		    }
			
			
		}
		
		
		self.saveImport = async function(){
			
			var requestUrl = baseUrl + self.url + '/import';
			
			var body = ko.toJSON(self.importList);
			
			var req = {
				method: 'POST',
				headers: getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al importar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Importación Exitosa');
		      self.current(new Entity());
		      
		      self.getAll(0);
		      self.showList();
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al Guardar');

		    }
			
			
		}
		
		self.update = async function(){
			
			var requestUrl = baseUrl + self.url + '/' + self.currentEdit().id();
			
			var body = ko.toJSON(self.currentEdit);
			
			var req = {
				method: 'PUT',
				headers: getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al Actualizar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Actualización Exitosa');
		      self.current(new Entity());
		      
		      self.getAll(0);
		      self.showList();
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al Actualizar');

		    }
			
			
		}
		
		self.deleteEntity = async function (element) {
			var requestUrl = baseUrl + self.url + '/' + element.id();
			
			var req = {
				method: 'DELETE',
				headers: getHeaders(),	
				cache: 'default',
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al eliminar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Eliminación Exitosa');
		      
		      self.getAll(0);
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al eliminar');

		    }
		};
		
		self.remove = async function (element) {
			
			bootbox.confirm({
			    message: "¿Está seguro que desea eliminar el usuario seleccionado?",
			    buttons: {
			        confirm: {
			            label: 'Sí',
			            className: 'btn-success'
			        },
			        cancel: {
			            label: 'No',
			            className: 'btn-danger'
			        }
			    },
			    callback: function (result) {
			        if (result){
			        	self.deleteEntity(element);
			        }
			    }
			});
			
			
		};
		
		
	}
	
	var viewModel = new ViewModel();
	
	viewModel.init();
	
    ko.applyBindings(viewModel, $('.Users')[0]);
    
    window.viewModel = viewModel;
	
	
});