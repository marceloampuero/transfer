package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndexRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;

@Service
@FeignClient(name = "kpiFilesIndexService", url = "${kpi.services.kpiurl}" + "/v1/filesindex")
public interface FilesIndexService {

	@GetMapping("/all")
	List<FilesIndex> findAll();

	@GetMapping
	@ResponseBody
	PageDetail findPaginated(@RequestParam(name = "filter", required = false) String filter,
			@RequestParam(name = "kpi", required = false) String kpi,
			@RequestParam(name = "page", defaultValue = "0", required = false) Integer page,
			@RequestParam(name = "size", defaultValue = "10", required = false) Integer size);

	@GetMapping("/{kpi}")
	List<FilesIndex> findByKpi(@PathVariable(value = "kpi") String kpi);

	@PostMapping
	@ResponseBody
	FilesIndex create(@RequestBody FilesIndexRequest filesIndex);

	@DeleteMapping("/{id}")
	void delete(@PathVariable(value = "id") Integer id);

}
