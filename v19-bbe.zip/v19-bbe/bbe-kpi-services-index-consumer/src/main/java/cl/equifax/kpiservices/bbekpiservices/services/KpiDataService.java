package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;

import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;
import cl.equifax.kpiservices.bbekpiservices.entities.UploadResult;

public interface KpiDataService {

	KpiResponse getKpiByRut(String rut, String kpi);

	KpiResponse getKpiByRut(KpiRequest request);

	KpiResponse getKpisByRut(String rut, List<String> kpis);

	UploadResult addKpiFile(String kpi, String filePath);

	UploadResult addKpiFile(String kpi, String user, String filePath);

}
