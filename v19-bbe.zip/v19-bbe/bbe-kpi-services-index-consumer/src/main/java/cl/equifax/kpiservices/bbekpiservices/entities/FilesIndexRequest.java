package cl.equifax.kpiservices.bbekpiservices.entities;

import java.util.Calendar;
import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

public class FilesIndexRequest {

	private Integer id;
	private static final String FILE_PATTERN = "^[A-Za-z0-9_.\\/;\\ -]*$";
	private static final String CREATEDBY_PATTERN = "^[A-Za-z0-9_; ]*$";

	@Pattern(regexp = FILE_PATTERN)
	private String filePath;

	@Pattern(regexp = FILE_PATTERN)
	private String indexPath;

	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss", timezone = "GMT-4")
	private Date createdAt = Calendar.getInstance().getTime();

	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss", timezone = "GMT-4")
	private Date modifiedAt = Calendar.getInstance().getTime();

	@Pattern(regexp = CREATEDBY_PATTERN)
	private String createdBy;

	@Pattern(regexp = CREATEDBY_PATTERN)
	private String modifiedBy;

	@Valid
	private Structure structure;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getIndexPath() {
		return indexPath;
	}

	public void setIndexPath(String indexPath) {
		this.indexPath = indexPath;
	}

	public Structure getStructure() {
		return structure;
	}

	public void setStructure(Structure structure) {
		this.structure = structure;
	}

	@Override
	public String toString() {
		return "FilesIndex [id=" + id + ", filePath=" + filePath + ", indexPath=" + indexPath + ", createdAt="
				+ createdAt + ", modifiedAt=" + modifiedAt + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
				+ ", structure=" + structure + "]";
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public FilesIndex toFilesIndex() {
		FilesIndex f = new FilesIndex();

		f.setId(this.getId());
		f.setCreatedAt(this.getCreatedAt());
		f.setCreatedBy(this.createdBy);
		f.setFilePath(this.getFilePath());
		f.setIndexPath(this.getIndexPath());
		f.setModifiedAt(this.getModifiedAt());
		f.setModifiedBy(this.getModifiedBy());
		f.setStructure(this.getStructure());

		return f;

	}
}
