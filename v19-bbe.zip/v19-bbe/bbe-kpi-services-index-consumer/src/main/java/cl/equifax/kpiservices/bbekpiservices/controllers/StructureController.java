package cl.equifax.kpiservices.bbekpiservices.controllers;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.entities.StructureRequest;
import cl.equifax.kpiservices.bbekpiservices.services.StructureService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1 + "/structure")
public class StructureController {

	private StructureService service;

	@Autowired
	public StructureController(StructureService service) {

		this.service = service;
	}

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@ApiOperation(value = "Obtiene la lista paginada filtradas por kpi de estructuras de KPIs")
	@GetMapping
	@ResponseBody
	public PageDetail home(@RequestParam(required = false) String filter,
			@RequestParam(defaultValue = "0", required = false) Integer page,
			@RequestParam(defaultValue = "10", required = false) Integer size) {

		return this.service.findPaginated(filter, page, size);

	}

	@ApiOperation(value = "Obtiene la lista actualizada de estructuras de KPIs")
	@GetMapping("/all")
	@ResponseBody
	public List<StructureRequest> getAll() {

		return this.service.findAll();
	}

	@ApiOperation(value = "Obtiene una estructura de kpi por Id ")
	@GetMapping("/{id}")
	@ResponseBody
	public Optional<StructureRequest> getById(@PathVariable(value = "id") Integer id) {

		return this.service.findById(id);
	}

	@ApiOperation(value = "Actualiza una estructura")
	@PutMapping("/{id}")
	@ResponseBody
	public ResponseEntity<StructureRequest> update(@PathVariable(value = "id") Integer id,
			@RequestBody StructureRequest structure) {

		StructureRequest savedStructure = this.service.update(id, structure);

		return new ResponseEntity<>(savedStructure, HttpStatus.OK);

	}

	@ApiOperation(value = "Cambia el archivo de índices de una estructura")
	@PutMapping("/{id}/{fileId}")
	@ResponseBody
	public StructureRequest updateIndexFile(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId,
			@RequestParam(name = "user", required = true, defaultValue = "") String user) {

		return this.service.changeFileIndex(id, fileId, user);

	}

	@ApiOperation(value = "Crea una estructura para un KPI")
	@PostMapping
	@ResponseBody
	public ResponseEntity<StructureRequest> create(@Valid @RequestBody StructureRequest structure) {

		StructureRequest savedStructure = service.create(structure);

		return new ResponseEntity<>(savedStructure, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Elimina una estructura de KPI")
	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<?> delete(@PathVariable(value = "id") Integer id,
			@RequestParam(name = "user", required = true, defaultValue = "") String user) {

		this.service.delete(id, user);

		return new ResponseEntity<>(HttpStatus.OK);

	}

}
