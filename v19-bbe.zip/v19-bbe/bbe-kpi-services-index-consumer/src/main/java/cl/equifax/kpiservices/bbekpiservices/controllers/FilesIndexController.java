package cl.equifax.kpiservices.bbekpiservices.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndexRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.services.FilesIndexService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1 + "/filesindex")
public class FilesIndexController {

	private FilesIndexService service;

	@Autowired
	public FilesIndexController(FilesIndexService service) {
		this.service = service;
	}

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@ApiOperation(value = "Obtiene la lista paginada filtradas de archivos")
	@GetMapping
	@ResponseBody
	public PageDetail paginated(@RequestParam(required = false) String filter,
			@RequestParam(required = false) String kpi,
			@RequestParam(defaultValue = "0", required = false) Integer page,
			@RequestParam(defaultValue = "10", required = false) Integer size) {

		return this.service.findPaginated(filter, kpi, page, size);

	}

	@ApiOperation(value = "Obtiene la lista actualizada de archivos e índices")
	@GetMapping("/all")
	@ResponseBody
	public List<FilesIndex> getAll() {
		return this.service.findAll();
	}

	@ApiOperation(value = "Obtiene la lista de archivos e índices de un kpi")
	@GetMapping("/{kpi}")
	@ResponseBody
	public List<FilesIndex> getByKpi(@PathVariable(value = "kpi") String kpi) {
		return this.service.findByKpi(kpi);
	}

	@ApiOperation(value = "Almacena los datos de archivo e índice para un unasubida de archivo determinada")
	@PostMapping
	@ResponseBody
	public ResponseEntity<FilesIndex> create(@Valid @RequestBody FilesIndexRequest filesIndex) {

		FilesIndex savedFileIndex = service.create(filesIndex);

		return new ResponseEntity<>(savedFileIndex, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Elimina un dato de archivo e índice.  Al eliminar ya no se puede utilizar el índice.")
	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<?> delete(@PathVariable(value = "id") Integer id) {

		this.service.delete(id);

		return new ResponseEntity<>(HttpStatus.OK);

	}

	//
	// @ApiOperation
	// (value="Elimina un dato de archivo e índice. Al eliminar ya nose puede
	// utilizar el índice.")
	//
	// @DeleteMapping("/{id}")
	// public @ResponseBody ResponseEntity<?> delete(@PathVariable(value = "id")
	// Integer id) {
	//
	// this.service.delete(id);
	//
	// return new ResponseEntity<>(HttpStatus.OK);
	//
	// }

}
