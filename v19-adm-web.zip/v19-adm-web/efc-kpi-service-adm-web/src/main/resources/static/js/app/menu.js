$(document).ready(function($){
	
	window.baseUrl = location.href.substring(0,location.href.search('gmac-web-ic') + 11);
	
	
	function MenuViewModel(){
		var self = this;
		
		const bmOff = 'position: fixed; z-index: 20000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 0; transform: translate3d(100%, 0px, 0px); transition: opacity 0.3s, transform 0s 0.3s;';
		const bmOn  = 'position: fixed; z-index: 20000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 1; transition: opacity 0.3s;';
		
		const mnOff = 'position: fixed; right: 0px; z-index: 20000; width: 260px; height: 100%; transition: all 0.5s; top: 51px; transform: translate3d(100%, 0px, 0px);';
		const mnOn  = 'position: fixed; right: 0px; z-index: 20000; width: 260px; height: 100%; transition: all 0.5s; top: 51px;';
		
		
		self.overlayStyle = ko.observable(bmOff);
		self.menuWrapStyle = ko.observable(mnOff);
		
		self.currentUser = ko.observable();
		self.nombre = ko.observable();
		self.apellido = ko.observable();
		
		
		self.getHeaders = function () {
			
			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};
		
	    self.toggleMenu = function () {
	    	
	    	if (self.overlayStyle() === bmOff){
	    		self.overlayStyle(bmOn);
	    		self.menuWrapStyle(mnOn);
	    	}else{
	    		self.overlayStyle(bmOff);
	    		self.menuWrapStyle(mnOff);
	    	}
	    	
	    };
	    
	    self.init = function (){
	    	self.getUser();
	    }
	    
	    self.getUser = async function () {
	    	
			let req = {
				method: 'GET',
				headers: self.getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
			
			 try {
		      let result = await fetch(baseUrl + '/api/users/current', req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  console.error('Ocurrió un error al obtener informacion del usuario:', error);
		    	  
		    	  return;
		    	  
		      }
		      
		      self.nombre(model.nombre);
		      self.apellido(model.paterno);
		      
		     //self.currentUser(model);
		      		     
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		     
		    }
			
	    	
	    	
	    }; 
		
	}
	
	var menuViewModel = new MenuViewModel();
	menuViewModel.init();
	window.mnuViewModel = menuViewModel;
	
    ko.applyBindings(menuViewModel, $('#sideMenu')[0]);
    
    
   
    
    
	
});