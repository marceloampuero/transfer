"use strict";

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	function ViewModel() {
		var self = this;

		self.registerUrl = '/api/register';

		self.couuid = ko.observable(window.couuid);
		self.selection = ko.observable(window.selection);

		self.rut = ko.observable(window.rut);
		self.name = ko.observable(window.name);
		self.email = ko.observable(window.email === 'null' ? '' : window.email);
		self.phone = ko.observable(window.phone);
		self.status = ko.observable(window.status);
		self.model = ko.observable(window.model);
		self.modelPrice = ko.observable(window.modelPrice).extend({ formatted: 1 });
		self.pie = ko.observable(window.pie).extend({ formatted: 1 });
		self.plazo = ko.observable(window.plazo).extend({ formatted: 1 });
		self.cuota = ko.observable(window.cuota).extend({ formatted: 1 });

		self.isAdvanced = ko.observable(window.isAdvanced);
		self.isSales = ko.observable(window.isSales);

		self.fechaNacimiento = ko.observable(window.fechaNacimiento);
		self.genero = ko.observable(window.genero);
		self.tasa = ko.observable(window.tasa);
		self.scoreGmac = ko.observable(window.scoreGmac);
		self.scoreEfx = ko.observable(window.scoreEfx);
		self.scoreTUCurrent = ko.observable(window.scoreTUCurrent);
		self.scoreTU13meses = ko.observable(window.scoreTU13meses);
		self.ingreso = ko.observable(window.ingreso).extend({ formatted: 1 });

		self.reglasGatilladas = ko.observable(window.reglasGatilladas);
		self.cuotaMax = ko.observable(window.cuotaMax).extend({ formatted: 1 });

		self.back = function () {
			window.history.back();
		};

		self.getHeaders = function () {

			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};

		self.sendToFLink = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
			var registration, body, req, url, result, json;
			return regeneratorRuntime.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							registration = {
								couuid: self.couuid(),
								financeIndex: self.selection()
							};
							body = JSON.stringify(registration);
							req = {
								method: 'POST',
								headers: self.getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context.prev = 3;
							url = baseUrl + '/api/registration/finished';
							_context.next = 7;
							return fetch(url, req);

						case 7:
							result = _context.sent;
							_context.next = 10;
							return result.json();

						case 10:
							json = _context.sent;

							if (!(json.clientOrchestrationStatus !== 'selected')) {
								_context.next = 14;
								break;
							}

							toastr.error("Ocurrió un error al Guardar");
							return _context.abrupt("return");

						case 14:

							toastr.success("Perfilamiento Exitoso");

							window.location = baseUrl + "/idpreevaluationsuccess";

							_context.next = 22;
							break;

						case 18:
							_context.prev = 18;
							_context.t0 = _context["catch"](3);

							console.error('Error en request:', _context.t0);
							toastr.error("Ocurrió un error al Guardar en F&I Link");

						case 22:
						case "end":
							return _context.stop();
					}
				}
			}, _callee, this, [[3, 18]]);
		}));

		self.convertToNumber = function (value) {
			return value.replace(/\./g, '').replace(/,/g, '');
		};

		self.selectRegistration = function (data, id) {

			var params = '?';
			params += 'register=' + self.registrationId();
			params += '&finance=' + data.id;

			console.log(params);
			window.location = baseUrl + '/idpreevaluation' + params;
		};
	}

	var viewModel = new ViewModel();

	ko.applyBindings(viewModel, $('.IdPreEvaluation')[0]);

	window.viewModel = viewModel;
});