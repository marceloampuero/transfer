package cl.equifax.kpiservices.ifcwebadmin.entities;

import java.util.List;

public class PageDetail {

	private List<?> content;
	private Integer total;
	private Integer size;
	private Integer totalPages;
	private Integer numberOfElement;
	private Integer number;
	private Long totalElements;
	private Boolean isFirst;
	private Boolean isLast;
	private PageableDetail pageable;

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Integer getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public Long getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(Long totalElements) {
		this.totalElements = totalElements;
	}

	public Integer getNumberOfElement() {
		return numberOfElement;
	}

	public void setNumberOfElement(Integer numberOfElement) {
		this.numberOfElement = numberOfElement;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Boolean getIsFirst() {
		return isFirst;
	}

	public void setIsFirst(Boolean isFirst) {
		this.isFirst = isFirst;
	}

	public Boolean getIsLast() {
		return isLast;
	}

	public void setIsLast(Boolean isLast) {
		this.isLast = isLast;
	}

	public List<?> getContent() {
		return content;
	}

	public void setContent(List<?> content) {
		this.content = content;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public PageableDetail getPageable() {
		return pageable;
	}

	public void setPageable(PageableDetail pageable) {
		this.pageable = pageable;
	}

	@Override
	public String toString() {
		return "PageDetail [content=" + content + ", total=" + total + ", size=" + size + ", totalPages=" + totalPages
				+ ", totalElements=" + totalElements + ", numberOfElement=" + numberOfElement + ", number=" + number
				+ ", isFirst=" + isFirst + ", isLast=" + isLast + ", pageable=" + pageable + "]";
	}

}
