package cl.equifax.kpiservices.ifcwebadmin.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import cl.equifax.kpiservices.ifcwebadmin.utils.EFXAuthUtils;

@Controller
@RequestMapping("/structures")
public class Structures {

	private static final String STRUCTURE_PAGE = "structures/structures";
	private static final String ERROR_PAGE = "error/error";

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@GetMapping
	public String render(Model model, Authentication authentication) {

		return EFXAuthUtils.hasRole(authentication, "P03") ? STRUCTURE_PAGE : ERROR_PAGE;
	}
}
