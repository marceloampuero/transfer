package cl.equifax.kpiservices.ifcwebadmin.security;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Component;

import cl.equifax.kpiservices.ifcwebadmin.models.AccesoAplicacion;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessQuery;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessResponse;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessSecurity;
import cl.equifax.kpiservices.ifcwebadmin.services.AuthenticationService;

@Component
public class EFXAccessValidatorProvider implements AuthenticationProvider {

	@Autowired
	private AuthenticationService authenticationService;

	private static final String APPLICATION_NAME = "KPISERV";

	private static final Logger LOGGER = LoggerFactory.getLogger(EFXAccessValidatorProvider.class);

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String username = authentication.getName();
		String phrase = authentication.getCredentials().toString();

		if (username.compareTo("") == 0) {
			LOGGER.error("Bad Credentials.");
			throw new BadCredentialsException("Bad Credentials.");
		}

		if (phrase.compareTo("") == 0) {
			LOGGER.error("Bad Credentials.");
			throw new BadCredentialsException("Bad Credentials.");
		}

		AccessRequest request = new AccessRequest();

		List<AccessQuery> querys = new ArrayList<>();

		AccessQuery accessQuery = new AccessQuery();

		accessQuery.setAplicacion(APPLICATION_NAME);

		querys.add(accessQuery);

		request.setQuerys(querys);

		AccessSecurity security = new AccessSecurity();

		security.setUsername(username);
		security.setPhrase(phrase);
		request.setSecurity(security);

		AccessResponse response;
		try {
			response = this.authenticationService.autenticate(request);
		} catch (Exception e) {
			throw new BadCredentialsException("Bad Credentials.");
		}

		if (response == null) {
			LOGGER.error("Bad Credentials.");
			throw new BadCredentialsException("Bad Credentials.");
		}

		List<AccesoAplicacion> listaAccesos = response.getAccesoPorAplicacions();

		if (listaAccesos == null || listaAccesos.isEmpty()) {
			LOGGER.error("Bad Credentials. User doesn't have access");
			throw new BadCredentialsException("Bad Credentials. User doesn't have access");
		}

		AccesoAplicacion acceso = listaAccesos.get(0);

		String accesoAplicacion = acceso.getAccesosPorAplicacion();

		String roles = "";

		if (accesoAplicacion.charAt(0) == 'S') {
			roles += "P01";
		}

		if (accesoAplicacion.charAt(1) == 'S') {
			roles += ",P02";
		}

		if (accesoAplicacion.charAt(2) == 'S') {
			roles += ",P03";
		}

		if (roles.startsWith(",")) {
			roles = roles.substring(1);
		}

		if (roles.isEmpty()) {
			throw new BadCredentialsException("Bad Credentials. User don't have a role");
		}

		return new UsernamePasswordAuthenticationToken(username, phrase,
				AuthorityUtils.commaSeparatedStringToAuthorityList(roles));

	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
