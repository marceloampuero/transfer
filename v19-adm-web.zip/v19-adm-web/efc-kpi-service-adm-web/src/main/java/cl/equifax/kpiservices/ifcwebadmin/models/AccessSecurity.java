package cl.equifax.kpiservices.ifcwebadmin.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccessSecurity {

	private String username;

	@JsonProperty("password")
	private String phrase;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPhrase() {
		return phrase;
	}

	public void setPhrase(String phrase) {
		this.phrase = phrase;
	}

}
