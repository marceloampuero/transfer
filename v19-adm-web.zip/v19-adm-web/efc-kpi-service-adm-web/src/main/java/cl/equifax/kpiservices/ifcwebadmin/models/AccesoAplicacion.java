package cl.equifax.kpiservices.ifcwebadmin.models;

public class AccesoAplicacion {

	private String aplicacionConsultada;
	private String accesosPorAplicacion;
	private String accesosDeConsulta;
	private String accesosDeIngreso;
	private String accesosDeModificacion;
	private String accesosDeEliminacion;

	public String getAplicacionConsultada() {
		return aplicacionConsultada;
	}

	public void setAplicacionConsultada(String aplicacionConsultada) {
		this.aplicacionConsultada = aplicacionConsultada;
	}

	public String getAccesosPorAplicacion() {
		return accesosPorAplicacion;
	}

	public void setAccesosPorAplicacion(String accesosPorAplicacion) {
		this.accesosPorAplicacion = accesosPorAplicacion;
	}

	public String getAccesosDeConsulta() {
		return accesosDeConsulta;
	}

	public void setAccesosDeConsulta(String accesosDeConsulta) {
		this.accesosDeConsulta = accesosDeConsulta;
	}

	public String getAccesosDeIngreso() {
		return accesosDeIngreso;
	}

	public void setAccesosDeIngreso(String accesosDeIngreso) {
		this.accesosDeIngreso = accesosDeIngreso;
	}

	public String getAccesosDeModificacion() {
		return accesosDeModificacion;
	}

	public void setAccesosDeModificacion(String accesosDeModificacion) {
		this.accesosDeModificacion = accesosDeModificacion;
	}

	public String getAccesosDeEliminacion() {
		return accesosDeEliminacion;
	}

	public void setAccesosDeEliminacion(String accesosDeEliminacion) {
		this.accesosDeEliminacion = accesosDeEliminacion;
	}

}
