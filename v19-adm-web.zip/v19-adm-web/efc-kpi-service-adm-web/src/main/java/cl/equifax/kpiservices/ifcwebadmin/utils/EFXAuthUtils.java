package cl.equifax.kpiservices.ifcwebadmin.utils;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

public class EFXAuthUtils {

	private EFXAuthUtils() {

	}

	public static boolean hasRole(Authentication authentication, String role) {
		boolean result = false;

		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

		for (GrantedAuthority grantedAuthority : authorities) {
			if (grantedAuthority.getAuthority().equals(role)) {
				result = true;
				break;
			}
		}

		return result;
	}

}