"use strict";

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.sort = {
		init: function init(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';

			element.onclick = function () {
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;

				bindingContext.$data.sortField(prop);
				asc = !asc;

				data.sort(function (left, right) {
					var rec1 = left;
					var rec2 = right;

					if (!asc) {
						rec1 = right;
						rec2 = left;
					}

					var props = prop.split('.');
					for (var i in props) {
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if (parenIndex > 0) {
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}

					rec1 = rec1.toString();
					rec2 = rec2.toString();

					rec1 = parseInt(rec1.replace(/\./g, '').replace(/,/g, ''), 10);
					rec2 = parseInt(rec2.replace(/\./g, '').replace(/,/g, ''), 10);

					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
			};
		}
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	var getHeaders = function getHeaders() {

		return {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'X-Requested-With': 'XMLHttpRequest',
			'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
		};
	};

	function Pagination() {

		var self = this;

		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);

		self.hasNext = ko.pureComputed(function () {
			return self.number() < self.totalPages();
		}, self);

		self.hasPrevious = ko.pureComputed(function () {
			return self.number() > 1;
		}, self);
	}

	function FormsView() {
		var self = this;

		self.isCreateVisible = ko.observable(false);
		self.isEditVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		self.current = ko.observable();

		self.showCreate = function () {
			self.current(new Entity());
			self.isCreateVisible(true);
			self.isEditVisible(false);
			self.isListVisible(false);
		};

		self.showEdit = function (item) {
			self.current(item);
			self.isCreateVisible(false);
			self.isEditVisible(true);
			self.isListVisible(false);
		};

		self.showList = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(true);

			self.current(new Entity());
		};
	}

	function Entity() {
		var self = this;

		self.id = ko.observable();
		self.code = ko.observable();
		self.name = ko.observable();
		self.dependency = ko.observable();
	}

	function ViewModel() {
		var self = this;

		self.url = '/api/employmentType';

		self.pagination = ko.observable(new Pagination());
		self.forms = ko.observable(new FormsView());

		self.list = ko.observableArray([]);

		self.size = ko.observable(10);
		self.filter = ko.observable('');

		self.forms().current(new Entity());

		self.init = function () {
			self.getAll(0);
		};

		self.searchFilter = function () {

			self.getAll(0);
		};

		self.updateList = function () {
			self.getAll(self.pagination().number() - 1);
		};

		self.getAll = function () {
			var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(page) {
				var requestUrl, req, res, data, _page, contents;

				return regeneratorRuntime.wrap(function _callee$(_context) {
					while (1) {
						switch (_context.prev = _context.next) {
							case 0:
								requestUrl = baseUrl + self.url + ("?page=" + page + "&size=" + self.size() + "&filter=" + self.filter());


								self.list([]);

								req = {
									method: 'GET',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context.prev = 3;
								_context.next = 6;
								return fetch(requestUrl, req);

							case 6:
								res = _context.sent;
								_context.next = 9;
								return res.json();

							case 9:
								data = _context.sent;
								_page = new Pagination();

								_page.size(data.size);
								_page.number(data.number + 1);
								_page.numberOfElements(data.numberOfElements);
								_page.totalPages(data.totalPages);
								_page.totalElements(data.totalElements);
								_page.first(data.first);
								_page.last(data.last);

								self.pagination(_page);

								contents = [];


								data.content.forEach(function (element) {
									var obj = new Entity();

									obj.id(element.id);
									obj.code(element.code);
									obj.name(element.name);
									obj.dependency(element.dependency);

									contents.push(obj);
								});

								self.list(contents);

								_context.next = 27;
								break;

							case 24:
								_context.prev = 24;
								_context.t0 = _context["catch"](3);

								console.error(_context.t0);

							case 27:
							case "end":
								return _context.stop();
						}
					}
				}, _callee, this, [[3, 24]]);
			}));

			return function (_x) {
				return _ref.apply(this, arguments);
			};
		}();

		self.next = function () {

			if (self.pagination().last()) {
				return;
			}

			if (self.pagination().number() < self.pagination().totalPages()) {
				self.getAll(self.pagination().number());
			}
		};

		self.previous = function () {

			if (self.pagination().first()) {
				return;
			}

			self.getAll(self.pagination().number() - 2);
		};

		self.enableSave = ko.pureComputed(function () {
			return self.forms().current().code() && self.forms().current().name();
		}, self);

		self.save = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
			var requestUrl, body, req, result, model;
			return regeneratorRuntime.wrap(function _callee2$(_context2) {
				while (1) {
					switch (_context2.prev = _context2.next) {
						case 0:
							requestUrl = baseUrl + self.url;
							body = JSON.stringify({
								code: self.forms().current().code(),
								name: self.forms().current().name(),
								dependency: self.forms().current().dependency()
							});
							req = {
								method: 'POST',
								headers: getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context2.prev = 3;
							_context2.next = 6;
							return fetch(requestUrl, req);

						case 6:
							result = _context2.sent;
							_context2.next = 9;
							return result.json();

						case 9:
							model = _context2.sent;

							if (!model.error) {
								_context2.next = 13;
								break;
							}

							toastr.error('Ocurrió un error al Guardar');
							return _context2.abrupt("return");

						case 13:

							toastr.success('Creación Exitosa');
							self.forms().current(new Entity());

							self.getAll(0);
							self.forms().showList();

							_context2.next = 23;
							break;

						case 19:
							_context2.prev = 19;
							_context2.t0 = _context2["catch"](3);

							console.error('Error en request:', _context2.t0);
							toastr.error('Ocurrió un error al Guardar');

						case 23:
						case "end":
							return _context2.stop();
					}
				}
			}, _callee2, this, [[3, 19]]);
		}));

		self.update = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
			var requestUrl, body, req, result, model;
			return regeneratorRuntime.wrap(function _callee3$(_context3) {
				while (1) {
					switch (_context3.prev = _context3.next) {
						case 0:
							requestUrl = baseUrl + self.url + '/' + self.forms().current().id();
							body = JSON.stringify({
								id: self.forms().current().id(),
								code: self.forms().current().code(),
								name: self.forms().current().name(),
								dependency: self.forms().current().dependency()
							});
							req = {
								method: 'PUT',
								headers: getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context3.prev = 3;
							_context3.next = 6;
							return fetch(requestUrl, req);

						case 6:
							result = _context3.sent;
							_context3.next = 9;
							return result.json();

						case 9:
							model = _context3.sent;

							if (!model.error) {
								_context3.next = 13;
								break;
							}

							toastr.error('Ocurrió un error al Actualizar');
							return _context3.abrupt("return");

						case 13:

							toastr.success('Actualización Exitosa');
							self.forms().current(new Entity());

							self.getAll(0);
							self.forms().showList();

							_context3.next = 23;
							break;

						case 19:
							_context3.prev = 19;
							_context3.t0 = _context3["catch"](3);

							console.error('Error en request:', _context3.t0);
							toastr.error('Ocurrió un error al Actualizar');

						case 23:
						case "end":
							return _context3.stop();
					}
				}
			}, _callee3, this, [[3, 19]]);
		}));

		self.deleteEntity = function () {
			var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(element) {
				var requestUrl, req, result, model;
				return regeneratorRuntime.wrap(function _callee4$(_context4) {
					while (1) {
						switch (_context4.prev = _context4.next) {
							case 0:
								requestUrl = baseUrl + self.url + '/' + element.id();
								req = {
									method: 'DELETE',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context4.prev = 2;
								_context4.next = 5;
								return fetch(requestUrl, req);

							case 5:
								result = _context4.sent;
								_context4.next = 8;
								return result.json();

							case 8:
								model = _context4.sent;

								if (!model.error) {
									_context4.next = 12;
									break;
								}

								toastr.error('Ocurrió un error al eliminar');
								return _context4.abrupt("return");

							case 12:

								toastr.success('Eliminación Exitosa');

								self.getAll(0);

								_context4.next = 20;
								break;

							case 16:
								_context4.prev = 16;
								_context4.t0 = _context4["catch"](2);

								console.error('Error en request:', _context4.t0);
								toastr.error('Ocurrió un error al eliminar');

							case 20:
							case "end":
								return _context4.stop();
						}
					}
				}, _callee4, this, [[2, 16]]);
			}));

			return function (_x2) {
				return _ref4.apply(this, arguments);
			};
		}();

		self.remove = function () {
			var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(element) {
				return regeneratorRuntime.wrap(function _callee5$(_context5) {
					while (1) {
						switch (_context5.prev = _context5.next) {
							case 0:

								bootbox.confirm({
									message: "¿Está seguro que desea eliminar el tipo de empleo?",
									buttons: {
										confirm: {
											label: 'Sí',
											className: 'btn-success'
										},
										cancel: {
											label: 'No',
											className: 'btn-danger'
										}
									},
									callback: function callback(result) {
										if (result) {
											self.deleteEntity(element);
										}
									}
								});

							case 1:
							case "end":
								return _context5.stop();
						}
					}
				}, _callee5, this);
			}));

			return function (_x3) {
				return _ref5.apply(this, arguments);
			};
		}();
	}

	var viewModel = new ViewModel();

	viewModel.init();

	ko.applyBindings(viewModel, $('.Franchisees')[0]);

	window.viewModel = viewModel;
});