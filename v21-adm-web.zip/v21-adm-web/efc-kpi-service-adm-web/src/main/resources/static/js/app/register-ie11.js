"use strict";

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	function getDV(T) {

		var m = 0;
		var s = 1;
		T = parseInt(T, 10);
		for (; T; T = Math.floor(T / 10)) {
			s = (s + T % 10 * (9 - m++ % 6)) % 11;
		}

		return s ? s - 1 : 'K';
	}

	function formatRut(rut) {

		return rut.substring(0, rut.length - 1) + '-' + rut.substring(rut.length - 1);
	}

	function validateRut(rut) {

		var checkRx;
		var splitted;
		var digits;
		var dv;
		var calculatedDv;

		if (!rut) {
			return false;
		}

		checkRx = /^\d{7,9}-{0,1}[0-9Kk]/;

		if (!checkRx.test(rut.trim())) {
			return false;
		}

		rut = rut.replace('.', '');

		splitted = rut.split('-');

		if (!splitted[1]) {
			return false;
		}

		digits = splitted[0];
		dv = splitted[1].toUpperCase();
		calculatedDv = getDV(digits).toString();

		return dv === calculatedDv;
	}

	function validateEmail(email) {
		var re = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
		return re.test(email);
	}

	function validateTelephone(telephone) {
		var re = /^(562|569)\d{8}$/i;
		return re.test(telephone);
	}

	function ViewModel() {
		var self = this;

		self.registerUrl = '/api/register';

		self.rut = ko.observable();
		self.customerReferenceIdentifier = ko.observable();
		self.name = ko.observable();
		self.email = ko.observable();
		self.phone = ko.observable();

		self.requestStatus = ko.observable('started');
		self.registrationId = ko.observable(0);

		self.inRequest = ko.observable(false);
		self.inRequestPrev = ko.observable(false);

		self.menuStyle = ko.observable('position: fixed; z-index: 20000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 0; transform: translate3d(100%, 0px, 0px); transition: opacity 0.3s, transform 0s 0.3s;');

		self.init = function () {

			self.getRegister();
		};

		self.getRegister = function () {

			var req = {
				method: 'GET',
				headers: self.getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};

			if (window.registerId) {
				fetch(baseUrl + '/api/registration/searchBy/' + window.registerId, req).then(function (response) {
					return response.json();
				}).then(function (json) {

					var transactionFound = json.applicants.primaryConsumer.personalInformation.TRANSACTIONSEARCH[0].transactionFound;

					var personalInfo = transactionFound.applicants.primaryConsumer.personalInformation;

					self.rut(formatRut(personalInfo.chileanRut));
					self.name(personalInfo.dic_nombre_00);
					self.email(personalInfo.usu_email);
					self.phone(personalInfo.usu_telefono);
					self.requestStatus(transactionFound.clientOrchestrationStatus);
					self.registrationId(window.registerId);
				});
			}
		};

		self.enableRegister = ko.pureComputed(function () {

			var validStatus = self.requestStatus() === 'started';
			var validRut = self.rut() && validateRut(self.rut());
			var validEmail = !self.email() || validateEmail(self.email());
			var validTelephone = !self.phone() || validateTelephone(self.phone());

			return !self.inRequest() && validStatus && validRut && validEmail && validTelephone;
		}, self);

		self.enableRegisterFields = ko.pureComputed(function () {

			return self.requestStatus() === 'started';
		}, self);

		self.validRut = ko.pureComputed(function () {

			return validateRut(self.rut());
		}, self);

		self.validEmail = ko.pureComputed(function () {

			return validateEmail(self.email());
		}, self);

		self.validTelephone = ko.pureComputed(function () {
			return validateTelephone(self.phone());
		}, self);

		self.getHeaders = function () {

			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};

		self.register = function () {
			var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
				var body, req, result, model;
				return regeneratorRuntime.wrap(function _callee$(_context) {
					while (1) {
						switch (_context.prev = _context.next) {
							case 0:

								self.inRequest(true);

								body = JSON.stringify({

									rut: self.rut().toUpperCase(),
									email: self.email() || '',
									telephone: self.phone() || '',
									name: self.name() || ''

								});
								req = {
									method: 'POST',
									headers: self.getHeaders(),
									cache: 'default',
									body: body,
									credentials: 'same-origin'
								};
								_context.prev = 3;
								_context.next = 6;
								return fetch(baseUrl + '/api/registration/register', req);

							case 6:
								result = _context.sent;
								_context.next = 9;
								return result.json();

							case 9:
								model = _context.sent;

								if (!model.error) {
									_context.next = 14;
									break;
								}

								toastr.error('Ocurrió un error al Inscribir. Intente otra vez');
								self.inRequest(false);
								return _context.abrupt("return");

							case 14:

								self.registrationId(model.clientOrchestrationUUID);
								self.requestStatus('registered');
								self.email(model.email);
								self.phone(model.telephone);
								self.name(model.name);

								toastr.success('Inscripción Exitosa');

								self.requestStatus('started');
								self.registrationId(undefined);
								self.email(undefined);
								self.phone(undefined);
								self.name(undefined);
								self.rut(undefined);

								_context.next = 32;
								break;

							case 28:
								_context.prev = 28;
								_context.t0 = _context["catch"](3);

								console.error('Error en request:', _context.t0);
								toastr.error('Ocurrió un error al Inscribir');

							case 32:

								self.inRequest(false);

							case 33:
							case "end":
								return _context.stop();
						}
					}
				}, _callee, this, [[3, 28]]);
			}));

			function handleRegister() {
				return _ref.apply(this, arguments);
			}

			return handleRegister;
		}();

		self.convertToNumber = function (value) {
			return value.replace(/\./g, '').replace(/,/g, '');
		};

		self.preevaluate = function () {
			var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
				var body, req, url, result, model;
				return regeneratorRuntime.wrap(function _callee2$(_context2) {
					while (1) {
						switch (_context2.prev = _context2.next) {
							case 0:

								self.inRequestPrev(true);

								body = JSON.stringify({
									telephone: self.phone(),
									employmentTypeId: self.employmentType().id,
									salary: self.convertToNumber(self.salary()),
									endowment: self.convertToNumber(self.endowment()),
									modelId: self.model().id,
									modelPrice: self.convertToNumber(self.modelPrice()),
									clientOrchestrationUUID: self.registrationId()

								});
								req = {
									method: 'POST',
									headers: self.getHeaders(),
									cache: 'default',
									body: body,
									credentials: 'same-origin'
								};
								_context2.prev = 3;
								url = baseUrl + '/api/registration/preevaluate/' + self.registrationId();
								_context2.next = 7;
								return fetch(url, req);

							case 7:
								result = _context2.sent;
								_context2.next = 10;
								return result.json();

							case 10:
								model = _context2.sent;

								if (!model.error) {
									_context2.next = 15;
									break;
								}

								toastr.error('Ocurrió un error al Perfilar. Intente otra vez');
								self.inRequestPrev(false);
								return _context2.abrupt("return");

							case 15:

								self.registrationId(model.clientOrchestrationUUID);
								self.requestStatus(model.clientOrchestrationStatus);

								if (self.requestStatus() === 'preevaluated') {
									toastr.success('Perfilamiento Exitoso');
									window.location = baseUrl + '/preevaluationresult/' + model.clientOrchestrationUUID;
								} else {
									toastr.error('Ocurrió un error al Perfilar. Intente otra vez');
								}

								_context2.next = 24;
								break;

							case 20:
								_context2.prev = 20;
								_context2.t0 = _context2["catch"](3);

								console.error('Error en request:', _context2.t0);
								toastr.error('Ocurrió un error al Perfilar');

							case 24:

								self.inRequestPrev(false);

							case 25:
							case "end":
								return _context2.stop();
						}
					}
				}, _callee2, this, [[3, 20]]);
			}));

			function handlePreEvaluation() {
				return _ref2.apply(this, arguments);
			}

			return handlePreEvaluation;
		}();

		self.list = ko.observableArray([]);
		self.size = ko.observable(10);
		self.filter = ko.observable('');

		self.isFormVisible = ko.observable(false);
		// self.current = ko.observable(new Entity());

		self.saveEnabled = ko.pureComputed(function () {
			return self.current().address() && self.current().reason();
		}, self);
	}

	var viewModel = new ViewModel();

	viewModel.init();

	ko.applyBindings(viewModel, $('.SalesDashboard')[0]);

	window.viewModel = viewModel;
});