$(document).ready(function($){
	
	
	window.baseUrl = location.href.substring(0,location.href.search('gmac-web-ic') + 11);
	
	
	toastr.options = {
	  "closeButton": false,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-bottom-full-width",
	  "preventDuplicates": false,
	  "onclick": null,
	  "showDuration": "300",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};
	
	ko.bindingHandlers.executeOnEnter = {
		    init: function (element, valueAccessor, allBindings, viewModel) {

		        var bindings = allBindings();
		        $(element).keypress(function (event) {
		            var keyCode = (event.which ? event.which : event.keyCode);
		            if (keyCode === 13) {
		                bindings.executeOnEnter.call(viewModel, viewModel, element);
		                return false;
		            }
		            return true;
		        });
		    },
		    update: function () {}
	};
	
	

	ko.extenders.formatted = function(target, precision) {
	    //create a writable computed observable to intercept writes to our observable
	    var result = ko.pureComputed({
	        read: function () {
	        	
	        	if(!(target && target())){
	        		return '';
	        	}
	        	
	        	var newValue = target().toString();
	        	var val = parseInt(newValue.replace(/\./g,'').replace(/,/g,''));
	        	
	        	if (isNaN(val)){
	        		val = '';
	        	}
	        	
	        	var numberFormat = new Intl.NumberFormat();
	        	
	        	var nf = numberFormat.format(val);
	        	
	            return nf;
	        },  //always return the original observables value
	        write: target
	    }).extend({ notify: 'always' });
	 
	    //initialize with current value to make sure it is rounded appropriately
	    result(target());
	 
	    //return the new computed observable
	    return result;
	};
	

	
	
	function ViewModel(){
		var self = this;
		
		self.registerUrl = '/api/register';
		
		
		self.couuid = ko.observable(window.couuid);
		self.selection = ko.observable(window.selection);
		
		self.rut = ko.observable(window.rut);
		self.name = ko.observable(window.name);
		self.email = ko.observable(window.email === 'null'? '': window.email);
		self.phone = ko.observable(window.phone);
		self.status = ko.observable(window.status);	
		self.model = ko.observable(window.model);
		self.modelPrice = ko.observable(window.modelPrice).extend({formatted: 1});
		self.pie = ko.observable(window.pie).extend({formatted: 1});
		self.plazo = ko.observable(window.plazo).extend({formatted: 1});
		self.cuota = ko.observable(window.cuota).extend({formatted: 1});
		
		self.isAdvanced = ko.observable(window.isAdvanced);
		self.isSales = ko.observable(window.isSales);
		
		self.fechaNacimiento = ko.observable(window.fechaNacimiento);
		self.genero = ko.observable(window.genero);
		self.tasa = ko.observable(window.tasa);
		self.scoreGmac = ko.observable(window.scoreGmac);
		self.scoreEfx = ko.observable(window.scoreEfx);
		self.scoreTUCurrent = ko.observable(window.scoreTUCurrent);
		self.scoreTU13meses = ko.observable(window.scoreTU13meses);
		self.ingreso = ko.observable(window.ingreso).extend({ formatted: 1 });
		
		self.reglasGatilladas = ko.observable(window.reglasGatilladas);
		self.cuotaMax = ko.observable(window.cuotaMax).extend({formatted: 1});
		
		 self.back = function(){
			 window.history.back();
		 };
		 
		 self.getHeaders = function () {
				
				return {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
					'X-Requested-With': 'XMLHttpRequest',
					'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
				};
		};
		 
		 self.sendToFLink = async function() {

			
		 
		    let registration = {
		    	couuid: self.couuid(),
		    	financeIndex: self.selection()
		    };
		    
		   
		    let body = JSON.stringify(registration);
		    
		    let req = {
				method: 'POST',
				headers: self.getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      
		      let url = baseUrl + '/api/registration/finished';
		      let result = await fetch(url , req);
		      let json = await result.json();

		      if (json.clientOrchestrationStatus !== 'selected'){
		    	  toastr.error("Ocurrió un error al Guardar");
		    	  return;
		      }
		     
		      toastr.success("Perfilamiento Exitoso");
		      
		      window.location = baseUrl + "/idpreevaluationsuccess"; 
		      
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error("Ocurrió un error al Guardar en F&I Link");
		    }

		   
		    
		        
		  }
		
		self.convertToNumber = function(value){
		    return value.replace(/\./g,'').replace(/,/g,'');
		};
		
		self.selectRegistration = function (data, id){
			
		    let params = '?';
		    params += 'register=' + self.registrationId();
		    params += '&finance=' + data.id;

		    console.log(params);
		    window.location= baseUrl + '/idpreevaluation' + params;
		    
		}
		
		
	}
	
	var viewModel = new ViewModel();
	
    ko.applyBindings(viewModel, $('.IdPreEvaluation')[0]);
    
    window.viewModel = viewModel;
	
	
});