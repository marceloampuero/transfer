$(document).ready(function($){
	
	window.baseUrl = location.href.substring(0,location.href.search('gmac-web-ic') + 11);
	
	
	toastr.options = {
	  "closeButton": false,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-bottom-full-width",
	  "preventDuplicates": false,
	  "onclick": null,
	  "showDuration": "300",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};
	
	ko.bindingHandlers.executeOnEnter = {
		    init: function (element, valueAccessor, allBindings, viewModel) {

		        var bindings = allBindings();
		        $(element).keypress(function (event) {
		            var keyCode = (event.which ? event.which : event.keyCode);
		            if (keyCode === 13) {
		                bindings.executeOnEnter.call(viewModel, viewModel, element);
		                return false;
		            }
		            return true;
		        });
		    },
		    update: function () {}
	};
	
	ko.bindingHandlers.sort = {
		init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';
			
			element.onclick = function(){
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;
				var dataType = value.dataType;
				
				
				
				bindingContext.$data.sortField(prop);
				asc = !asc;
				
				data.sort(function(left, right){
					var rec1 = left;
					var rec2 = right;
					
					if(!asc) {
						rec1 = right;
						rec2 = left;
					}
					
					var props = prop.split('.');
					for(var i in props){
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if(parenIndex > 0){
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}
					
					rec1 = rec1.toString();
					rec2 = rec2.toString();
					
					if (dataType === 'date'){
						console.log('date');
						
						 rec1 = rec1.split('/').reverse().join('/');
						 rec2 = rec2.split('/').reverse().join('/');
						
						
					}else if (dataType === 'number'){
						
						rec1 = parseInt(rec1.replace(/\./g,'').replace(/,/g,''),10);
						rec2 = parseInt(rec2.replace(/\./g,'').replace(/,/g,''),10);
					}else if (dataType !== 'string'){
						console.error('type not accepted');
					}
					
					
					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
	        };
	    }
	};
	
	

	ko.extenders.formatted = function(target, precision) {
	    //create a writable computed observable to intercept writes to our observable
	    var result = ko.pureComputed({
	        read: function () {
	        	
	        	if(!(target && target())){
	        		return '';
	        	}
	        	
	        	var newValue = target().toString();
	        	var val = parseInt(newValue.replace(/\./g,'').replace(/,/g,''));
	        	
	        	if (isNaN(val)){
	        		val = '';
	        	}
	        	
	        	var numberFormat = new Intl.NumberFormat();
	        	
	        	var nf = numberFormat.format(val);
	        	
	            return nf;
	        },  //always return the original observables value
	        write: target
	    }).extend({ notify: 'always' });
	 
	    //initialize with current value to make sure it is rounded appropriately
	    result(target());
	 
	    //return the new computed observable
	    return result;
	};
	
	function getDV(T){
	    
	    var m = 0;
	    var s = 1;
	    T = parseInt(T, 10);
	    for (; T; T = Math.floor(T / 10)) {
	        s = (s + T % 10 * (9 - m++ % 6)) % 11;
	    }

	    return s ? s - 1 : 'K';
	}

	function validateRut(rut) {
	    
	    var checkRx;
	    var splitted;
	    var digits;
	    var dv;
	    var calculatedDv;


	    if (!rut) {
	        return false;
	    }

	    checkRx = /^\d{7,9}-{0,1}[0-9Kk]/;

	    if (!checkRx.test(rut.trim())) {
	        return false;
	    }

	    rut = rut.replace('.', '');

	    splitted = rut.split('-');

	    if (!splitted[1]) {
	        return false;
	    }

	    digits = splitted[0];
	    dv = splitted[1].toUpperCase();
	    calculatedDv = getDV(digits).toString();

	    return (dv === calculatedDv);

	}


	function validateEmail(email) {
	    var re = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
	    return re.test(email);
	}
	
	function validateTelephone(telephone){
		return telephone && telephone.length;
	}
	
	function ViewModel(){
		var self = this;
		
		self.registerUrl = '/api/register';
		
		self.results = ko.observableArray([]);
		
		self.sortField = ko.observable();
		self.sortOrder = ko.observable(1);
		
		self.querying = ko.observable(false);
		
		self.init = function (){
			self.search();
		}
		
		
		self.getHeaders = function () {
			
			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};
		
		self.search = async function () {
			
			self.querying(true);
					    
		    try {
		    	
		    	let paramList = [];
				
				

			    if (window.rut){
			    	paramList.push('rut=' + window.rut);
			    }
			    
			    if (window.periodo){
			    	paramList.push('periodo=' + window.periodo);
			    }
			    
			    if (window.usuario){
			    	paramList.push('usuario=' +window.usuario);
			    }
			    
			    if (window.sucursal){
			    	paramList.push('sucursal=' + window.sucursal);
			    }
			    
			    if (window.concesionario){
			    	paramList.push('concesionario=' + window.concesionario);
			    }
			    
			    let params = '?' + paramList.join('&');
			    
				const url = baseUrl + '/api/registration/listBy'+ params;
				
				let req = {
					method: 'GET',
					headers: self.getHeaders(),
					cache: 'default',
					credentials: 'same-origin'
				};
 
				const res =  await fetch(url, req);
				const json = await res.json();
				  
				if (json.error){
					toastr.error("Ocurrió un error al obtener la información");
					console.error(json.error);
					self.querying(false);
					return;
				}
				
				try{
					if (json.applicants.primaryConsumer.personalInformation.TRANSACTIONLIST[0].clientOrchestrationStatus === 'error' &&
							json.applicants.primaryConsumer.personalInformation.TRANSACTIONLIST[0].clientOrchestrationMessageError.indexOf('Results') >= 0){
						toastr.warning("Límite de búsqueda excedido. Debe refinar la búsqueda");
						console.error('Error:', json.applicants.primaryConsumer.personalInformation.TRANSACTIONLIST[0].clientOrchestrationMessageError);
						self.querying(false);
						return;
					}
					
					
				}catch(err){
					
				}
				

				
				
				let list = json.applicants.primaryConsumer.personalInformation.TRANSACTIONLIST.map(x => {
					x.DIC_NOMBRE_00 = x.DIC_NOMBRE_00.toLowerCase().replace(/(^|\s)\S/g, l => l.toUpperCase());
					return x;
				})
				
				let listWithoutSurname = list.map(x =>{
					
					let nameArray = x.DIC_NOMBRE_00.split(' ');
					
					let name = nameArray[0];
					let lastName = nameArray[nameArray.length-2];
					let secondLastName = '';
					
					if (nameArray.length >= 3){
						secondLastName = nameArray[nameArray.length-1];
					}
					
					x.DIC_NOMBRE_00 = (name + ' ' + lastName + ' ' + secondLastName).trim()
					
					return x;
					
				});
				
				self.results(listWithoutSurname);

				
		    } catch (error) {
		    	toastr.error("Ocurrió un error al obtener la información");
		    }
		    
		    self.querying(false);
		    
		    
		};
		
		self.selectRegistration = function (selected){
			
			if(selected.clientOrchestrationStatus === 'registered'){
				window.location =  baseUrl + '/sales?id=' + selected.clientOrchestrationUUID
    
			}else if(selected.clientOrchestrationStatus === 'preevaluated'){
				window.location = baseUrl + '/preevaluationresult/' + selected.clientOrchestrationUUID
   
			}else if (selected.clientOrchestrationStatus === 'selected'){
				
				window.location = baseUrl + '/viewpreevaluation/' + selected.clientOrchestrationUUID
   
			}
		};
		
	}
	
	var viewModel = new ViewModel();
	
	viewModel.init();
	
    ko.applyBindings(viewModel, $('.SearchResult')[0]);
    
    window.viewModel = viewModel;
	
	
});