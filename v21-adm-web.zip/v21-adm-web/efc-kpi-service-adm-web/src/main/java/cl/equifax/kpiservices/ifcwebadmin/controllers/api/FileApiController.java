package cl.equifax.kpiservices.ifcwebadmin.controllers.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.ifcwebadmin.entities.FilesIndex;
import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.services.KpiService;

@RestController
@RequestMapping("/api/files")
public class FileApiController {
	@Autowired
	KpiService fileService;

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@GetMapping("/all")
	public List<FilesIndex> findAll() {

		return fileService.findAllIndex();
	}

	@GetMapping
	public PageDetail findAllPaginate(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(required = false, name = "kpi") String kpi,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size) {

		return fileService.findAllIndex(filter, page, size, kpi);

	}
}
