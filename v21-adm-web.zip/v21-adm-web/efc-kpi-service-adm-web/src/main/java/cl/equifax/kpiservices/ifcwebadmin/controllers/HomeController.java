package cl.equifax.kpiservices.ifcwebadmin.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

import cl.equifax.kpiservices.ifcwebadmin.utils.EFXAuthUtils;

@Controller
@RequestMapping("/")
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@GetMapping("/")
	public RedirectView home(Authentication authentication, HttpServletRequest request, HttpSession session,
			Model model) {

		String redirectPage = "structures";

		if (authentication != null && authentication.isAuthenticated()) {

			if (EFXAuthUtils.hasRole(authentication, "P03")) {

				redirectPage = "structures";
			} else if (EFXAuthUtils.hasRole(authentication, "P01") || EFXAuthUtils.hasRole(authentication, "P02")) {
				redirectPage = "files";
			}

		} else {
			redirectPage = "login";
		}

		return new RedirectView(redirectPage);

	}

}