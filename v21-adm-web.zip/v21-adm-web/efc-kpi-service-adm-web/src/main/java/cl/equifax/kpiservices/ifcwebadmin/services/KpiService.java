package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cl.equifax.kpiservices.ifcwebadmin.entities.FilesIndex;
import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;
import cl.equifax.kpiservices.ifcwebadmin.entities.StructureRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessResponse;

@FeignClient(name = "agy-kpi-service")
public interface KpiService {

	@GetMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/filesindex/all")
	List<FilesIndex> findAllIndex();

	@GetMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/filesindex")
	PageDetail findAllIndex(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size,
			@RequestParam(required = false, name = "kpi") String kpi);

	@GetMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure/all")
	List<Structure> findAllStructures();

	@GetMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure?page={page}&size={size}&filter={filter}")
	@ResponseBody
	PageDetail findAllStructures(@PathVariable(value = "filter") String filter,
			@PathVariable(value = "page") Integer page, @PathVariable(value = "size") Integer size);

	@PostMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure")
	StructureRequest createStructure(@RequestBody StructureRequest request);

	@PutMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure/{id}")
	StructureRequest editStructure(@PathVariable(value = "id") Integer id, @RequestBody StructureRequest request);

	@PutMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure/{id}/{fileId}?user={user}")
	StructureRequest updateIndexFileStructure(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId, @PathVariable(value = "user") String user);

	@DeleteMapping("/agy-kpi-service/kpis/bbe-kpi-services-index-consumer/v1/structure/{id}?user={user}")
	StructureRequest deleteStructure(@PathVariable(value = "id") Integer id, @PathVariable(value = "user") String user);

	@PostMapping("/agy-kpi-service/accessvalidator/bbe-accessvalidator-rest/v1/accessstatus")
	AccessResponse autenticate(AccessRequest request);

}
