package cl.equifax.kpiservices.ifcwebadmin.controllers.api;

import java.util.Calendar;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;
import cl.equifax.kpiservices.ifcwebadmin.entities.StructureRequest;
import cl.equifax.kpiservices.ifcwebadmin.services.KpiService;

@RestController
@RequestMapping("/api/structures")
public class StructureApiController {

	@Autowired
	KpiService service;

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@GetMapping("/all")
	public List<Structure> findAll() {

		return service.findAllStructures();
	}

	@GetMapping()
	public PageDetail findAllPaginate(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size) {

		return service.findAllStructures(filter, page, size);
	}

	@PostMapping
	public StructureRequest create(@Valid @RequestBody StructureRequest structure, Authentication authentication) {

		structure.setCreatedBy(authentication.getName());
		structure.setCreatedAt(Calendar.getInstance().getTime());
		return service.createStructure(structure);

	}

	@PutMapping("/{id}")
	public StructureRequest put(@PathVariable(value = "id") Integer id, @RequestBody StructureRequest request,
			Authentication authentication) {

		request.setModifiedBy(authentication.getName());
		request.setModifiedAt(Calendar.getInstance().getTime());
		return service.editStructure(id, request);

	}

	@PutMapping("/{id}/{fileId}")
	public StructureRequest updateIndexFile(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId, Authentication authentication) {

		return service.updateIndexFileStructure(id, fileId, authentication.getName());

	}

	@DeleteMapping("/{id}")
	public StructureRequest delete(@PathVariable(value = "id") Integer id, Authentication authentication) {

		return service.deleteStructure(id, authentication.getName());
	}

}
