package cl.equifax.kpiservices.ifcwebadmin.entities;

import java.util.Calendar;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Structure {

	private Integer id;

	@NotNull
	@Size(max = 50)
	private String kpi;
	private String description;

	private String kpiCurrentVersion;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdAt = Calendar.getInstance().getTime();

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedAt = Calendar.getInstance().getTime();
	private String createdBy;
	private String modifiedBy;

	@NotNull
	@Size(max = 50)
	private String header;

	private boolean active = true;

	private String lastIndexPath;

	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Structure [id=" + id + ", kpi=" + kpi + ", description=" + description + ", kpiCurrentVersion="
				+ kpiCurrentVersion + ", createdAt=" + createdAt + ", modifiedAt=" + modifiedAt + ", createdBy="
				+ createdBy + ", modifiedBy=" + modifiedBy + ", header=" + header + ", active=" + active
				+ ", lastIndexPath=" + lastIndexPath + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLastIndexPath() {
		return lastIndexPath;
	}

	public void setLastIndexPath(String lastIndexPath) {
		this.lastIndexPath = lastIndexPath;
	}

	public String getKpiCurrentVersion() {
		return kpiCurrentVersion;
	}

	public void setKpiCurrentVersion(String kpiCurrentVersion) {
		this.kpiCurrentVersion = kpiCurrentVersion;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
