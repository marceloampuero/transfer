package cl.equifax.kpiservices.bbekpiservices.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class KpiRequest {

	@JsonProperty("kpiServices")
	private KpiServicesRequest kpiServices;

	public KpiServicesRequest getKpiServices() {
		return kpiServices;
	}

	public void setKpiServices(KpiServicesRequest kpiServices) {
		this.kpiServices = kpiServices;
	}

	@Override
	public String toString() {
		return "KpiRequest [kpiServices=" + kpiServices + "]";
	}

}
