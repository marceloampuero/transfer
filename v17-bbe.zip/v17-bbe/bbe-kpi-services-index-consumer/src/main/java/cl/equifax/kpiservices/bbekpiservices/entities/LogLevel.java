package cl.equifax.kpiservices.bbekpiservices.entities;

public enum LogLevel {

	WARN, INFO, DEBUG, ERROR, TRACE

}
