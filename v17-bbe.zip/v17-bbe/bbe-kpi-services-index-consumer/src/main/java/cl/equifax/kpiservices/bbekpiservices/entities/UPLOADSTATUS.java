package cl.equifax.kpiservices.bbekpiservices.entities;

public enum UPLOADSTATUS {
	OK, ERROR
}
