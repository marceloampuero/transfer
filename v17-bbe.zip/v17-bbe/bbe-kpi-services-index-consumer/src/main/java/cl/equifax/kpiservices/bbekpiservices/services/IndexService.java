package cl.equifax.kpiservices.bbekpiservices.services;

public interface IndexService {

	void createKpiIndex(String kpi);

}
