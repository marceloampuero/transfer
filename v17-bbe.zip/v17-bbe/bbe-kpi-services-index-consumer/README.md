# bbe-kpi-services

KPI service REST microservice