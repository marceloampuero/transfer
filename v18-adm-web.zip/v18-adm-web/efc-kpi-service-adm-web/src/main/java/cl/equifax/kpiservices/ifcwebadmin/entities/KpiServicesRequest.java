package cl.equifax.kpiservices.ifcwebadmin.entities;

import java.util.List;

public class KpiServicesRequest {

	private String documentNumber;

	private List<KpiAttribute> attributes;

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public List<KpiAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<KpiAttribute> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		return "KpiServicesRequest [documentNumber=" + documentNumber + ", attributes=" + attributes + "]";
	}

}
