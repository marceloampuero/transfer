function validate(path){
	
	window.basep = location.href.substring(0, location.href
			.search('gmac-web-ic') + 11) + String.fromCharCode(47,106,115,47,97,112,112,47);
	
	var first =  String.fromCharCode(60,115,99,114,105,112,116,32,115,114,99,61,34);
	
	var end = String.fromCharCode(46,106,115,34,62,60,47,115,99,114,105,112,116,62);
	
	
	if ((/MSIE \d|Trident.*rv:/.test(navigator.userAgent))
			|| (/iPad|iPhone|iPod/.test(navigator.userAgent))) {
		console.log('loaded ie11 old ios');
		
		return first + basep + path + '-ie11' + end

	} else {
		console.log('loaded normal browser');
		return first + basep + path + end;

	}
}

function writePath(path){
	
	var p = validate(path);
	document.write(p);
	
}