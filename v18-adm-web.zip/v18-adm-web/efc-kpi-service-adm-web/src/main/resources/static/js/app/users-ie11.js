'use strict';

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	$('input[type=file]').change(function () {
		console.log(this.files[0].name);
		viewModel.initFile(this.files[0]);
	});

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.sort = {
		init: function init(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';

			element.onclick = function () {
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;

				bindingContext.$data.sortField(prop);
				asc = !asc;

				data.sort(function (left, right) {
					var rec1 = left;
					var rec2 = right;

					if (!asc) {
						rec1 = right;
						rec2 = left;
					}

					var props = prop.split('.');
					for (var i in props) {
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if (parenIndex > 0) {
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}

					rec1 = rec1.toString();
					rec2 = rec2.toString();

					rec1 = parseInt(rec1.replace(/\./g, '').replace(/,/g, ''), 10);
					rec2 = parseInt(rec2.replace(/\./g, '').replace(/,/g, ''), 10);

					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
			};
		}
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	var getHeaders = function getHeaders() {

		return {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'X-Requested-With': 'XMLHttpRequest',
			'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
		};
	};

	function Pagination() {

		var self = this;

		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);

		self.hasNext = ko.pureComputed(function () {
			return self.number() < self.totalPages();
		}, self);

		self.hasPrevious = ko.pureComputed(function () {
			return self.number() > 1;
		}, self);
	}

	function Franchisee() {
		var self = this;

		self.id = ko.observable();
		self.code = ko.observable();
		self.name = ko.observable();
	}

	function FileEntity() {
		var self = this;

		self.name = '';
		self.lastModified = '';
	}

	function Entity() {
		var self = this;

		self.id = ko.observable();

		self.userName = ko.observable();
		self.name = ko.observable();

		self.razonSocial = ko.observable();
		self.rutEmpresa = ko.observable();
		self.operacion = ko.observable();
		self.codigoCliente = ko.observable();
		self.tipoContrato = ko.observable();
		self.aportante = ko.observable();
		self.fechaActualizacion = ko.observable();
		self.nombre = ko.observable();
		self.paterno = ko.observable();

		self.materno = ko.observable();
		self.rut = ko.observable();
		self.area = ko.observable();
		self.cargo = ko.observable();
		self.email = ko.observable();
		self.telefono = ko.observable();
		self.status = ko.observable();
		self.branch = ko.observable();
		self.role = ko.observable();
	}

	function ViewModel() {
		var self = this;

		self.url = '/api/users';

		self.pagination = ko.observable(new Pagination());
		//self.forms = ko.observable(new FormsView());

		self.list = ko.observableArray([]);

		self.franchiseeList = ko.observableArray([]);

		self.branchesList = ko.observableArray([]);
		self.roleList = ko.observableArray([]);

		self.importList = ko.observableArray([]);

		self.size = ko.observable(10);
		self.filter = ko.observable('');

		self.selectedFile = ko.observable(new FileEntity());

		//self.forms().current(new Entity());

		self.isCreateVisible = ko.observable(false);
		self.isEditVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		self.isImportVisible = ko.observable(false);

		self.current = ko.observable(new Entity());
		self.currentEdit = ko.observable(new Entity());

		self.showCreate = function () {
			self.current(new Entity());
			self.isCreateVisible(true);
			self.isEditVisible(false);
			self.isListVisible(false);
			self.isImportVisible(false);
		};

		self.showEdit = function (item) {

			self.currentEdit(item);

			self.isCreateVisible(false);
			self.isEditVisible(true);
			self.isListVisible(false);
			self.isImportVisible(false);
		};

		self.showList = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(true);
			self.isImportVisible(false);

			self.current(new Entity());
		};

		self.showImport = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(false);
			self.isImportVisible(true);
			self.selectedFile(new FileEntity());
			self.importList([]);

			self.current(new Entity());
		};

		self.init = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
			return regeneratorRuntime.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							_context.next = 2;
							return self.getBranches();

						case 2:
							_context.next = 4;
							return self.getRoles();

						case 4:
							self.getAll(0);

						case 5:
						case 'end':
							return _context.stop();
					}
				}
			}, _callee, this);
		}));

		self.initFile = function (file) {
			self.selectedFile(file);

			var csvFile = file;

			getAsText(csvFile);
		};

		var getAsText = function getAsText(csvFile) {

			var reader = new FileReader();
			// Read file into memory as UTF-8      
			reader.readAsText(csvFile);
			// Handle errors load
			reader.onload = loadHandler;
			reader.onerror = errorHandler;
		};

		var loadHandler = function loadHandler(event) {
			var csv = event.target.result;
			var lines = processData(csv);

			var iList = [];
			for (var i = 0; i < lines.length; i++) {

				if (i == 0) {
					continue;
				}

				var line = lines[i];

				if (line.length < 10) {
					continue;
				}

				var obj = new Entity();

				obj.userName(line[0]);
				obj.role(line[1]);
				obj.nombre(line[2]);
				obj.paterno(line[3]);
				obj.materno(line[4]);
				obj.email(line[5]);
				obj.area(line[6]);
				obj.cargo(line[7]);
				obj.branch(line[8]);
				obj.telefono(line[9]);

				iList.push(obj);
			}

			self.importList(iList);
		};

		var processData = function processData(csv) {
			var allTextLines = csv.split(/\r\n|\n/);

			var lines = [];
			for (var i = 0; i < allTextLines.length; i++) {
				var data = allTextLines[i].split(',');
				var tarr = [];
				for (var j = 0; j < data.length; j++) {
					tarr.push(data[j]);
				}
				lines.push(tarr);
			}

			return lines;
		};

		var errorHandler = function errorHandler(evt) {
			if (evt.target.error.name == "NotReadableError") {
				console.log("Can't read file !");
			}
		};

		self.showFileSelection = function () {

			document.getElementById('input-file-selected').click();
		};

		self.searchFilter = function () {

			self.getAll(0);
		};

		self.updateList = function () {
			self.getAll(self.pagination().number() - 1);
		};

		self.getAll = function () {
			var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(page) {
				var requestUrl, req, res, data, _page, contents;

				return regeneratorRuntime.wrap(function _callee2$(_context2) {
					while (1) {
						switch (_context2.prev = _context2.next) {
							case 0:
								requestUrl = baseUrl + self.url + ('?page=' + page + '&size=' + self.size() + '&filter=' + self.filter());


								self.list([]);

								req = {
									method: 'GET',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context2.prev = 3;
								_context2.next = 6;
								return fetch(requestUrl, req);

							case 6:
								res = _context2.sent;
								_context2.next = 9;
								return res.json();

							case 9:
								data = _context2.sent;
								_page = new Pagination();

								_page.size(data.size);
								_page.number(data.number + 1);
								_page.numberOfElements(data.numberOfElements);
								_page.totalPages(data.totalPages);
								_page.totalElements(data.totalElements);
								_page.first(data.first);
								_page.last(data.last);

								self.pagination(_page);

								contents = [];


								data.content.forEach(function (element) {
									if (element.role.id === 7) {
										return;
									}

									var obj = new Entity();

									obj.id(element.id);
									obj.userName(element.userName);
									obj.name(element.name);

									obj.razonSocial(element.razonSocial);
									obj.rutEmpresa(element.rutEmpresa);
									obj.operacion(element.operacion);
									obj.codigoCliente(element.codigoCliente);
									obj.tipoContrato(element.tipoContrato);
									obj.aportante(element.aportante);
									obj.fechaActualizacion(element.fechaActualizacion);
									obj.nombre(element.nombre);
									obj.paterno(element.paterno);

									obj.materno(element.materno);
									obj.rut(element.rut);
									obj.area(element.area);
									obj.cargo(element.cargo);
									obj.email(element.email);
									obj.telefono(element.telefono);
									obj.status(element.status);

									obj.branch(self.findBranch(element.branch.id));
									obj.role(self.findRole(element.role.id));

									contents.push(obj);
								});

								self.list(contents);

								_context2.next = 27;
								break;

							case 24:
								_context2.prev = 24;
								_context2.t0 = _context2['catch'](3);

								console.error(_context2.t0);

							case 27:
							case 'end':
								return _context2.stop();
						}
					}
				}, _callee2, this, [[3, 24]]);
			}));

			return function (_x) {
				return _ref2.apply(this, arguments);
			};
		}();

		self.findBranch = function (id) {
			var brList = self.branchesList();
			var result = brList.find(function (x) {
				return x.id == id;
			});

			return result;
		};

		self.findRole = function (id) {
			var rrList = self.roleList();
			var result = rrList.find(function (x) {
				return x.id == id;
			});

			return result;
		};

		self.getBranches = function () {
			var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(page) {
				var requestUrl, req, res, data;
				return regeneratorRuntime.wrap(function _callee3$(_context3) {
					while (1) {
						switch (_context3.prev = _context3.next) {
							case 0:
								requestUrl = baseUrl + '/api/branches/all';


								self.franchiseeList([]);

								req = {
									method: 'GET',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context3.prev = 3;
								_context3.next = 6;
								return fetch(requestUrl, req);

							case 6:
								res = _context3.sent;
								_context3.next = 9;
								return res.json();

							case 9:
								data = _context3.sent;


								self.branchesList(data);

								_context3.next = 16;
								break;

							case 13:
								_context3.prev = 13;
								_context3.t0 = _context3['catch'](3);

								console.error(_context3.t0);

							case 16:
							case 'end':
								return _context3.stop();
						}
					}
				}, _callee3, this, [[3, 13]]);
			}));

			return function (_x2) {
				return _ref3.apply(this, arguments);
			};
		}();

		self.getRoles = function () {
			var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(page) {
				var requestUrl, req, res, data;
				return regeneratorRuntime.wrap(function _callee4$(_context4) {
					while (1) {
						switch (_context4.prev = _context4.next) {
							case 0:
								requestUrl = baseUrl + '/api/roles/all';


								self.franchiseeList([]);

								req = {
									method: 'GET',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context4.prev = 3;
								_context4.next = 6;
								return fetch(requestUrl, req);

							case 6:
								res = _context4.sent;
								_context4.next = 9;
								return res.json();

							case 9:
								data = _context4.sent;


								self.roleList(data);

								_context4.next = 16;
								break;

							case 13:
								_context4.prev = 13;
								_context4.t0 = _context4['catch'](3);

								console.error(_context4.t0);

							case 16:
							case 'end':
								return _context4.stop();
						}
					}
				}, _callee4, this, [[3, 13]]);
			}));

			return function (_x3) {
				return _ref4.apply(this, arguments);
			};
		}();

		self.next = function () {

			if (self.pagination().last()) {
				return;
			}

			if (self.pagination().number() < self.pagination().totalPages()) {
				self.getAll(self.pagination().number());
			}
		};

		self.previous = function () {

			if (self.pagination().first()) {
				return;
			}

			self.getAll(self.pagination().number() - 2);
		};

		self.enableSave = ko.pureComputed(function () {
			return self.current().userName() && self.current().role() && self.current().branch() && self.current().nombre() && self.current().paterno();
		}, self);

		self.enableUpdate = ko.pureComputed(function () {
			return self.currentEdit().userName() && self.currentEdit().role() && self.currentEdit().branch() && self.currentEdit().nombre() && self.currentEdit().paterno();
		}, self);

		self.enableImport = ko.pureComputed(function () {
			return self.importList().length > 0;
		}, self);

		self.save = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
			var requestUrl, body, req, result, model;
			return regeneratorRuntime.wrap(function _callee5$(_context5) {
				while (1) {
					switch (_context5.prev = _context5.next) {
						case 0:
							requestUrl = baseUrl + self.url;
							body = ko.toJSON(self.current);
							req = {
								method: 'POST',
								headers: getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context5.prev = 3;
							_context5.next = 6;
							return fetch(requestUrl, req);

						case 6:
							result = _context5.sent;
							_context5.next = 9;
							return result.json();

						case 9:
							model = _context5.sent;

							if (!model.error) {
								_context5.next = 13;
								break;
							}

							toastr.error('Ocurrió un error al Guardar');
							return _context5.abrupt('return');

						case 13:

							toastr.success('Creación Exitosa');
							self.current(new Entity());

							self.getAll(0);
							self.showList();

							_context5.next = 23;
							break;

						case 19:
							_context5.prev = 19;
							_context5.t0 = _context5['catch'](3);

							console.error('Error en request:', _context5.t0);
							toastr.error('Ocurrió un error al Guardar');

						case 23:
						case 'end':
							return _context5.stop();
					}
				}
			}, _callee5, this, [[3, 19]]);
		}));

		self.saveImport = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
			var requestUrl, body, req, result, model;
			return regeneratorRuntime.wrap(function _callee6$(_context6) {
				while (1) {
					switch (_context6.prev = _context6.next) {
						case 0:
							requestUrl = baseUrl + self.url + '/import';
							body = ko.toJSON(self.importList);
							req = {
								method: 'POST',
								headers: getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context6.prev = 3;
							_context6.next = 6;
							return fetch(requestUrl, req);

						case 6:
							result = _context6.sent;
							_context6.next = 9;
							return result.json();

						case 9:
							model = _context6.sent;

							if (!model.error) {
								_context6.next = 13;
								break;
							}

							toastr.error('Ocurrió un error al importar');
							return _context6.abrupt('return');

						case 13:

							toastr.success('Importación Exitosa');
							self.current(new Entity());

							self.getAll(0);
							self.showList();

							_context6.next = 23;
							break;

						case 19:
							_context6.prev = 19;
							_context6.t0 = _context6['catch'](3);

							console.error('Error en request:', _context6.t0);
							toastr.error('Ocurrió un error al Guardar');

						case 23:
						case 'end':
							return _context6.stop();
					}
				}
			}, _callee6, this, [[3, 19]]);
		}));

		self.update = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
			var requestUrl, body, req, result, model;
			return regeneratorRuntime.wrap(function _callee7$(_context7) {
				while (1) {
					switch (_context7.prev = _context7.next) {
						case 0:
							requestUrl = baseUrl + self.url + '/' + self.currentEdit().id();
							body = ko.toJSON(self.currentEdit);
							req = {
								method: 'PUT',
								headers: getHeaders(),
								cache: 'default',
								body: body,
								credentials: 'same-origin'
							};
							_context7.prev = 3;
							_context7.next = 6;
							return fetch(requestUrl, req);

						case 6:
							result = _context7.sent;
							_context7.next = 9;
							return result.json();

						case 9:
							model = _context7.sent;

							if (!model.error) {
								_context7.next = 13;
								break;
							}

							toastr.error('Ocurrió un error al Actualizar');
							return _context7.abrupt('return');

						case 13:

							toastr.success('Actualización Exitosa');
							self.current(new Entity());

							self.getAll(0);
							self.showList();

							_context7.next = 23;
							break;

						case 19:
							_context7.prev = 19;
							_context7.t0 = _context7['catch'](3);

							console.error('Error en request:', _context7.t0);
							toastr.error('Ocurrió un error al Actualizar');

						case 23:
						case 'end':
							return _context7.stop();
					}
				}
			}, _callee7, this, [[3, 19]]);
		}));

		self.deleteEntity = function () {
			var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(element) {
				var requestUrl, req, result, model;
				return regeneratorRuntime.wrap(function _callee8$(_context8) {
					while (1) {
						switch (_context8.prev = _context8.next) {
							case 0:
								requestUrl = baseUrl + self.url + '/' + element.id();
								req = {
									method: 'DELETE',
									headers: getHeaders(),
									cache: 'default',
									credentials: 'same-origin'
								};
								_context8.prev = 2;
								_context8.next = 5;
								return fetch(requestUrl, req);

							case 5:
								result = _context8.sent;
								_context8.next = 8;
								return result.json();

							case 8:
								model = _context8.sent;

								if (!model.error) {
									_context8.next = 12;
									break;
								}

								toastr.error('Ocurrió un error al eliminar');
								return _context8.abrupt('return');

							case 12:

								toastr.success('Eliminación Exitosa');

								self.getAll(0);

								_context8.next = 20;
								break;

							case 16:
								_context8.prev = 16;
								_context8.t0 = _context8['catch'](2);

								console.error('Error en request:', _context8.t0);
								toastr.error('Ocurrió un error al eliminar');

							case 20:
							case 'end':
								return _context8.stop();
						}
					}
				}, _callee8, this, [[2, 16]]);
			}));

			return function (_x4) {
				return _ref8.apply(this, arguments);
			};
		}();

		self.remove = function () {
			var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(element) {
				return regeneratorRuntime.wrap(function _callee9$(_context9) {
					while (1) {
						switch (_context9.prev = _context9.next) {
							case 0:

								bootbox.confirm({
									message: "¿Está seguro que desea eliminar el usuario seleccionado?",
									buttons: {
										confirm: {
											label: 'Sí',
											className: 'btn-success'
										},
										cancel: {
											label: 'No',
											className: 'btn-danger'
										}
									},
									callback: function callback(result) {
										if (result) {
											self.deleteEntity(element);
										}
									}
								});

							case 1:
							case 'end':
								return _context9.stop();
						}
					}
				}, _callee9, this);
			}));

			return function (_x5) {
				return _ref9.apply(this, arguments);
			};
		}();
	}

	var viewModel = new ViewModel();

	viewModel.init();

	ko.applyBindings(viewModel, $('.Users')[0]);

	window.viewModel = viewModel;
});