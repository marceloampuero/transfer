$(document).ready(function($){
	

	
	function ViewModel(){
		var self = this;
		
		self.url = '/api/queries';
		
		 
	    self.getAll = async function () {
	    }; 
		
	}
	
	var viewModel = new ViewModel();
	viewModel.getAll();
    ko.applyBindings(viewModel, $('.page-wrapper')[0]);
    
    window.viewModel = viewModel;
	
	
});