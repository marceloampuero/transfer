package cl.equifax.kpiservices.bbekpiservices.kpi;

public class IndexFolderDoNotExistsException extends RuntimeException {

	private static final long serialVersionUID = 702191088230592531L;

	private static final String MESSAGE = "Index folder do not exists";

	public IndexFolderDoNotExistsException() {
		super(MESSAGE);
	}

	public IndexFolderDoNotExistsException(String message) {
		super(message);

	}

	public IndexFolderDoNotExistsException(Throwable cause) {
		super(MESSAGE, cause);

	}

	public IndexFolderDoNotExistsException(String message, Throwable cause) {
		super(message, cause);

	}

	public IndexFolderDoNotExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
