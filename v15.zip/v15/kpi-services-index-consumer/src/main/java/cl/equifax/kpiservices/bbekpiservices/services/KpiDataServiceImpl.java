package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.equifax.kpiservices.bbekpiservices.entities.Kpi;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiAttribute;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.kpi.KpiService;

@Service
public class KpiDataServiceImpl implements KpiDataService {

	private KpiService service;
	private StructureService structureService;

	@Autowired
	public KpiDataServiceImpl(KpiService service, StructureService structureService,
			FilesIndexService filesIndexService, LogService logService) {
		this.service = service;
		this.structureService = structureService;
	}

	@Override
	public KpiResponse getKpiByRut(String rut, String kpi) {

		return null;
	}

	@Override
	public KpiResponse getKpisByRut(String rut, List<String> kpis) {

		return null;
	}

	private List<String> getAllCurrentKpiNames() {
		List<Structure> structures = this.structureService.findActiveKpis();

		return structures.stream().map(s -> s.getKpiCurrentVersion()).collect(Collectors.toList());
	}

	private List<String> getCurrentKpiNames(List<String> kpis) {
		Set<String> kpisSet = kpis.stream().collect(Collectors.toSet());

		List<Structure> structures = this.structureService.findAll();

		List<Structure> filterList = structures.stream().filter(s -> kpisSet.contains(s.getKpi()))
				.collect(Collectors.toList());

		return filterList.stream().map(s -> s.getKpiCurrentVersion()).collect(Collectors.toList());

	}

	private String removeTimeStamp(String kpiNameWithTimestamp) {

		return kpiNameWithTimestamp.substring(0, kpiNameWithTimestamp.lastIndexOf("-"));

	}

	@Override
	public KpiResponse getKpiByRut(KpiRequest request) {

		String rut = request.getKpiServices().getDocumentNumber();

		List<KpiAttribute> attributes = request.getKpiServices().getAttributes();
		List<String> currentKpis;
		if (attributes == null || attributes.isEmpty() || attributes.get(0).getVariableName() == null
				|| attributes.get(0).getVariableName().isEmpty()) {

			currentKpis = this.getAllCurrentKpiNames();

		} else {
			List<String> kpis = attributes.stream().map(p -> p.getVariableName()).collect(Collectors.toList());

			currentKpis = this.getCurrentKpiNames(kpis);
		}

		// if attributes empty then all kpis
		// else get from list

		Map<String, String> result = this.service.getKpis(rut, currentKpis);

		List<KpiAttribute> attributesResult = new ArrayList<>();

		result.forEach((k, v) -> attributesResult.add(new KpiAttribute(removeTimeStamp(k), v)));

		KpiResponse response = new KpiResponse();
		Kpi kpi = new Kpi();

		kpi.setAttributes(attributesResult);
		response.setKpi(kpi);

		return response;
	}
	//
	// private String getFileName(String filePath) {
	// return Paths.get(filePath).getFileName().toString();
	// }

	// @Override
	// public UploadResult addKpiFile(String kpi, String filePath) {
	//
	// Structure structure = this.structureService.findByKpi(kpi);
	//
	// if (structure == null) {
	// throw new KpiStructureNotFoundException();
	// }
	//
	// String filename = this.getFileName(filePath);
	// String indexName = filename.substring(0, filename.length() - 4);
	//
	// String indexPath = this.service.createReplaceIndex(indexName);
	//
	// service.loadKpis(indexName, filePath, structure.getHeader());
	//
	// structure.setKpiCurrentVersion(indexName);
	// structure.setLastIndexPath(indexPath);
	//
	// Structure savedStructure = this.structureService.save(structure);
	//
	// FilesIndex filesIndex = new FilesIndex();
	//
	// filesIndex.setFilePath(filePath);
	// filesIndex.setIndexPath(indexPath);
	// filesIndex.setStructure(savedStructure);
	//
	// this.filesIndexService.save(filesIndex);
	//
	// UploadResult result = new UploadResult();
	//
	// result.setStatus(UPLOADSTATUS.OK);
	// result.setDescription("File processed");
	//
	// return result;
	// }

	// @Override
	// public UploadResult addKpiFile(String kpi, String user, String filePath)
	// {
	// Structure structure = this.structureService.findByKpi(kpi);
	//
	// if (structure == null) {
	//
	// KpiStructureNotFoundException ex = new KpiStructureNotFoundException();
	// this.logService.error(String.format("Structure for %s not found", kpi),
	// user, ex);
	//
	// throw ex;
	// }
	//
	// String filename = this.getFileName(filePath);
	// String indexName = filename.substring(0, filename.length() - 4);
	//
	// String indexPath = this.service.createReplaceIndex(indexName);
	//
	// service.loadKpis(indexName, filePath, structure.getHeader());
	//
	// structure.setKpiCurrentVersion(indexName);
	// structure.setLastIndexPath(indexPath);
	//
	// Structure savedStructure = this.structureService.save(structure);
	//
	// FilesIndex filesIndex = new FilesIndex();
	//
	// filesIndex.setFilePath(filePath);
	// filesIndex.setIndexPath(indexPath);
	// filesIndex.setStructure(savedStructure);
	// filesIndex.setCreatedBy(user);
	//
	// this.filesIndexService.save(filesIndex);
	//
	// UploadResult result = new UploadResult();
	//
	// result.setStatus(UPLOADSTATUS.OK);
	// result.setDescription("File processed");
	//
	// this.removeFile(filePath, user);
	//
	// this.logService.info(String.format("File %s uploaded and processed for
	// %s", filePath, indexPath), user);
	//
	// return result;
	// }
	//
	// private void removeFile(String filePath, String user) {
	// try {
	// if (!FileNameValidator.isValidFileName(filePath)) {
	// throw new StorageException("Invalid file name");
	// }
	// Files.deleteIfExists(Paths.get(filePath));
	// } catch (Exception ex) {
	// this.logService.error("Cannot delete uploaded file because doesn't
	// exists", user, ex);
	// }
	// }

}
