package cl.equifax.kpiservices.bbekpiservices;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import cl.equifax.kpiservices.bbekpiservices.kpi.KpiService;
import cl.equifax.kpiservices.bbekpiservices.kpi.KpiServiceImpl;

@Configuration
@PropertySource("${configuration-path}")
public class KpiServicesConfiguration {

	@Value("${kpi.services.lucene.path}")
	private String lucenePath;

	@Bean
	public KpiService kpiService() {
		return new KpiServiceImpl(lucenePath);
	}

}
