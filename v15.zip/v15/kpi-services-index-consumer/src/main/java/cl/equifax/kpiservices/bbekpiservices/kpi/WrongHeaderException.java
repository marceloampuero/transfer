package cl.equifax.kpiservices.bbekpiservices.kpi;

public class WrongHeaderException extends RuntimeException {

	private static final long serialVersionUID = -5904509241693391396L;

	public WrongHeaderException() {
		super("Header is not equal to first line of input file");
	}

	public WrongHeaderException(String message) {
		super(message);
	}

	public WrongHeaderException(Throwable cause) {
		super(cause);
	}

	public WrongHeaderException(String message, Throwable cause) {
		super(message, cause);
	}

	public WrongHeaderException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
