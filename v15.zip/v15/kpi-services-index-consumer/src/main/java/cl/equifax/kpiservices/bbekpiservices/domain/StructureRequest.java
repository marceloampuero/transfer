package cl.equifax.kpiservices.bbekpiservices.domain;

import java.util.Calendar;
import java.util.Date;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

public class StructureRequest {

	private static final String STRUCTURE_PATTERN = "^[A-Za-z0-9_; ]*$";
	private static final String KPI_PATTERN = "^[A-Za-z0-9_;]*$";
	private static final String INDEXPATH_PATTERN = "^[A-Za-z0-9_.\\/;\\ -]*$";
	private Integer id;

	@Size(max = 50)
	@Pattern(regexp = KPI_PATTERN)
	private String kpi;

	@Size(max = 50)
	@Pattern(regexp = STRUCTURE_PATTERN)
	private String description;

	@Size(max = 50)
	@Pattern(regexp = STRUCTURE_PATTERN)
	private String kpiCurrentVersion;

	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss", timezone = "GMT-4")
	private Date createdAt = Calendar.getInstance().getTime();

	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss", timezone = "GMT-4")
	private Date modifiedAt = Calendar.getInstance().getTime();

	@Size(max = 50)
	@Pattern(regexp = STRUCTURE_PATTERN)
	private String createdBy;

	@Size(max = 50)
	@Pattern(regexp = STRUCTURE_PATTERN)
	private String modifiedBy;

	@Size(max = 50)
	@Pattern(regexp = KPI_PATTERN)
	private String header;

	private boolean active = true;

	@Size(max = 250)
	@Pattern(regexp = INDEXPATH_PATTERN)
	private String lastIndexPath;

	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Structure [id=" + id + ", kpi=" + kpi + ", description=" + description + ", kpiCurrentVersion="
				+ kpiCurrentVersion + ", createdAt=" + createdAt + ", modifiedAt=" + modifiedAt + ", createdBy="
				+ createdBy + ", modifiedBy=" + modifiedBy + ", header=" + header + ", active=" + active
				+ ", lastIndexPath=" + lastIndexPath + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLastIndexPath() {
		return lastIndexPath;
	}

	public void setLastIndexPath(String lastIndexPath) {
		this.lastIndexPath = lastIndexPath;
	}

	public String getKpiCurrentVersion() {
		return kpiCurrentVersion;
	}

	public void setKpiCurrentVersion(String kpiCurrentVersion) {
		this.kpiCurrentVersion = kpiCurrentVersion;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Structure toStructure() {

		Structure s = new Structure();

		s.setActive(this.isActive());
		s.setCreatedAt(this.getCreatedAt());
		s.setCreatedBy(this.getCreatedBy());
		s.setDescription(this.getDescription());
		s.setHeader(this.getHeader());
		s.setId(this.getId());
		s.setKpi(this.getKpi());
		s.setKpiCurrentVersion(this.getKpiCurrentVersion());
		s.setLastIndexPath(this.getLastIndexPath());
		s.setModifiedAt(this.getModifiedAt());
		s.setModifiedBy(this.getModifiedBy());

		return s;

	}
}
