package cl.equifax.kpiservices.bbekpiservices.libs;

import org.springframework.data.domain.Page;

import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.entities.PageableDetail;

public class Paginator {

	public static PageDetail buildSerializablePage(Page<?> result) {

		PageDetail pageDetail = new PageDetail();
		PageableDetail pageableDetail = new PageableDetail();

		pageableDetail.setPage(result.getNumber());
		pageableDetail.setSize(result.getSize());
		pageDetail.setContent(result.getContent());
		pageDetail.setIsFirst(result.isFirst());
		pageDetail.setIsLast(result.isLast());
		pageDetail.setNumber(result.getNumber());
		pageDetail.setNumberOfElement(result.getNumberOfElements());
		pageDetail.setSize(result.getSize());
		pageDetail.setTotalElements(result.getTotalElements());
		pageDetail.setTotalPages(result.getTotalPages());
		pageDetail.setPageable(pageableDetail);
		pageDetail.setTotal(result.getSize());
		return pageDetail;
	}

}
