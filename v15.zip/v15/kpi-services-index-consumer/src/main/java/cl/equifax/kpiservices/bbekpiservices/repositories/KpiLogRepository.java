package cl.equifax.kpiservices.bbekpiservices.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import cl.equifax.kpiservices.bbekpiservices.entities.KpiLog;

@Repository
public interface KpiLogRepository extends CrudRepository<KpiLog, Integer> {

}
