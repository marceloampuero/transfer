package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;

import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;

public interface KpiDataService {

	KpiResponse getKpiByRut(String rut, String kpi);

	KpiResponse getKpiByRut(KpiRequest request);

	KpiResponse getKpisByRut(String rut, List<String> kpis);

}
