package cl.equifax.kpiservices.bbekpiservices.entities;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KpiServicesRequest {

	private static final String DOCUMENT_PATTERN = "^[kK0-9_. -]*$";

	@JsonProperty(required = true)
	@NotBlank
	@Pattern(regexp = DOCUMENT_PATTERN)
	private String documentNumber;

	@Valid
	private List<KpiAttribute> attributes;

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public List<KpiAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<KpiAttribute> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		return "KpiServicesRequest [documentNumber=" + documentNumber + ", attributes=" + attributes + "]";
	}

}
