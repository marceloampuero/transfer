package cl.equifax.kpiservices.ifcwebadmin.models;

import java.util.List;

public class AccessRequest {

	private List<AccessQuery> querys;

	private AccessSecurity security;

	public List<AccessQuery> getQuerys() {
		return querys;
	}

	public void setQuerys(List<AccessQuery> querys) {
		this.querys = querys;
	}

	public AccessSecurity getSecurity() {
		return security;
	}

	public void setSecurity(AccessSecurity security) {
		this.security = security;
	}

}
