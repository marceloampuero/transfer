package cl.equifax.kpiservices.ifcwebadmin.services;

import cl.equifax.kpiservices.ifcwebadmin.models.AccessRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessResponse;

public interface AuthenticationService {

	AccessResponse autenticate(AccessRequest request);
}
