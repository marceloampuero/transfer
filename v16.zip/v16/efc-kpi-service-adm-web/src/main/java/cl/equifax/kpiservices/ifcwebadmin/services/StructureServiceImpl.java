package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;

@Service
@Configurable
public class StructureServiceImpl implements StructureService {

	private static final String SERVICE_NAME = "AGY-KPI-SERVICE";
	private static final String ENDPOINTBASE = "/kpis/bbe-kpi-services-index-consumer";

	private RestTemplate restTemplate;

	private String baseUrl;
	private HttpHeaders baseHeaders;
	private MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();

	@Autowired
	public StructureServiceImpl(EurekaClient discoveryClient, RestTemplate restTemplate) {

		this.restTemplate = restTemplate;
		InstanceInfo instance = discoveryClient.getNextServerFromEureka(SERVICE_NAME, false);
		this.baseUrl = (instance.getHomePageUrl() + instance.getVIPAddress() + ENDPOINTBASE)
				.replaceAll("//kpis", "/kpis").replaceAll("//agy-kpi-service", "/agy-kpi-service");

		this.baseHeaders = new HttpHeaders();
		this.baseHeaders.setContentType(MediaType.APPLICATION_JSON);
		this.baseHeaders.set("Accept", MediaType.APPLICATION_JSON_VALUE);

		headers.add("Content-Type", "application/json");
		headers.add("Accept", "application/json");

	}

	@Override
	public List<Structure> findAll() {
		String endpoint = this.baseUrl + "/v1/structure/all";

		ResponseEntity<List<Structure>> response = restTemplate.exchange(endpoint, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Structure>>() {
				});

		return response.getBody();
	}

	@Override
	public PageDetail findAll(String filter, Integer page, Integer size) {
		String endpoint = this.baseUrl + "/v1/structure";

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint)
				.queryParam("page", page == null ? 0 : page).queryParam("size", size == null ? 10 : size)
				.queryParam("filter", filter);

		String uri = builder.toUriString();

		ResponseEntity<PageDetail> response = restTemplate.exchange(uri, HttpMethod.GET, null,
				new ParameterizedTypeReference<PageDetail>() {
				});

		return response.getBody();

	}

	@Override
	public Structure create(Structure request) {

		String endpoint = this.baseUrl + "/v1/structure/";

		HttpEntity<Structure> entity = new HttpEntity<>(request, this.baseHeaders);

		ResponseEntity<Structure> result = restTemplate.exchange(endpoint, HttpMethod.POST, entity, Structure.class);

		Structure response = result.getBody();

		return response;
	}

	@Override
	public Structure edit(Integer id, Structure request) {

		String endpoint = this.baseUrl + "/v1/structure/" + id.toString();

		HttpEntity<Structure> entity = new HttpEntity<>(request, this.baseHeaders);

		ResponseEntity<Structure> result = restTemplate.exchange(endpoint, HttpMethod.PUT, entity, Structure.class);

		Structure response = result.getBody();

		return response;
	}

	@Override
	public Structure updateIndexFile(Integer id, Integer fileId, String user) {

		String endpoint = this.baseUrl + "/v1/structure/" + id + "/" + fileId + "?user=" + user;

		HttpEntity<Structure> entity = new HttpEntity<>(this.headers);

		ResponseEntity<Structure> result = restTemplate.exchange(endpoint, HttpMethod.PUT, entity, Structure.class);

		Structure response = result.getBody();

		return response;
	}

	@Override
	public Structure delete(Integer id, String user) {

		String endpoint = this.baseUrl + "/v1/structure/" + id + "?user=" + user;

		HttpEntity<Structure> entity = new HttpEntity<>(this.headers);

		ResponseEntity<Structure> result = restTemplate.exchange(endpoint, HttpMethod.DELETE, entity, Structure.class);

		Structure response = result.getBody();

		return response;
	}

}
