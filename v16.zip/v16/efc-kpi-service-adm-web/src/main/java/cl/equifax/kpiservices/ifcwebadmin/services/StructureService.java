package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;

public interface StructureService {

	List<Structure> findAll();

	PageDetail findAll(String filter, Integer page, Integer size);

	Structure create(Structure request);

	Structure edit(Integer id, Structure request);

	Structure updateIndexFile(Integer id, Integer fileId, String user);

	Structure delete(Integer id, String user);

}