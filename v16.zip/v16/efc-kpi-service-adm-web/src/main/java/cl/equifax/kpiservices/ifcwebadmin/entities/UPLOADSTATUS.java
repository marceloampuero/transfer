package cl.equifax.kpiservices.ifcwebadmin.entities;

public enum UPLOADSTATUS {
	OK, ERROR
}
