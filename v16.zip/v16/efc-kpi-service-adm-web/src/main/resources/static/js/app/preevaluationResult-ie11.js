"use strict";

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.sort = {
		init: function init(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';

			element.onclick = function () {
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;

				bindingContext.$data.sortField(prop);
				asc = !asc;

				data.sort(function (left, right) {
					var rec1 = left;
					var rec2 = right;

					if (!asc) {
						rec1 = right;
						rec2 = left;
					}

					var props = prop.split('.');
					for (var i in props) {
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if (parenIndex > 0) {
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}

					rec1 = rec1.toString();
					rec2 = rec2.toString();

					rec1 = parseInt(rec1.replace(/\./g, '').replace(/,/g, ''), 10);
					rec2 = parseInt(rec2.replace(/\./g, '').replace(/,/g, ''), 10);

					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
			};
		}
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	function ViewModel() {
		var self = this;

		self.registerUrl = '/api/register';

		self.rut = ko.observable();
		self.name = ko.observable();
		self.results = ko.observableArray([]);
		self.modelPrice = ko.observable().extend({ formatted: 1 });
		self.model = ko.observable();
		self.registrationId = ko.observable(0);
		self.clientOrchestrationUUID = ko.observable();

		self.sortField = ko.observable();
		self.sortOrder = ko.observable(1);

		self.customerReferenceIdentifier = ko.observable();

		self.getHeaders = function () {

			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};

		self.init = function () {
			self.getPreevaluationResult();
		};

		self.sortByPie = function () {};

		self.getPreevaluationResult = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
			var couuid, req, res, json, numberFormat, newPlanList;
			return regeneratorRuntime.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							couuid = window.requestId;

							self.results([]);

							req = {
								method: 'GET',
								headers: self.getHeaders(),
								cache: 'default',
								credentials: 'same-origin'
							};
							_context.prev = 3;

							if (couuid) {
								_context.next = 6;
								break;
							}

							return _context.abrupt("return");

						case 6:
							_context.next = 8;
							return fetch(baseUrl + '/api/preevaluationresult/search/' + couuid, req);

						case 8:
							res = _context.sent;
							_context.next = 11;
							return res.json();

						case 11:
							json = _context.sent;

							if (!json.error) {
								_context.next = 16;
								break;
							}

							toastr.error("Ocurrió un error al obtener la información");
							console.error(json.error);
							return _context.abrupt("return");

						case 16:

							self.rut(json.rut);
							self.name(json.name);
							self.registrationId(json.coouid);
							self.clientOrchestrationUUID(json.coouid);
							self.model(json.model);
							self.modelPrice(json.modelPrice);

							//self.name(json.applicants.primaryConsumer.personalInformation.TRANSACTIONSEARCH[0].transactionFound.applicants.primaryConsumer.personalInformation.transactionInfo.attributes.DIC_NOMBRE_00);

							//self.modelPrice(json.applicants.primaryConsumer.personalInformation.TRANSACTIONSEARCH[0].transactionFound.applicants.primaryConsumer.personalInformation.transactionInfo.USU_VALOR_VEHIC);
							//self.model(json.applicants.primaryConsumer.personalInformation.TRANSACTIONSEARCH[0].transactionFound.applicants.primaryConsumer.personalInformation.transactionInfo.USU_MODELO);
							//self.registrationId(couuid);
							//self.clientOrchestrationUUID(couuid);

							if (json.planList) {
								numberFormat = new Intl.NumberFormat();
								newPlanList = json.planList.map(function (element) {

									element.pie = numberFormat.format(element.pie);
									element.cuota = numberFormat.format(element.cuota);

									return element;
								});


								self.results(newPlanList);
							}

							_context.next = 28;
							break;

						case 25:
							_context.prev = 25;
							_context.t0 = _context["catch"](3);

							toastr.error("Ocurrió un error al obtener la información");

						case 28:
						case "end":
							return _context.stop();
					}
				}
			}, _callee, this, [[3, 25]]);
		}));

		self.convertToNumber = function (value) {
			return value.replace(/\./g, '').replace(/,/g, '');
		};

		self.selectRegistration = function (data, id) {

			var params = '?';
			params += 'couuid=' + self.registrationId();
			params += '&selection=' + data.id;

			console.log(params);
			window.location = baseUrl + '/idpreevaluation' + params;
		};
	}

	var viewModel = new ViewModel();

	viewModel.init();

	ko.applyBindings(viewModel, $('.PreEvaluationResult')[0]);

	window.viewModel = viewModel;
});