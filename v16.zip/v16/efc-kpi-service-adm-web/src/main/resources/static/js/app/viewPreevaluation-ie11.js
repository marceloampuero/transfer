"use strict";

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	function formatRut(rut) {

		return rut.substring(0, rut.length - 1) + '-' + rut.substring(rut.length - 1);
	}

	function ViewModel() {
		var self = this;

		self.registrationId = ko.observable(0);
		self.financeId = ko.observable();
		self.person = ko.observable();
		self.rut = ko.observable();
		self.name = ko.observable();
		self.email = ko.observable();
		self.phone = ko.observable();

		self.fechaNacimiento = ko.observable();
		self.genero = ko.observable();
		self.tasa = ko.observable();
		self.scoreGmac = ko.observable();
		self.scoreEfx = ko.observable();

		self.scoreTUCurrent = ko.observable();
		self.scoreTU13meses = ko.observable();
		self.ingreso = ko.observable().extend({ formatted: 1 });

		self.reglasGatilladas = ko.observable();
		self.cuotaMax = ko.observable().extend({ formatted: 1 });

		self.isAdvanced = ko.observable(window.isAdvanced);
		self.isSales = ko.observable(window.isSales);

		self.model = ko.observable();
		self.modelPrice = ko.observable().extend({ formatted: 1 });
		self.term = ko.observable();
		self.endowment = ko.observable().extend({ formatted: 1 });
		self.fee = ko.observable().extend({ formatted: 1 });
		self.registration = ko.observable();
		self.requestStatus = ko.observable();
		self.couuid = ko.observable(window.registerId);

		self.init = function () {
			self.search();
		};

		self.back = function () {
			history.back();
		};

		self.convertDate = function (result) {

			var year = result.substring(0, 4);
			var month = result.substring(4, 6);
			var day = result.substring(6, 8);

			return day + '/' + month + '/' + year;
		};

		self.getHeaders = function () {

			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};

		self.search = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
			var req, res, json, pi;
			return regeneratorRuntime.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							req = {
								method: 'GET',
								headers: self.getHeaders(),
								cache: 'default',
								credentials: 'same-origin'
							};
							_context.prev = 1;
							_context.next = 4;
							return fetch(baseUrl + '/api/registration/searchBy/selected/' + self.couuid(), req);

						case 4:
							res = _context.sent;
							_context.next = 7;
							return res.json();

						case 7:
							json = _context.sent;
							pi = json.applicants.primaryConsumer.personalInformation;


							self.rut(formatRut(pi.chileanRut));
							self.name(pi.dic_nombre_00.toLowerCase().replace(/(^|\s)\S/g, function (l) {
								return l.toUpperCase();
							}));
							self.email(pi.USU_EMAIL === 'null' ? '' : pi.USU_EMAIL);
							self.phone(pi.USU_TELEFONO === 'null' ? '' : pi.USU_TELEFONO);
							self.model(pi.USU_MODELO);
							self.modelPrice(pi.USU_VALOR_VEHIC);

							self.ingreso(pi.USU_INGRESO);
							self.scoreTUCurrent(pi.USU_TU_CURRENT);
							self.scoreTU13meses(pi.USU_TU_13M);

							self.term(pi.serie_plazo_meses);
							self.endowment(pi.serie_pie_monto);
							self.fee(pi.serie_valor_cuota);

							self.fechaNacimiento(self.convertDate(pi.dic_fechnac2_26));
							self.genero(pi.dic_sexo_26 === 'M' ? 'Masculino' : 'Femenino');
							self.tasa(pi.serie_tasa_pct);
							self.scoreGmac(pi.serie_score_gmf);
							self.scoreEfx(pi.score_behavior);
							self.reglasGatilladas(pi.reason_code === 'null' ? '' : pi.reason_code);
							self.cuotaMax(pi.cuota_max);

							console.log(json);

							_context.next = 34;
							break;

						case 31:
							_context.prev = 31;
							_context.t0 = _context["catch"](1);

							console.error(_context.t0);

						case 34:
						case "end":
							return _context.stop();
					}
				}
			}, _callee, this, [[1, 31]]);
		}));
	}

	var viewModel = new ViewModel();

	viewModel.init();

	ko.applyBindings(viewModel, $('.ViewPreEvaluation')[0]);

	window.viewModel = viewModel;
});