package cl.equifax.kpiservices.bbekpiservices.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.equifax.kpi.kpiservices.KpiService;

@Service
public class IndexServiceImpl implements IndexService {

	private KpiService kpiService;

	@Autowired
	public IndexServiceImpl(KpiService kpiService) {
		this.kpiService = kpiService;
	}

	@Override
	public void createKpiIndex(String kpi) {
		// add hash and time-stamp

		// create and replace index

		this.kpiService.createReplaceIndex(kpi);

		// update list of indexes
		// define current index this

	}

}
