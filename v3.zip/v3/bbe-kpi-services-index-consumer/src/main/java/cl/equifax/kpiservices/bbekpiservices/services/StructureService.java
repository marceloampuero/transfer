package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

public interface StructureService {
	List<Structure> findAll();

	List<Structure> findActiveKpis();

	Page<Structure> findAll(Pageable pageable);

	Page<Structure> findByKpi(String kpi, Pageable pageable);

	Structure findByKpi(String kpi);

	Structure save(Structure structure);

	Optional<Structure> findById(Integer id);

	void delete(Integer id);

	Structure changeFileIndex(Integer id, Integer fileId);

}
