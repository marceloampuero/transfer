package cl.equifax.kpiservices.bbekpiservices.services;

public class StorageException extends RuntimeException {

	private static final long serialVersionUID = -2706419718093550601L;

	public StorageException(String message) {
		super(message);
	}

	public StorageException(String message, Throwable cause) {
		super(message, cause);
	}
}
