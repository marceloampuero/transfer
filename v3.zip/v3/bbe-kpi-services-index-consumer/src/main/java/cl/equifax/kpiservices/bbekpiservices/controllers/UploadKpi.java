package cl.equifax.kpiservices.bbekpiservices.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.UploadResult;
import cl.equifax.kpiservices.bbekpiservices.services.KpiDataService;
import cl.equifax.kpiservices.bbekpiservices.services.StorageFileNotFoundException;
import cl.equifax.kpiservices.bbekpiservices.services.StorageService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1+"/upload")
public class UploadKpi {

	private StorageService storageService;
	private KpiDataService service;

	@Autowired
	public UploadKpi(StorageService storageService, KpiDataService service) {
		this.storageService = storageService;
		this.service = service;
	}

	@ApiOperation(value = "Permite subir un archivo csv para un kpi determinado")
	@CrossOrigin
	@PostMapping("/")
	@ResponseBody
	public UploadResult kpiFileUpload(@RequestParam MultipartFile file, @RequestParam String kpi,
			@RequestParam String user) {

		String filename = this.storageService.store(kpi, file);
		return this.service.addKpiFile(kpi, user, filename);

	}

	@ExceptionHandler(StorageFileNotFoundException.class)
	public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
		return ResponseEntity.notFound().build();
	}

}
