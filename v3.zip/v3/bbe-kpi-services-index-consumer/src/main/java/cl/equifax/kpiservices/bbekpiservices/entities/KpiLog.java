package cl.equifax.kpiservices.bbekpiservices.entities;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class KpiLog {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "KPILOG_SEQ")
	@SequenceGenerator(sequenceName = "kpilog_seq", allocationSize = 1, name = "KPILOG_SEQ")
	private Integer id;

	private String user;

	private LogLevel level = LogLevel.INFO;

	private String details;

	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss", timezone = "GMT-4")
	private Date createdAt = Calendar.getInstance().getTime();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public LogLevel getLevel() {
		return level;
	}

	public void setLevel(LogLevel level) {
		this.level = level;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

}
