package cl.equifax.kpiservices.bbekpiservices.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

@Repository
public interface StructureRepository extends CrudRepository<Structure, Integer> {

	List<Structure> findAll();

	List<Structure> findByKpiCurrentVersionNotNullAndActiveTrue();

	Page<Structure> findAll(Pageable pageable);

	Structure findByKpi(String kpi);

	Page<Structure> findByKpiContainingIgnoreCase(String kpi, Pageable pageable);

}
