package cl.equifax.kpiservices.bbekpiservices.services;

import cl.equifax.kpiservices.bbekpiservices.entities.LogLevel;

public interface LogService {

	void log(LogLevel level, String details, String user);

	void info(String details, String user);

	void error(String details, String user);

}
