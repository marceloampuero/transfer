package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.repositories.FilesIndexRepository;
import cl.equifax.kpiservices.bbekpiservices.repositories.StructureRepository;

@Service
public class FilesIndexServiceImpl implements FilesIndexService {

	private FilesIndexRepository repository;
	private StructureRepository structureRepository;

	@Autowired
	public FilesIndexServiceImpl(FilesIndexRepository repository, StructureRepository structureRepository) {

		this.repository = repository;
		this.structureRepository = structureRepository;
	}

	@Override
	public List<FilesIndex> findAll() {

		return this.repository.findAll();
	}

	@Override
	public List<FilesIndex> findByKpi(String kpi) {

		Structure structure = this.structureRepository.findByKpi(kpi);

		return this.repository.findByStructure(structure);
	}

	@Override
	public List<FilesIndex> findByStructure(Structure structure) {
		return this.repository.findByStructure(structure);
	}

	@Override
	public FilesIndex save(FilesIndex kpiStructure) {

		return this.repository.save(kpiStructure);
	}

	@Override
	public Optional<FilesIndex> findById(Integer id) {

		return this.repository.findById(id);
	}

	@Override
	public void delete(Integer id) {
		this.repository.deleteById(id);
	}

	@Override
	public Page<FilesIndex> findAll(Pageable pageable) {

		return this.repository.findAll(pageable);
	}

	@Override
	public Page<FilesIndex> findByKpi(String kpi, Pageable pageable) {

		Structure structure = this.structureRepository.findByKpi(kpi);

		return this.repository.findByStructure(structure, pageable);
	}

	@Override
	public Page<FilesIndex> findByFilePath(String filePath, Pageable pageable) {
		return this.repository.findByFilePathContainingIgnoreCase(filePath, pageable);
	}

	@Override
	public Page<FilesIndex> findByKpiAndFilePath(String kpi, String filePath, Pageable pageable) {

		Structure structure = this.structureRepository.findByKpi(kpi);

		return this.repository.findByStructureAndFilePathContainingIgnoreCase(structure, filePath, pageable);

	}

}
