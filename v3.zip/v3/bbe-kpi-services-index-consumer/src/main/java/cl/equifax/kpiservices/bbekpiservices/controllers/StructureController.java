package cl.equifax.kpiservices.bbekpiservices.controllers;

import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.libs.Paginator;
import cl.equifax.kpiservices.bbekpiservices.services.StructureService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1+"/structure")
public class StructureController {

	private StructureService service;

	@Autowired
	public StructureController(StructureService service) {

		this.service = service;
	}

	@ApiOperation(value = "Obtiene la lista paginada filtradas por kpi de estructuras de KPIs")
	@GetMapping
	@ResponseBody
	public PageDetail home(@RequestParam(required = false) String filter,
			@RequestParam(defaultValue = "0", required = false) Integer page,
			@RequestParam(defaultValue = "10", required = false) Integer size) {

		Pageable pageable = PageRequest.of(page, size);

		if (filter != null && !filter.isEmpty()) {
			Page<Structure> result = this.service.findByKpi(filter, pageable);
			return Paginator.buildSerializablePage(result);
		}

		Page<Structure> result = this.service.findAll(pageable);
		return Paginator.buildSerializablePage(result);
	}

	@ApiOperation(value = "Obtiene la lista actualizada de estructuras de KPIs")
	@GetMapping("/all")
	@ResponseBody
	public List<Structure> getAll() {

		return this.service.findAll();
	}

	@ApiOperation(value = "Obtiene una estructura de kpi por Id ")
	@GetMapping("/{id}")
	@ResponseBody
	public Optional<Structure> getById(@PathVariable(value = "id") Integer id) {

		return this.service.findById(id);
	}

	@ApiOperation(value = "Actualiza una estructura")
	@PutMapping("/{id}")
	@ResponseBody
	public ResponseEntity<Structure> update(@PathVariable(value = "id") Integer id, @RequestBody Structure structure) {

		Optional<Structure> optStructure = service.findById(id);

		if (!optStructure.isPresent()) {
			return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		}

		Structure savedStructure = optStructure.get();

		savedStructure.setActive(structure.isActive());
		savedStructure.setDescription(structure.getDescription());
		savedStructure.setHeader(structure.getHeader());
		savedStructure.setKpi(structure.getKpi());
		savedStructure.setModifiedBy(structure.getModifiedBy());
		savedStructure.setModifiedAt(Calendar.getInstance().getTime());

		this.service.save(savedStructure);

		return new ResponseEntity<>(savedStructure, HttpStatus.OK);

	}

	@ApiOperation(value = "Cambia el archivo de índices de una estructura")
	@PutMapping("/{id}/{fileId}")
	@ResponseBody
	public Structure updateIndexFile(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId) {

		return this.service.changeFileIndex(id, fileId);

	}

	@ApiOperation(value = "Crea una estructura para un KPI")
	@PostMapping
	@ResponseBody
	public ResponseEntity<Structure> create(@Valid @RequestBody Structure structure) {

		structure.setKpi(structure.getKpi().toUpperCase());
		Structure savedStructure = service.save(structure);

		return new ResponseEntity<>(savedStructure, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Elimina una estructura de KPI")
	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity delete(@PathVariable(value = "id") Integer id) {

		this.service.delete(id);

		return new ResponseEntity(HttpStatus.OK);

	}

}
