package cl.equifax.kpiservices.bbekpiservices.services;

public class StorageFileNotFoundException extends StorageException {

	private static final long serialVersionUID = -4652485249847643932L;

	public StorageFileNotFoundException(String message) {
		super(message);
	}

	public StorageFileNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}
