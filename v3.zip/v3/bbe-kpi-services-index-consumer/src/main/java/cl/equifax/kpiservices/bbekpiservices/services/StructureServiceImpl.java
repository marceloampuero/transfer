package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.repositories.FilesIndexRepository;
import cl.equifax.kpiservices.bbekpiservices.repositories.StructureRepository;

@Service
public class StructureServiceImpl implements StructureService {

	private StructureRepository repository;
	private FilesIndexRepository filesIndexRepository;

	@Autowired
	public StructureServiceImpl(StructureRepository repository, FilesIndexRepository filesIndexRepository) {
		this.repository = repository;
		this.filesIndexRepository = filesIndexRepository;

	}

	@Override
	public List<Structure> findAll() {

		return this.repository.findAll();
	}

	@Override
	public Structure save(Structure structure) {

		return this.repository.save(structure);

	}

	@Override
	public void delete(Integer id) {

		this.repository.deleteById(id);

	}

	@Override
	public Optional<Structure> findById(Integer id) {

		return this.repository.findById(id);
	}

	@Override
	public Structure findByKpi(String kpi) {

		return this.repository.findByKpi(kpi);
	}

	private String getLastPartFromPath(String path) {

		return path.substring(path.lastIndexOf('/') + 1);

	}

	@Override
	public Structure changeFileIndex(Integer id, Integer fileId) {

		Optional<Structure> structureOpt = this.findById(id);

		Optional<FilesIndex> filesIndexOpt = this.filesIndexRepository.findById(fileId);

		if (!structureOpt.isPresent() || !filesIndexOpt.isPresent()) {
			return null;
		}

		Structure structure = structureOpt.get();
		FilesIndex filesIndex = filesIndexOpt.get();

		structure.setLastIndexPath(filesIndex.getIndexPath());
		structure.setKpiCurrentVersion(this.getLastPartFromPath(filesIndex.getIndexPath()));

		this.repository.save(structure);

		return structure;
	}

	@Override
	public Page<Structure> findAll(Pageable pageable) {

		return this.repository.findAll(pageable);
	}

	@Override
	public Page<Structure> findByKpi(String kpi, Pageable pageable) {

		return this.repository.findByKpiContainingIgnoreCase(kpi, pageable);
	}

	@Override
	public List<Structure> findActiveKpis() {

		return this.repository.findByKpiCurrentVersionNotNullAndActiveTrue();
	}

}
