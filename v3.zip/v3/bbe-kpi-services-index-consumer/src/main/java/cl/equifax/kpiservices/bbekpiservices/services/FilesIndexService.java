package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

public interface FilesIndexService {

	List<FilesIndex> findAll();

	Page<FilesIndex> findAll(Pageable pageable);

	List<FilesIndex> findByKpi(String kpi);

	Page<FilesIndex> findByFilePath(String filePath, Pageable pageable);

	Page<FilesIndex> findByKpi(String kpi, Pageable pageable);

	Page<FilesIndex> findByKpiAndFilePath(String kpi, String filePath, Pageable pageable);

	List<FilesIndex> findByStructure(Structure structure);

	FilesIndex save(FilesIndex kpiStructure);

	Optional<FilesIndex> findById(Integer id);

	void delete(Integer id);

}
