package cl.equifax.kpiservices.bbekpiservices.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiAttribute;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;
import cl.equifax.kpiservices.bbekpiservices.services.KpiDataService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1 + "/kpis")
public class KpiController {

	private KpiDataService service;

	@Autowired
	public KpiController(KpiDataService service) {
		this.service = service;
	}

	@ApiOperation(value = "Permite consultar por el o los kpis de un rut determinado")
	@PostMapping
	@ResponseBody
	public KpiResponse kpisByRut(@RequestBody KpiRequest request) {

		request.getKpiServices().setDocumentNumber(request.getKpiServices().getDocumentNumber().toUpperCase());

		List<KpiAttribute> attributes = request.getKpiServices().getAttributes();

		if (attributes != null && !attributes.isEmpty()) {
			KpiAttribute attribute = attributes.get(0);

			if (attribute.getVariableName() != null && !attribute.getVariableName().isEmpty()) {
				attribute.setVariableName(attribute.getVariableName().toUpperCase());
			}
		}

		return this.service.getKpiByRut(request);
	}

}
