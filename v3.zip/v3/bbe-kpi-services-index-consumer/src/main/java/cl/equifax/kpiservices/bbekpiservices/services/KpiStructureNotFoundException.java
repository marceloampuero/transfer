package cl.equifax.kpiservices.bbekpiservices.services;

public class KpiStructureNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 2842840981289103760L;

	public KpiStructureNotFoundException() {
		super("Kpi Structure Not Found");
	}

	public KpiStructureNotFoundException(String message) {
		super(message);

	}

	public KpiStructureNotFoundException(Throwable cause) {
		super(cause);

	}

	public KpiStructureNotFoundException(String message, Throwable cause) {
		super(message, cause);

	}

	public KpiStructureNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
