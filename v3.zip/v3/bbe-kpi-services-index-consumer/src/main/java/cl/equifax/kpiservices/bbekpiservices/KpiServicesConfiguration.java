package cl.equifax.kpiservices.bbekpiservices;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cl.equifax.kpi.kpiservices.KpiService;
import cl.equifax.kpi.kpiservices.KpiServiceImpl;
import cl.equifax.kpiservices.bbekpiservices.services.StorageProperties;

@Configuration
@EnableConfigurationProperties(StorageProperties.class)
public class KpiServicesConfiguration {

	@Value("${kpi.services.lucene.path}")
	private String lucenePath;

	@Bean
	public KpiService kpiService() {
		return new KpiServiceImpl(lucenePath);
	}

}
