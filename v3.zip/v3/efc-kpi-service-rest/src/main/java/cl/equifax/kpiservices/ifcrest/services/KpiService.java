package cl.equifax.kpiservices.ifcrest.services;

import cl.equifax.kpiservices.ifcrest.entities.KpiRequest;
import cl.equifax.kpiservices.ifcrest.entities.KpiResponse;

public interface KpiService {

	KpiResponse getKpiByRut(KpiRequest request);

}
