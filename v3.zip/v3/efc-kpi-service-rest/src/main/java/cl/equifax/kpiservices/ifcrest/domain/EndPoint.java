package cl.equifax.kpiservices.ifcrest.domain;

public final class EndPoint {
	public static final String VERSION_1 = "/v1";
	
	private EndPoint() {

	}
}
