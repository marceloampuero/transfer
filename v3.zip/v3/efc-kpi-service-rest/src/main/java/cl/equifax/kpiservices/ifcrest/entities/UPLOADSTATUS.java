package cl.equifax.kpiservices.ifcrest.entities;

public enum UPLOADSTATUS {
	OK, ERROR
}
