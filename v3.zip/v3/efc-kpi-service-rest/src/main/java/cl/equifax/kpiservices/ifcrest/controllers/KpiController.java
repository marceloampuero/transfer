package cl.equifax.kpiservices.ifcrest.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.ifcrest.entities.KpiRequest;
import cl.equifax.kpiservices.ifcrest.entities.KpiResponse;
import cl.equifax.kpiservices.ifcrest.services.KpiService;

@RestController
@RequestMapping("/v1/kpis")
public class KpiController {

	private KpiService service;

	@Autowired
	public KpiController(KpiService service) {
		this.service = service;
	}

	@PostMapping
	@ResponseBody
	public KpiResponse kpisByRut(@RequestBody KpiRequest request) {

		return this.service.getKpiByRut(request);
	}

}
