package cl.equifax.kpiservices.ifcrest.entities;

public class UploadResult {

	private UPLOADSTATUS status;
	private String description;

	public UPLOADSTATUS getStatus() {
		return status;
	}

	public void setStatus(UPLOADSTATUS status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "UploadResult [status=" + status + ", description=" + description + "]";
	}

}
