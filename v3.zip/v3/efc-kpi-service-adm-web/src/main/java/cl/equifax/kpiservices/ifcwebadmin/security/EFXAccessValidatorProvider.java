package cl.equifax.kpiservices.ifcwebadmin.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Component;

import cl.equifax.kpiservices.ifcwebadmin.models.AccesoAplicacion;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessQuery;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessResponse;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessSecurity;
import cl.equifax.kpiservices.ifcwebadmin.services.AuthenticationService;

@Component
public class EFXAccessValidatorProvider implements AuthenticationProvider {

	@Autowired
	private AuthenticationService authenticationService;

	private static final String APPLICATION_NAME = "KPISERV";

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String username = authentication.getName();
		String password = authentication.getCredentials().toString();

		AccessRequest request = new AccessRequest();

		List<AccessQuery> querys = new ArrayList<>();

		AccessQuery accessQuery = new AccessQuery();

		accessQuery.setAplicacion(APPLICATION_NAME);

		querys.add(accessQuery);

		request.setQuerys(querys);

		AccessSecurity security = new AccessSecurity();

		security.setUsername(username);
		security.setPassword(password);

		request.setSecurity(security);

		AccessResponse response = this.authenticationService.autenticate(request);

		List<AccesoAplicacion> listaAccesos = response.getAccesoPorAplicacions();

		if (listaAccesos == null || listaAccesos.isEmpty()) {
			throw new BadCredentialsException("Bad Credentials. User doesn't have access");
		}

		AccesoAplicacion acceso = listaAccesos.get(0);

		String accesoAplicacion = acceso.getAccesosPorAplicacion();

		String roles = "";

		if (accesoAplicacion.charAt(0) == 'S') {
			roles += "P01";
		}

		if (accesoAplicacion.charAt(1) == 'S') {
			roles += ",P02";
		}

		if (accesoAplicacion.charAt(2) == 'S') {
			roles += ",P03";
		}

		if (roles.startsWith(",")) {
			roles = roles.substring(1);
		}

		if (roles.isEmpty()) {
			throw new BadCredentialsException("Bad Credentials. User don't have a role");
		}

		return new UsernamePasswordAuthenticationToken(username, password,
				AuthorityUtils.commaSeparatedStringToAuthorityList(roles));

	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
