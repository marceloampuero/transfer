package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cl.equifax.kpiservices.ifcwebadmin.entities.FilesIndex;
import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;

@FeignClient(name = "agy-kpi-service")
public interface FileService {

	@GetMapping("/kpis/v1/filesindex/all")
	List<FilesIndex> findAll();

	@GetMapping("/kpis/v1/filesindex")
	PageDetail findAll(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size,
			@RequestParam(required = false, name = "kpi") String kpi);
}
