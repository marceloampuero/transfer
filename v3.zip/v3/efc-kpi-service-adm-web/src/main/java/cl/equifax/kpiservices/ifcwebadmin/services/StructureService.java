package cl.equifax.kpiservices.ifcwebadmin.services;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;

@FeignClient(name = "agy-kpi-service")
public interface StructureService {

	@GetMapping("/kpis/v1/structure/all")
	List<Structure> findAll();

	@GetMapping("/kpis/v1/structure/")
	PageDetail findAll(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size);

	@PostMapping("/kpis/v1/structure/")
	@ResponseBody
	Structure create(@RequestBody Structure request);

	@PutMapping("/kpis/v1/structure/{id}")
	@ResponseBody
	Structure edit(@PathVariable(value = "id") Integer id, @RequestBody Structure request);

	@PutMapping("/kpis/v1/structure/{id}/{fileId}")
	@ResponseBody
	Structure updateIndexFile(@PathVariable(value = "id") Integer id, @PathVariable(value = "fileId") Integer fileId);

	@DeleteMapping("/kpis/v1/structure/{id}")
	@ResponseBody
	Structure delete(@PathVariable(value = "id") Integer id);

}