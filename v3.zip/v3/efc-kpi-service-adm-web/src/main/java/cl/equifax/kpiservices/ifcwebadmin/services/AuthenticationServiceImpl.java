package cl.equifax.kpiservices.ifcwebadmin.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

import cl.equifax.kpiservices.ifcwebadmin.models.AccessRequest;
import cl.equifax.kpiservices.ifcwebadmin.models.AccessResponse;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	private static final String SERVICE_NAME = "BBE-ACCESSVALIDATOR-REST";
	private static final String ENDPOINT = "/bbe-accessvalidator-rest/v1/accessstatus";

	@Autowired
	private EurekaClient discoveryClient;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public AccessResponse autenticate(AccessRequest request) {

		InstanceInfo instance = discoveryClient.getNextServerFromEureka(SERVICE_NAME, false);
		String kpiServiceUrl = instance.getHomePageUrl() + ENDPOINT;

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<AccessRequest> entity = new HttpEntity<>(request, headers);

		ResponseEntity<AccessResponse> result = restTemplate.exchange(kpiServiceUrl, HttpMethod.POST, entity,
				AccessResponse.class);

		AccessResponse response = result.getBody();

		return response;
	}

}
