package cl.equifax.kpiservices.ifcwebadmin.controllers.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.ifcwebadmin.entities.PageDetail;
import cl.equifax.kpiservices.ifcwebadmin.entities.Structure;
import cl.equifax.kpiservices.ifcwebadmin.services.StructureService;

@RestController
@RequestMapping("/api/structures")
public class StructureApiController {

	@Autowired
	StructureService structureService;

	@GetMapping("/all")
	public List<Structure> findAll() {

		return structureService.findAll();
	}

	@GetMapping()
	public PageDetail findAllPaginate(@RequestParam(required = false, name = "filter") String filter,
			@RequestParam(defaultValue = "0", required = false, name = "page") Integer page,
			@RequestParam(defaultValue = "10", required = false, name = "size") Integer size) {

		return structureService.findAll(filter, page, size);
	}

	@PostMapping
	public Structure create(@Valid @RequestBody Structure structure) {

		return structureService.create(structure);

	}

	@PutMapping("/{id}")
	public Structure put(@PathVariable(value = "id") Integer id, @RequestBody Structure request) {

		return structureService.edit(id, request);

	}

	@PutMapping("/{id}/{fileId}")
	public Structure updateIndexFile(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId) {

		return structureService.updateIndexFile(id, fileId);

	}

	@DeleteMapping("/{id}")
	public Structure delete(@PathVariable(value = "id") Integer id) {

		return structureService.delete(id);
	}

}
