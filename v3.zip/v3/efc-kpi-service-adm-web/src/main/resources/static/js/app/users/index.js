$(document)
		.ready(
				function($) {

					function User(parent) {
						var self = this;

						self.id = ko.observable();
						self.userName = ko.observable();
						self.name = ko.observable();
						self.email = ko.observable();
						self.roles = ko.observableArray([]);
						self.selectedRole = ko.observable();

						self.addRole = function(vm) {

							updateRolelist(vm.selectedRole());

						};
						
						self.removeRole = function (role) {
							
							self.roles.remove(role);
							
						};

						function updateRolelist(role) {
							if (!role || self.roles().indexOf(role) !== -1) {
								return;
							}
							self.roles.push(role);
						}
					}

					function Role() {
						var self = this;

						self.id = ko.observable();
						self.code = ko.observable();
						self.name = ko.observable();
					}

					function Pagination() {

						var self = this;

						self.totalPages = ko.observable(0);
						self.totalElements = ko.observable(0);
						self.last = ko.observable(false);
						self.first = ko.observable(true);
						self.size = ko.observable(0);
						self.number = ko.observable(1);
						self.numberOfElements = ko.observable(0);

						self.hasNext = ko.pureComputed(function() {
							return self.number() < self.totalPages();
						}, self);

						self.hasPrevious = ko.pureComputed(function() {
							return self.number() > 1;
						}, self);

					}

					function ViewModel() {
						var self = this;

						self.url = '/api/users';
						self.pagination = ko.observable(new Pagination());
						self.list = ko.observableArray([]);
						self.roleList = ko.observableArray([]);

						self.size = ko.observable(10);
						self.filter = ko.observable('');
						self.current = ko.observable(new User());

						self.isCreateVisible = ko.observable(false);
						self.isEditVisible = ko.observable(false);
						self.isListVisible = ko.observable(true);

						self.showCreate = function() {
							self.current(new User());
							self.isCreateVisible(true);
							self.isEditVisible(false);
							self.isListVisible(false);
							self.getRoles();
						};

						self.showEdit = function(item) {

							self.current(item);
							self.isCreateVisible(false);
							self.isEditVisible(true);
							self.isListVisible(false);
							self.getRoles();
						};

						self.enableSave = ko.pureComputed(function() {
							return self.current().name()
									&& self.current().userName()
									&& self.current().email();
						}, self);

						self.showList = function() {
							self.isCreateVisible(false);
							self.isEditVisible(false);
							self.isListVisible(true);

							self.current(new User());

						};

						self.convertToUser = function(element, self) {

							var user = new User(self);

							user.userName(element.userName);
							user.id(element.id);
							user.roles(element.roles);
							user.email(element.email);
							user.name(element.name);

							return user;
						};

						self.convertToRole = function(element, self) {

							var role = new Role(self);

							role.id(element.id);
							role.name(element.name);
							role.code(element.code);

							return role;
						};

						self.save = function(vm) {

							var type = 'POST';
							var url = self.url;

							if (vm.id()) {
								url = self.url + "/" + vm.id();
								type = 'PUT';
							}

							var body = ko.toJSON(self.current);

							$.ajax({
								url : url,
								contentType : "application/json",
								data : body,
								type : type,
								success : function(result) {
									window.location.href = "/users";
								}
							});

						}

						self.remove = function(vm) {

							$.ajax({
								url : self.url + "/" + vm.id(),
								contentType : "application/json",
								type : 'DELETE',
								success : function(result) {
									self.getAll(0);
								}
							});

						}
						
						

						self.getAll = function(page) {

							var requestUrl = self.url
									+ `?page=${page}&size=${self.size()}&filter=${self.filter()}`;
							$
									.ajax({
										url : requestUrl,
										type : 'GET',
										success : function(data) {

											let page = new Pagination();
											page.size(data.size);
											page.number(data.number + 1);
											page
													.numberOfElements(data.numberOfElements);
											page.totalPages(data.totalPages);
											page
													.totalElements(data.totalElements);
											page.first(data.first);
											page.last(data.last);
											self.pagination(page);
											var list = [];

											data.content.map(function(item) {
												var user = self.convertToUser(
														item, self);
												list.push(user);
											})

											self.list(list);
										}
									});

						};

						self.getRoles = function(page) {

							var requestUrl = "/api/roles/all";
							$.ajax({
								url : requestUrl,
								type : 'GET',
								success : function(data) {
									var list = [];

									data.map(function(item) {
										var user = self.convertToRole(item,
												self);
										list.push(user);
									})

									self.roleList(list);
								}
							});

						};

						self.updateList = function() {
							self.getAll(self.pagination().number() - 1)
						};

						self.searchFilter = function() {

							self.getAll(0);
						};

						self.next = function() {

							if (self.pagination().last()) {
								return;
							}

							if (self.pagination().number() < self.pagination()
									.totalPages()) {
								self.getAll(self.pagination().number());
							}

						};

						self.previous = function() {

							if (self.pagination().first()) {
								return;
							}

							self.getAll(self.pagination().number() - 2);

						};

						self.init = function() {

							self.getAll(0);

						};

					}

					var viewModel = new ViewModel();
					viewModel.init();
					ko.applyBindings(viewModel, $('.Users')[0]);
					window.viewModel = viewModel;

				});