$(document).ready(function($){
	
	window.baseUrl = location.href.substring(0,location.href.search('gmac-web-ic') + 11);
	
	toastr.options = {
	  "closeButton": false,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-bottom-full-width",
	  "preventDuplicates": false,
	  "onclick": null,
	  "showDuration": "300",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};
	
	ko.bindingHandlers.sort = {
		init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var asc = false;
			element.style.cursor = 'pointer';
			
			element.onclick = function(){
				var value = valueAccessor();
				var prop = value.prop;
				var data = value.arr;
				
				
				
				bindingContext.$data.sortField(prop);
				asc = !asc;
				
				data.sort(function(left, right){
					var rec1 = left;
					var rec2 = right;
					
					if(!asc) {
						rec1 = right;
						rec2 = left;
					}
					
					var props = prop.split('.');
					for(var i in props){
						var propName = props[i];
						var parenIndex = propName.indexOf('()');
						if(parenIndex > 0){
							propName = propName.substring(0, parenIndex);
							rec1 = rec1[propName]();
							rec2 = rec2[propName]();
						} else {
							rec1 = rec1[propName];
							rec2 = rec2[propName];
						}
					}
					
					rec1 = rec1.toString();
					rec2 = rec2.toString();
					
					rec1 = parseInt(rec1.replace(/\./g,'').replace(/,/g,''),10);
					rec2 = parseInt(rec2.replace(/\./g,'').replace(/,/g,''),10);
					
					return rec1 == rec2 ? 0 : rec1 < rec2 ? -1 : 1;
				});
	        };
	    }
	};
	
	ko.bindingHandlers.executeOnEnter = {
		    init: function (element, valueAccessor, allBindings, viewModel) {

		        var bindings = allBindings();
		        $(element).keypress(function (event) {
		            var keyCode = (event.which ? event.which : event.keyCode);
		            if (keyCode === 13) {
		                bindings.executeOnEnter.call(viewModel, viewModel, element);
		                return false;
		            }
		            return true;
		        });
		    },
		    update: function () {}
	};
	
	

	ko.extenders.formatted = function(target, precision) {
	    //create a writable computed observable to intercept writes to our observable
	    var result = ko.pureComputed({
	        read: function () {
	        	
	        	if(!(target && target())){
	        		return '';
	        	}
	        	
	        	var newValue = target().toString();
	        	var val = parseInt(newValue.replace(/\./g,'').replace(/,/g,''));
	        	
	        	if (isNaN(val)){
	        		val = '';
	        	}
	        	
	        	var numberFormat = new Intl.NumberFormat();
	        	
	        	var nf = numberFormat.format(val);
	        	
	            return nf;
	        },  //always return the original observables value
	        write: target
	    }).extend({ notify: 'always' });
	 
	    //initialize with current value to make sure it is rounded appropriately
	    result(target());
	 
	    //return the new computed observable
	    return result;
	};
	
	var getHeaders = function () {
		
		return {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'X-Requested-With': 'XMLHttpRequest',
			'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
		};
	};
	
	function Pagination () {
		
		var self = this;
		
		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);
		
		self.hasNext = ko.pureComputed(function() {
		    return self.number() < self.totalPages();
		}, self);
		
		self.hasPrevious = ko.pureComputed(function() {
		    return self.number() > 1;
		}, self);
		
	
	}
	
	
	
	function Franchisee(){
		var self = this;
		
		self.id = ko.observable();
		self.code = ko.observable();
		self.name = ko.observable();
		
	}
	
	
	function Entity(){
		var self = this;
		
		self.id = ko.observable();
		self.code = ko.observable();
		self.name = ko.observable();
		self.franchisee = ko.observable();
		
		
	}
	
	
	
	function ViewModel(){
		var self = this;
		
		self.url = '/api/branches';
		
		self.pagination = ko.observable(new Pagination());
		//self.forms = ko.observable(new FormsView());
		
		self.list = ko.observableArray([]);
		
		self.franchiseeList = ko.observableArray([]);
		
		self.size = ko.observable(10);
		self.filter = ko.observable('');
		
		//self.forms().current(new Entity());
		
		self.isCreateVisible = ko.observable(false);
		self.isEditVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		self.current = ko.observable(new Entity());
		self.currentEdit = ko.observable(new Entity());
		
		self.showCreate = function () {
			self.current(new Entity());
			self.isCreateVisible(true);
			self.isEditVisible(false);
			self.isListVisible(false);
			
			
		};
		
		self.showEdit = function (item) {
			
			self.currentEdit(item);
			
			self.isCreateVisible(false);
			self.isEditVisible(true);
			self.isListVisible(false);
			
			
		};
		
		self.showList = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(true);
			
			self.current(new Entity());
			
		};
		
		self.init = function() {
			self.getFranchisees();
			self.getAll(0);
			
		};
		
		
		self.searchFilter = function() {
			
			self.getAll(0);
		};
		
		self.updateList = function(){
			self.getAll(self.pagination().number()-1)
		};
		
		
		self.getAll = async function(page) {
			
			var requestUrl = baseUrl + self.url + `?page=${page}&size=${self.size()}&filter=${self.filter()}`;
			
			self.list([]);
		    
		    let req = {
				method: 'GET',
				headers: getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
		    
		    try {
		    	const res =  await fetch(requestUrl, req);
			    const data = await res.json();
			    
			    let page = new Pagination();
			    page.size(data.size);
			    page.number(data.number + 1);
			    page.numberOfElements(data.numberOfElements);
			    page.totalPages(data.totalPages);
			    page.totalElements(data.totalElements);
			    page.first(data.first);
			    page.last(data.last);
			  
			    self.pagination(page);
			    
			    let contents = [];
				  
				  data.content.forEach(element => {
					  let obj = new Entity();
					  
					  obj.id(element.id);
					  obj.code(element.code);
					  obj.name(element.name);
					  
//					  let fr = new Franchisee();
//				      fr.id(element.franchisee.id);
//					  fr.code(element.franchisee.code);
//					  fr.name(element.franchisee.name);
					  
					  //obj.franchisee(fr);
					  
					  //debugger;
					  var fr = self.findFranchisee(element.franchisee.id);
					  obj.franchisee(fr);
					  
					  contents.push(obj);
					  
				  });
				  
				  self.list(contents);
			    
		    }catch (e){
		    	console.error(e);
		    }
		    
		    	
		};
		
		self.findFranchisee = function(id){
			var frList = self.franchiseeList();
			var result = frList.find(x => x.id == id);
				
			return result;
			
		}
		
		self.getFranchisees = async function(page) {
			
			var requestUrl = baseUrl + '/api/franchisees/all';
			
			self.franchiseeList([]);
		    
		    let req = {
				method: 'GET',
				headers: getHeaders(),
				cache: 'default',
				credentials: 'same-origin'
			};
		    
		    try {
		    	const res =  await fetch(requestUrl, req);
			    const data = await res.json();
			    
//			    data.forEach(element => {
//			    	
//			    	let obj = new Franchisee();
//			    	obj.id(element.id);
//			    	obj.code(element.code);
//				obj.name(element.name);
//			    	
//			    });
			    
			    self.franchiseeList(data);
			    
			    
		    }catch (e){
		    	console.error(e);
		    }
		    
		    	
		};
		
		self.next = function () {
			
			if (self.pagination().last()){
				return;
			}
			
			if (self.pagination().number() < self.pagination().totalPages()){
				self.getAll(self.pagination().number());
			}
			
		};
		
		self.previous = function () {
			
			if (self.pagination().first()){
				return;
			}
			
			self.getAll(self.pagination().number()-2);
			
		};
		
		self.enableSave = ko.pureComputed(function() {
			return self.current().code() && self.current().name();
		}, self);
		
		self.enableUpdate = ko.pureComputed(function() {
			return self.currentEdit().code() && self.currentEdit().name();
		}, self);
		
		
		
		self.save = async function(){
			
			var requestUrl = baseUrl + self.url;
			
			var body = JSON.stringify({
				code: self.current().code(),
				name: self.current().name(),
				franchisee: self.current().franchisee()
			});
			
			var req = {
				method: 'POST',
				headers: getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al Guardar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Creación Exitosa');
		      self.current(new Entity());
		      
		      self.getAll(0);
		      self.showList();
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al Guardar');

		    }
			
			
		}
		
		self.update = async function(){
			
			var requestUrl = baseUrl + self.url + '/' + self.currentEdit().id();
			
			var body = JSON.stringify({
				id:self.currentEdit().id(),
				code: self.currentEdit().code(),
				name: self.currentEdit().name(),
				franchisee: self.currentEdit().franchisee()
			});
			
			var req = {
				method: 'PUT',
				headers: getHeaders(),	
				cache: 'default',
				body : body,
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al Actualizar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Actualización Exitosa');
		      self.current(new Entity());
		      
		      self.getAll(0);
		      self.showList();
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al Actualizar');

		    }
			
			
		}
		
		self.deleteEntity = async function (element) {
			var requestUrl = baseUrl + self.url + '/' + element.id();
			
			var req = {
				method: 'DELETE',
				headers: getHeaders(),	
				cache: 'default',
				credentials: 'same-origin'
			};

		    try {
		      let result = await fetch(requestUrl, req);
		      let model = await result.json();
		      
		      if (model.error){
		    	  toastr.error('Ocurrió un error al eliminar');
		    	  return;
		      }
		      
		      		      
		      toastr.success('Eliminación Exitosa');
		      
		      self.getAll(0);
		      
		     
		    } catch (error) {
		      console.error('Error en request:', error);
		      toastr.error('Ocurrió un error al eliminar');

		    }
		};
		
		self.remove = async function (element) {
			
			bootbox.confirm({
			    message: "¿Está seguro que desea eliminar la sucursal?",
			    buttons: {
			        confirm: {
			            label: 'Sí',
			            className: 'btn-success'
			        },
			        cancel: {
			            label: 'No',
			            className: 'btn-danger'
			        }
			    },
			    callback: function (result) {
			        if (result){
			        	self.deleteEntity(element);
			        }
			    }
			});
			
			
		};
		
		
	}
	
	var viewModel = new ViewModel();
	
	viewModel.init();
	
    ko.applyBindings(viewModel, $('.Franchisees')[0]);
    
    window.viewModel = viewModel;
	
	
});