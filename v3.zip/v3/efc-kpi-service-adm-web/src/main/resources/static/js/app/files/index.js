$(document).ready(function($){
	
	function FileViewModel(){
		var self = this;
		
		self.id = ko.observable();
		self.createdAt = ko.observable();
		self.fileName = ko.observable();
		self.kpi = ko.observable();
		self.active = ko.observable();
		self.createdBy = ko.observable();
		self.structure = ko.observable();
	}
	
	function Pagination () {
		
		var self = this;
		
		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);
		
		self.hasNext = ko.pureComputed(function() {
		    return self.number() < self.totalPages();
		}, self);
		
		self.hasPrevious = ko.pureComputed(function() {
		    return self.number() > 1;
		}, self);
		
	
	}
	
	function StructureViewModel () {
		
		var self = this;

		self.id = ko.observable();
		self.kpiCurrentVersion = ko.observable();
		
	
	}
	
	self.searchFilter = function() {
		
		self.getAll(0);
	};
	
	function FilesViewModel(){
		var self = this;
		
		self.url = '/api/files';
		self.pagination = ko.observable(new Pagination());
		self.list = ko.observableArray([]);
		
		self.size = ko.observable(10);
		self.kpi = ko.observable();
		self.filter = ko.observable('');
		self.current = ko.observable(new FileViewModel());
		
		self.isCreateVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		
		self.structuresList = ko.observableArray([]);
		
		self.showCreate = function () {
			self.current(new FileViewModel());
			self.isCreateVisible(true);
			self.isListVisible(false);
		};
		
		self.enableSave = ko.pureComputed(function() {
			return self.current().fileName() 
				&& self.current().kpi();
		}, self);
		
		self.showList = function () {
			self.isCreateVisible(false);
			self.isListVisible(true);
			
			self.current(new FileViewModel());
			
		};
		
		self.convertToFile= function (element, self) {
			
			var file = new FileViewModel(self);
			var fileNameIndex = element.filePath && element.filePath.lastIndexOf("/") +1;
			var indexPathIndex = element.indexPath && element.indexPath.lastIndexOf("/") +1;
			var indexPath = element.indexPath && element.indexPath.substring(indexPathIndex);
			
			file.structure(convertToStructure(element.structure, self));
			file.fileName(element.filePath && element.filePath.substring(fileNameIndex));
			file.id(element.id);
			file.active(file.structure().kpiCurrentVersion() === indexPath);
			file.createdBy(element.createdBy);
			file.createdAt(element.createdAt);
			
			return file;
		};
		
		function convertToStructure(element, self) {

			var structure = new StructureViewModel(self);
			structure.id(element && element.id);
			structure.kpiCurrentVersion(element && element.kpiCurrentVersion);
			
			return structure;
			
		}
		
		self.activateFile = function(vm) {
			var url = '/api/structures/' + vm.structure().id() + '/' + vm.id();
			
			$.ajax({
				url: url,
	            type: 'PUT',
	            success: function (result) {
	            	self.getAll(0);
	            }
	          });  
			
		};
		
		self.getStructures = function (){
			
			let url = '/api/structures/all';
			
			 $.ajax({
	            url: url,
	            type: 'GET',
	            success: function (data) {	
	            	self.structuresList(data);
	            }
		     });  
			
			
			
		};
		
		
		 
	    self.getAll = function (page) {	

	    	var requestUrl =  self.url + `?page=${page}&size=${self.size()}`;
	    	requestUrl = self.filter() ?  requestUrl + '&filter='+ self.filter() : requestUrl;
	    	requestUrl = self.kpi() ?  requestUrl + '&kpi='+ self.kpi() : requestUrl;
	    	
	        $.ajax({
	            url: requestUrl,
	            type: 'GET',
	            success: function (data) {	
            	let page = new Pagination();
			    page.size(data.size);
			    page.number(data.number + 1);
			    page.numberOfElements(data.numberOfElements);
			    page.totalPages(data.totalPages);
			    page.totalElements(data.totalElements);
			    page.first(data.first);
			    page.last(data.last);
			    self.pagination(page);
			    
            	var list = [];
            	data.content.map(function (item) {
            		
            		var structure = self.convertToFile(item, self);
            	    list.push(structure);
            	})
    	    	 
          
            	self.list(list);
	            }
	          });  
	    	
	    };
	    
	    self.updateList = function(){
			self.getAll(self.pagination().number()-1)
		};

		self.searchFilter = function() {
			
			self.getAll(0);
		};
		
		self.next = function () {
			
			if (self.pagination().last()){
				return;
			}
			
			if (self.pagination().number() < self.pagination().totalPages()){
				self.getAll(self.pagination().number());
			}
			
		};
		
		
				
		self.previous = function () {
			
			if (self.pagination().first()){
				return;
			}
			
			self.getAll(self.pagination().number()-2);
			
		};

		self.init = function () {
				
			self.getAll(0);
			self.getStructures();
			
		};
		
		self.sendFile = function(file, kpi){
			
    	    
    	 	var fd = new FormData();    
    	    fd.append('file', file);
    	    fd.append('kpi', kpi);
    	    fd.append('user', currentUser);
    	    
    	    var serviceUrl = kpiServiceUrl + 'upload/';
    	    
    	    $.ajax({
    	      url: serviceUrl ,
    	      data: fd,
    	      processData: false,
    	      contentType: false,
    	      type: 'POST',
    	      success: function (result) {
    	    	  self.getAll(0);
                  self.showList();
    	      },
    	      error:function(err){
    	    	  self.getAll(0);
                  self.showList();
    	      } 
    	    });
		}
		
	}
	
	var viewModel = new FilesViewModel();
	viewModel.init();
    ko.applyBindings(viewModel, $('.Files')[0]);
    window.viewModel = viewModel;
	
	
});