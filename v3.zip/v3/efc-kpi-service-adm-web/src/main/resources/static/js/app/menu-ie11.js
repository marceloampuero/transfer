'use strict';

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	function MenuViewModel() {
		var self = this;

		var bmOff = 'position: fixed; z-index: 20000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 0; transform: translate3d(100%, 0px, 0px); transition: opacity 0.3s, transform 0s 0.3s;';
		var bmOn = 'position: fixed; z-index: 20000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 1; transition: opacity 0.3s;';

		var mnOff = 'position: fixed; right: 0px; z-index: 20000; width: 260px; height: 100%; transition: all 0.5s; top: 51px; transform: translate3d(100%, 0px, 0px);';
		var mnOn = 'position: fixed; right: 0px; z-index: 20000; width: 260px; height: 100%; transition: all 0.5s; top: 51px;';

		self.overlayStyle = ko.observable(bmOff);
		self.menuWrapStyle = ko.observable(mnOff);

		self.currentUser = ko.observable();
		self.nombre = ko.observable();
		self.apellido = ko.observable();

		self.getHeaders = function () {

			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-Requested-With': 'XMLHttpRequest',
				'X-CSRF-Token': document.getElementsByName("_csrf")[0].value
			};
		};

		self.toggleMenu = function () {

			if (self.overlayStyle() === bmOff) {
				self.overlayStyle(bmOn);
				self.menuWrapStyle(mnOn);
			} else {
				self.overlayStyle(bmOff);
				self.menuWrapStyle(mnOff);
			}
		};

		self.init = function () {
			self.getUser();
		};

		self.getUser = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
			var req, result, model;
			return regeneratorRuntime.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							req = {
								method: 'GET',
								headers: self.getHeaders(),
								cache: 'default',
								credentials: 'same-origin'
							};
							_context.prev = 1;
							_context.next = 4;
							return fetch(baseUrl + '/api/users/current', req);

						case 4:
							result = _context.sent;
							_context.next = 7;
							return result.json();

						case 7:
							model = _context.sent;

							if (!model.error) {
								_context.next = 11;
								break;
							}

							console.error('Ocurrió un error al obtener informacion del usuario:', error);

							return _context.abrupt('return');

						case 11:

							self.nombre(model.nombre);
							self.apellido(model.paterno);

							//self.currentUser(model);


							_context.next = 18;
							break;

						case 15:
							_context.prev = 15;
							_context.t0 = _context['catch'](1);

							console.error('Error en request:', _context.t0);

						case 18:
						case 'end':
							return _context.stop();
					}
				}
			}, _callee, this, [[1, 15]]);
		}));
	}

	var menuViewModel = new MenuViewModel();
	menuViewModel.init();
	window.mnuViewModel = menuViewModel;

	ko.applyBindings(menuViewModel, $('#sideMenu')[0]);
});