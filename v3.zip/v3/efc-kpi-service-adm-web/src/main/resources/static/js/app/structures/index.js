$(document).ready(function($){
	
	function Structure(){
		var self = this;
		
		self.id = ko.observable();
		self.kpi = ko.observable();
		self.description = ko.observable();
		self.header = ko.observable();
		self.active = ko.observable();
	}
	
	function Pagination () {
		
		var self = this;
		
		self.totalPages = ko.observable(0);
		self.totalElements = ko.observable(0);
		self.last = ko.observable(false);
		self.first = ko.observable(true);
		self.size = ko.observable(0);
		self.number = ko.observable(1);
		self.numberOfElements = ko.observable(0);
		
		self.hasNext = ko.pureComputed(function() {
		    return self.number() < self.totalPages();
		}, self);
		
		self.hasPrevious = ko.pureComputed(function() {
		    return self.number() > 1;
		}, self);
		
	
	}
	
	function ViewModel(){
		var self = this;
		
		self.url = '/api/structures';
		self.pagination = ko.observable(new Pagination());
		self.list = ko.observableArray([]);
		
		self.size = ko.observable(10);
		self.filter = ko.observable('');
		self.current = ko.observable(new Structure());
		
		self.isCreateVisible = ko.observable(false);
		self.isEditVisible = ko.observable(false);
		self.isListVisible = ko.observable(true);
		
		self.showCreate = function () {
			self.current(new Structure());
			self.isCreateVisible(true);
			self.isEditVisible(false);
			self.isListVisible(false);
		};
		
		self.showEdit = function (item) {
			
			self.current(item);
			self.isCreateVisible(false);
			self.isEditVisible(true);
			self.isListVisible(false);		
		};
		
		self.enableSave = ko.pureComputed(function() {
			return self.current().kpi() 
				&& self.current().description()
				&& self.current().header();
		}, self);
		
		self.showList = function () {
			self.isCreateVisible(false);
			self.isEditVisible(false);
			self.isListVisible(true);
			
			self.current(new Structure());
			
		};
		
		self.convertToStructure = function (element, self) {
			
			var structure = new Structure(self);

			structure.kpi(element.kpi);
			structure.id(element.id);
			structure.description(element.description);
			structure.active(element.active);
			structure.header(element.header);
			
			return structure;
		};
		
		self.save = function(vm){
			
			var type = 'POST';
			var url = self.url;
			
			if (vm.id()) {
				 url = self.url + "/" + vm.id();
				 type = 'PUT';
			}
			
			var body = ko.toJSON(self.current);
			
	        $.ajax({
	            url: url,
	            contentType: "application/json",
	            data: body,
	            type: type,
	            success: function (result) {	
	            window.location.href = "/structures";
	            }
	          }); 	
				
		}
		
		self.remove = function(vm){
			
	        $.ajax({
	            url: self.url + "/" + vm.id(),
	            contentType: "application/json",
	            type: 'DELETE',
	            success: function (result) {	
	            self.getAll(0);
	            }
	          }); 	
				
		}
		 
	    self.getAll = function (page) {	
	    	
	    	var requestUrl =  self.url + `?page=${page}&size=${self.size()}&filter=${self.filter()}`;
	        $.ajax({
	            url: requestUrl,
	            type: 'GET',
	            success: function (data) {	
	            	   
			    let page = new Pagination();
			    page.size(data.size);
			    page.number(data.number + 1);
			    page.numberOfElements(data.numberOfElements);
			    page.totalPages(data.totalPages);
			    page.totalElements(data.totalElements);
			    page.first(data.first);
			    page.last(data.last);
			    self.pagination(page);
            	var list = [];
            	
            	data.content.map(function (item) {
            		var structure = self.convertToStructure(item, self);
            	    list.push(structure);
            	})
    	    	 	    	
            	self.list(list);
	            }
	          });  
	    	
	    }; 
	    
		self.updateList = function(){
			self.getAll(self.pagination().number()-1)
		};

		self.searchFilter = function() {
			
			self.getAll(0);
		};
		
		self.next = function () {
			
			if (self.pagination().last()){
				return;
			}
			
			if (self.pagination().number() < self.pagination().totalPages()){
				self.getAll(self.pagination().number());
			}
			
		};
		
		
				
		self.previous = function () {
			
			if (self.pagination().first()){
				return;
			}
			
			self.getAll(self.pagination().number()-2);
			
		};

		self.init = function () {
				
			self.getAll(0);
			
		};
		
	}
	
	var viewModel = new ViewModel();
	viewModel.init();
    ko.applyBindings(viewModel, $('.Structures')[0]);
    window.viewModel = viewModel;
	
	
});