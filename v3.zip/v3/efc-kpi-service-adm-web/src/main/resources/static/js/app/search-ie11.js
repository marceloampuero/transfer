"use strict";

$(document).ready(function ($) {

	window.baseUrl = location.href.substring(0, location.href.search('gmac-web-ic') + 11);

	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-bottom-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	ko.bindingHandlers.executeOnEnter = {
		init: function init(element, valueAccessor, allBindings, viewModel) {

			var bindings = allBindings();
			$(element).keypress(function (event) {
				var keyCode = event.which ? event.which : event.keyCode;
				if (keyCode === 13) {
					bindings.executeOnEnter.call(viewModel, viewModel, element);
					return false;
				}
				return true;
			});
		},
		update: function update() {}
	};

	ko.extenders.formatted = function (target, precision) {
		//create a writable computed observable to intercept writes to our observable
		var result = ko.pureComputed({
			read: function read() {

				if (!(target && target())) {
					return '';
				}

				var newValue = target().toString();
				var val = parseInt(newValue.replace(/\./g, '').replace(/,/g, ''));

				if (isNaN(val)) {
					val = '';
				}

				var numberFormat = new Intl.NumberFormat();

				var nf = numberFormat.format(val);

				return nf;
			}, //always return the original observables value
			write: target
		}).extend({ notify: 'always' });

		//initialize with current value to make sure it is rounded appropriately
		result(target());

		//return the new computed observable
		return result;
	};

	function getDV(T) {

		var m = 0;
		var s = 1;
		T = parseInt(T, 10);
		for (; T; T = Math.floor(T / 10)) {
			s = (s + T % 10 * (9 - m++ % 6)) % 11;
		}

		return s ? s - 1 : 'K';
	}

	function validateRut(rut) {

		var checkRx;
		var splitted;
		var digits;
		var dv;
		var calculatedDv;

		if (!rut) {
			return false;
		}

		checkRx = /^\d{1,9}-{0,1}[0-9Kk]/;

		if (!checkRx.test(rut.trim())) {
			return false;
		}

		rut = rut.replace('.', '');

		splitted = rut.split('-');

		if (!splitted[1]) {
			return false;
		}

		digits = splitted[0];
		dv = splitted[1].toUpperCase();
		calculatedDv = getDV(digits).toString();

		return dv === calculatedDv;
	}

	function validateEmail(email) {
		var re = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
		return re.test(email);
	}

	function validateTelephone(telephone) {
		return telephone && telephone.length;
	}

	// function Entity(){
	// var self = this;
	//		
	// self.id = ko.observable();
	// self.address = ko.observable();
	// self.date = ko.observable();
	// self.reason = ko.observable();
	// self.createdBy = ko.observable();
	//		
	//	
	//
	// }
	//	


	function ViewModel() {
		var self = this;

		self.rut = ko.observable();
		self.periodo = ko.observable();
		self.usuario = ko.observable();
		self.idSucursal = ko.observable();
		self.idConcesionario = ko.observable();

		self.validRut = ko.pureComputed(function () {

			return validateRut(self.rut());
		}, self);

		self.search = function () {

			var paramList = [];

			if (self.rut()) {
				paramList.push('rut=' + self.rut());
			}

			if (self.periodo()) {
				paramList.push('periodo=' + self.periodo());
			}

			if (self.usuario()) {
				paramList.push('usuario=' + self.usuario());
			}

			if (self.idSucursal()) {
				paramList.push('sucursal=' + self.idSucursal());
			}

			if (self.idConcesionario()) {
				paramList.push('concesionario=' + self.idConcesionario());
			}

			var params = '?' + paramList.join('&');

			window.location = baseUrl + '/searchresult' + params;
		};
	}

	var viewModel = new ViewModel();

	ko.applyBindings(viewModel, $('.PreevaluationResult')[0]);

	window.viewModel = viewModel;
});