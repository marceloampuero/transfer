package cl.equifax.kpiservices.efcsoap.entities;

import java.util.List;

public class Kpi {

	private List<KpiAttribute> attributes;

	public List<KpiAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<KpiAttribute> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		return "Kpi [attributes=" + attributes + "]";
	}

}
