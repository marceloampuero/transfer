package cl.equifax.kpiservices.efcsoap.entities;

public enum UPLOADSTATUS {
	OK, ERROR
}
