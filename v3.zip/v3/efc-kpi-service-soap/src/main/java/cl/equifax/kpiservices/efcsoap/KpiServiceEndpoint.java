package cl.equifax.kpiservices.efcsoap;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.equifax.cl.schema.kpiservice.kpiservicerequest.KpiServiceRequest;
import com.equifax.cl.schema.kpiservice.kpiserviceresponse.Attributes;
import com.equifax.cl.schema.kpiservice.kpiserviceresponse.KpiServiceResponse;
import com.equifax.cl.schema.kpiservice.kpiserviceresponse.ObjectFactory;

import cl.equifax.kpiservices.efcsoap.entities.KpiAttribute;
import cl.equifax.kpiservices.efcsoap.entities.KpiRequest;
import cl.equifax.kpiservices.efcsoap.entities.KpiResponse;
import cl.equifax.kpiservices.efcsoap.entities.KpiServicesRequest;
import cl.equifax.kpiservices.efcsoap.services.KpiService;

@Endpoint
public class KpiServiceEndpoint {

	private static final String NAMESPACE_URI = "http://cl.equifax.com/schema/KpiService/KpiServiceRequest";

	private KpiService service;

	@Autowired
	public KpiServiceEndpoint(KpiService service) {
		this.service = service;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "KpiServiceRequest")
	@ResponsePayload
	KpiServiceResponse getValidationResponse(@RequestPayload KpiServiceRequest request) {

		KpiRequest requestKpi = new KpiRequest();

		KpiServicesRequest kpiServicesRequest = new KpiServicesRequest();
		kpiServicesRequest.setDocumentNumber(request.getDocumentNumber());

		List<KpiAttribute> attributes = new ArrayList<>();

		KpiAttribute kpiAttribute = new KpiAttribute();

		kpiAttribute.setVariableName(request.getVariableName());
		attributes.add(kpiAttribute);

		kpiServicesRequest.setAttributes(attributes);

		requestKpi.setKpiServices(kpiServicesRequest);

		KpiResponse response = this.service.getKpiByRut(requestKpi);

		ObjectFactory factory = new ObjectFactory();

		KpiServiceResponse result = factory.createKpiServiceResponse();

		for (KpiAttribute attrib : response.getKpi().getAttributes()) {

			Attributes a = factory.createAttributes();

			a.setValue(attrib.getValue());
			a.setVariableName(attrib.getVariableName());

			result.getAttributes().add(a);
		}

		return result;
	}

}
