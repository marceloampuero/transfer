package cl.equifax.kpiservices.efcsoap.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

import cl.equifax.kpiservices.efcsoap.entities.KpiRequest;
import cl.equifax.kpiservices.efcsoap.entities.KpiResponse;

@Service
public class KpiServiceImpl implements KpiService {

	private static final String SERVICE_NAME = "AGY-KPI-SERVICE";
	private static final String ENDPOINT = "kpis/v1/kpis/";

	@Autowired
	private EurekaClient discoveryClient;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public KpiResponse getKpiByRut(KpiRequest request) {
		InstanceInfo instance = discoveryClient.getNextServerFromEureka(SERVICE_NAME, false);
		String kpiServiceUrl = instance.getHomePageUrl() + ENDPOINT;

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<KpiRequest> entity = new HttpEntity<>(request, headers);

		ResponseEntity<KpiResponse> result = restTemplate.exchange(kpiServiceUrl, HttpMethod.POST, entity,
				KpiResponse.class);

		KpiResponse response = result.getBody();

		return response;
	}

}
