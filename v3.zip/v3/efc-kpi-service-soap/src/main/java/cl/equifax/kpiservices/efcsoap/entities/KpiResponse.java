package cl.equifax.kpiservices.efcsoap.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KpiResponse {

	@JsonProperty("KPI")
	private Kpi kpi;

	public Kpi getKpi() {
		return kpi;
	}

	public void setKpi(Kpi kpi) {
		this.kpi = kpi;
	}

	@Override
	public String toString() {
		return "KpiRequest []";
	}

}
