package cl.equifax.kpiservices.efcsoap.services;

import cl.equifax.kpiservices.efcsoap.entities.KpiRequest;
import cl.equifax.kpiservices.efcsoap.entities.KpiResponse;

public interface KpiService {

	KpiResponse getKpiByRut(KpiRequest request);

}
