package cl.equifax.kpiservices.efcsoap.entities;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class KpiAttribute {

	private String variableName;
	private String value;

	public KpiAttribute() {

	}

	public KpiAttribute(String variableName, String value) {

		this.variableName = variableName;
		this.value = value;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "KpiAttribute [variableName=" + variableName + ", value=" + value + "]";
	}

}
