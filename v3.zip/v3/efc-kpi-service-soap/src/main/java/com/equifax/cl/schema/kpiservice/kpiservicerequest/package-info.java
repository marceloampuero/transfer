//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2018.07.05 a las 09:58:45 PM CLT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://cl.equifax.com/schema/KpiService/KpiServiceRequest", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.equifax.cl.schema.kpiservice.kpiservicerequest;
