package cl.equifax.kpi.kpiservices;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import cl.equifax.kpi.kpiservices.util.FileProcessor;

public class LoadDataTests {

	private String getResourcesFolder() {

		File resourcesDirectory = new File("src/test/resources");

		String current = resourcesDirectory.getAbsolutePath();

		return current;

	}

	@Test
	public void addDataToKpi() {
		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");

		service.addKpi("ISE", "1-9", "ABC");
		String result = service.getValue("ISE", "1-9");
		String expected = "ABC";
		assertEquals(expected, result);

		String result2 = service.getValue("ISE2", "1-9");
		assertNull(result2);

	}

	@Test
	public void addDoubleDataToKpi() {
		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");

		service.addKpi("ISE", "1-9", "CDF");
		service.addKpi("ISE", "1-9", "ABC");

		String result = service.getValue("ISE", "1-9");
		String expected = "CDF";
		assertEquals(expected, result);

		String result2 = service.getValue("ISE2", "1-9");
		assertNull(result2);

	}

	@Test
	public void getValueNotInserted() {

		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ICE");

		service.addKpi("ICE", "1-9", "ABC");
		String result = service.getValue("DATE", "1-9");
		assertNull(result);

	}

	@Test(expected = IndexFolderDoNotExistsException.class)
	public void testFolderNotFoundException() {

		String folderPath = this.getResourcesFolder() + "/lucene234";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ICE");
		service.addKpi("ICE", "1-9", "ABC");
		String result = service.getValue("DATE", "1-9");
		assertNull(result);

	}

	@Test(expected = InvalidPathException.class)
	public void testInvalidPathWithDoubleDotsException() {

		String folderPath = this.getResourcesFolder() + "/../lucene234";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ICE");
		service.addKpi("ICE", "1-9", "ABC");
		String result = service.getValue("DATE", "1-9");
		assertNull(result);

	}

	@Test
	public void indexFolderCreated() {

		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createIndex("ISE");

		File f = new File(folderPath, "ISE");
		assertTrue(f.exists() && f.isDirectory());

	}

	@Test
	public void createAndReplaceFolderCreated() {

		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");
		File f = new File(folderPath, "ISE");
		assertTrue(f.exists() && f.isDirectory());

	}

	@Test
	public void allSingleKPISReturned() {

		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ICE");

		service.addKpi("ICE", "1-9", "ABC");

		List<String> kpis = Arrays.asList("ICE");

		Map<String, String> userKpis = service.getKpis("1-9", kpis);

		assertEquals("ABC", userKpis.get("ICE"));
		assertNull(userKpis.get("CSI"));

	}

	@Test
	public void allListKPISReturned() {

		String folderPath = this.getResourcesFolder() + "/lucene";
		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ICE");
		service.createReplaceIndex("CSI");

		service.addKpi("ICE", "1-9", "ABC");
		service.addKpi("CSI", "1-9", "222");

		List<String> kpis = Arrays.asList("ICE", "CSI");

		Map<String, String> userKpis = service.getKpis("1-9", kpis);

		assertEquals("ABC", userKpis.get("ICE"));
		assertEquals("222", userKpis.get("CSI"));

	}

	@Test
	public void fileUploaded() {

		String folderPath = this.getResourcesFolder() + "/lucene";

		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");
		service.loadKpis("ISE", this.getResourcesFolder() + "/ISE-20180516v1.csv");

		assertEquals("ABCD", service.getValue("ISE", "1-9"));
		assertEquals("CFGH", service.getValue("ISE", "7-7"));
		assertEquals("", service.getValue("ISE", "8-8"));
		assertEquals("", service.getValue("ISE", "9-9"));
		assertEquals("RTYYU", service.getValue("ISE", "10-1"));

	}

	@Test
	public void headerIsEquals() {

		String folderPath = this.getResourcesFolder() + "/lucene";

		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");
		service.loadKpis("ISE", this.getResourcesFolder() + "/ISE-20180516v1.csv", "RUT;ISE");

		assertEquals("ABCD", service.getValue("ISE", "1-9"));
		assertEquals("CFGH", service.getValue("ISE", "7-7"));
		assertEquals("", service.getValue("ISE", "8-8"));
		assertEquals("", service.getValue("ISE", "9-9"));
		assertEquals("RTYYU", service.getValue("ISE", "10-1"));

	}

	@Test(expected = WrongHeaderException.class)
	public void headerIsNotEquals() {

		String folderPath = this.getResourcesFolder() + "/lucene";

		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE");
		service.loadKpis("ISE", this.getResourcesFolder() + "/ISE-20180516v1.csv", "RUT;PKR");

	}

	@Test
	public void testBigFile() {

		String folderPath = this.getResourcesFolder() + "/lucene";

		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("SEG");
		service.loadKpis("SEG", this.getResourcesFolder() + "/SEG-BIGFILE.csv", "RUT;SEG");

		assertEquals("35", service.getValue("SEG", "9"));

	}

	@Test
	public void testTooMuchBigFile() {

		String folderPath = this.getResourcesFolder() + "/luceneBig";

		KpiService service = new KpiServiceImpl(folderPath);
		service.createReplaceIndex("ISE_EQUIFAX");
		service.loadKpis("ISE_EQUIFAX", this.getResourcesFolder() + "/RUT_ISE_18M.csv", "RUT;ISE_EQUIFAX");

		assertEquals("E", service.getValue("ISE_EQUIFAX", "4340"));

	}

	@Test
	public void testTooBigFile() {

		// replace with a really big file. And please do not commit that file to git.
		String filePath = this.getResourcesFolder() + "/RUT_ISE_18M.csv";

		int lineCount = FileProcessor.process(filePath);

		// assertEquals(18252565, lineCount);
		assertEquals(12, lineCount);

	}

}
