package cl.equifax.kpi.kpiservices;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import cl.equifax.kpi.kpiservices.validators.RutValidator;

public class RutValidatorTests {

	@Test
	public void validRut() {
		boolean result = RutValidator.validate("0000000019");

		assertTrue(result);
	}

	@Test
	public void rutTooLarge() {
		boolean result = RutValidator.validate("00000000019");

		assertFalse(result);
	}

	@Test
	public void rutTooShort() {
		boolean result = RutValidator.validate("0019");

		assertFalse(result);
	}

	@Test
	public void invalidRutWithLetter() {
		boolean result = RutValidator.validate("000000001a");

		assertFalse(result);
	}

	@Test
	public void invalidRutWithDopubleK() {
		boolean result = RutValidator.validate("00000000KK");

		assertFalse(result);
	}

	@Test
	public void validRutWithK() {
		boolean result = RutValidator.validate("000000001K");

		assertTrue(result);
	}

	@Test
	public void validRutWithKlowercase() {
		boolean result = RutValidator.validate("000000001k");

		assertTrue(result);
	}

}
