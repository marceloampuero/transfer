package cl.equifax.kpi.kpiservices;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import cl.equifax.kpi.kpiservices.formatters.Rutformatter;

public class RutFormatTests {

	@Test
	public void format10Chars() {
		String result = Rutformatter.format("1-9");
		String expected = "0000000019";

		assertEquals(expected, result);

	}

	@Test
	public void formatWithoutSeparator() {
		String result = Rutformatter.format("019");
		String expected = "0000000019";

		assertEquals(expected, result);

	}

	@Test
	public void correctFormatSeparator() {
		String result = Rutformatter.format("0000000019");
		String expected = "0000000019";

		assertEquals(expected, result);

	}

}
