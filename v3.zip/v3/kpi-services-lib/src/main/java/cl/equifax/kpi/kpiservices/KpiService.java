package cl.equifax.kpi.kpiservices;

import java.util.List;
import java.util.Map;

public interface KpiService {

	String getIndexesFolder();

	void addKpi(String kpi, String rut, String value);

	String getValue(String kpi, String rut);

	void createIndex(String kpi);

	String createReplaceIndex(String kpi);

	Map<String, String> getAllKpis(String rut);

	Map<String, String> getKpis(String rut, List<String> kpis);

	void loadKpis(String kpi, String path);

	void loadKpis(String kpi, String path, String header);

}
