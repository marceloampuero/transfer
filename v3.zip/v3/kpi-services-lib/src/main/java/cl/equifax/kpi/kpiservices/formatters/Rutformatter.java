package cl.equifax.kpi.kpiservices.formatters;

public class Rutformatter {

	private static int RUTLENGHT = 10;

	public static String format(String rut) {
		String withoutSeparator = rut.replace("-", "");

		return addLeadingZeroes(withoutSeparator, RUTLENGHT);

	}

	private static String addLeadingZeroes(String rut, int lenght) {

		String result = rut;
		if (rut.length() < 10) {
			result = String.format("%0" + (lenght - rut.length()) + "d%s", 0, rut);
		}

		return result;
	}

}
