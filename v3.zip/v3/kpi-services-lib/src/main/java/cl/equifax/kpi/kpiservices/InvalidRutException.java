package cl.equifax.kpi.kpiservices;

public class InvalidRutException extends RuntimeException {

	private static final long serialVersionUID = 5338665417690198095L;

	public InvalidRutException() {
		super("Invalid Rut");
	}

	public InvalidRutException(String message) {
		super(message);

	}

	public InvalidRutException(Throwable cause) {
		super(cause);

	}

	public InvalidRutException(String message, Throwable cause) {
		super(message, cause);

	}

	public InvalidRutException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
