package cl.equifax.kpi.kpiservices.validators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RutValidator {

	private static int RUTLENGHT = 10;	
	private static final String RUT_PATTERN = "[0-9]{9}[0-9kK]";

	public static boolean validate(String rut) {
			
		if (rut.length() != RUTLENGHT) {
			return false;
		}
		
		Pattern pattern = Pattern.compile(RUT_PATTERN);
		Matcher matcher = pattern.matcher(rut);
		
		if (!matcher.matches()) {
			return false;
		}

		return true;
	}

}
