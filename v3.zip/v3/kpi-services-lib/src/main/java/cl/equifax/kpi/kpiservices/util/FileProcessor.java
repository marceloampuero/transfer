package cl.equifax.kpi.kpiservices.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import cl.equifax.kpi.kpiservices.IndexFolderDoNotExistsException;

public class FileProcessor {

	private FileProcessor() {

	}

	public static int process(String path) {

		int count = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(path));) {

			String line = br.readLine();

			while (line != null) {
				count++;

				line = br.readLine();
			}

		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Error processing", e);
		}

		return count;
	}
}
