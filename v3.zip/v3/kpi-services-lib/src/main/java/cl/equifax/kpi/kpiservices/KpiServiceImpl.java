package cl.equifax.kpi.kpiservices;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import cl.equifax.kpi.kpiservices.formatters.Rutformatter;
import cl.equifax.kpi.kpiservices.validators.RutValidator;

public class KpiServiceImpl implements KpiService {

	private String indexesFolder;

	private StandardAnalyzer analyzer;

	private IndexWriter writer;

	public KpiServiceImpl(String indexesFolder) {

		if (!isValidPath(indexesFolder)) {
			throw new InvalidPathException();
		}

		this.indexesFolder = indexesFolder;
		this.analyzer = new StandardAnalyzer();
	}

	private boolean isValidPath(String path) {

		if (path.indexOf("..") != -1) {
			return false;
		}

		try {
			Paths.get(path);
		} catch (InvalidPathException | NullPointerException ex) {
			return false;
		}

		return true;

	}

	private String transformValidate(String rut) {
		String newRut = Rutformatter.format(rut);

		if (!RutValidator.validate(newRut)) {
			throw new InvalidRutException("Rut invalido");
		}
		return newRut;
	}

	@Override
	public void addKpi(String kpi, String rut, String value) {
		this.writer = getWriter(kpi);

		String newRut = transformValidate(rut);

		addDocument(writer, this.addDocument(newRut, kpi, value));

		this.closeWriter(writer);

	}

	private void addSimpleKpi(String kpi, String rut, String value) {

		String newRut = transformValidate(rut);

		addDocument(writer, this.addDocument(newRut, kpi, value));

	}

	private Document addDocument(String rut, String kpi, String value) {

		Document doc = new Document();

		doc.add(new TextField("rut", rut, Field.Store.YES));
		doc.add(new TextField("kpi", kpi, Field.Store.YES));
		doc.add(new StringField("value", value, Field.Store.YES));

		return doc;
	}

	private void addDocument(IndexWriter writer, Document doc) {
		try {
			writer.addDocument(doc);
		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Cannot add document to index", e);
		}
	}

	private void closeWriter(IndexWriter writer) {
		try {
			writer.close();
		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Writer is not closed", e);
		}
	}

	private IndexWriter getWriter(String kpi) {

		File f = new File(indexesFolder, kpi);

		if (!f.exists() || !f.isDirectory()) {
			throw new IndexFolderDoNotExistsException();
		}

		try {

			// Don't use try-with-resources cause we need to keep directory open
			Directory dir = FSDirectory.open(Paths.get(indexesFolder, kpi));
			Analyzer newAnalyzer = new StandardAnalyzer();
			IndexWriterConfig config = new IndexWriterConfig(newAnalyzer);

			config.setOpenMode(OpenMode.CREATE_OR_APPEND);

			return new IndexWriter(dir, config);

		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Error creating lucene index", e);
		}

	}

	private IndexReader getReader(String folder) {
		if (!this.isValidPath(folder)) {
			throw new IndexFolderDoNotExistsException();
		}

		try {
			return DirectoryReader.open(FSDirectory.open(Paths.get(indexesFolder, folder)));
		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException(e);
		}
	}

	private Query getQuery(String field, String value) {

		try {
			return new QueryParser(field, this.analyzer).parse(value);
		} catch (ParseException e1) {
			throw new QueryException("Query Error", e1);
		}

	}

	private BooleanQuery getBooleanQuery(Query q, Query q2) {
		BooleanQuery.Builder bqb = new BooleanQuery.Builder();
		return bqb.add(q, BooleanClause.Occur.MUST).add(q2, BooleanClause.Occur.MUST).build();

	}

	@Override
	public String getValue(String kpi, String rut) {

		String newRut = transformValidate(rut);

		// indexesFolder and its security is checked in the constructor
		// Please ignore security warning
		File f = new File(indexesFolder, kpi);
		if (!f.exists() || !f.isDirectory()) {
			return null;
		}

		IndexReader reader = getReader(kpi);

		try {

			IndexSearcher searcher = new IndexSearcher(reader);

			Query q = this.getQuery("rut", newRut);

			Query q2 = this.getQuery("kpi", kpi);

			BooleanQuery finalQuery = getBooleanQuery(q, q2);

			int hitsPerPage = 10;
			TopDocs docs = searcher.search(finalQuery, hitsPerPage);
			ScoreDoc[] hits = docs.scoreDocs;

			if (hits.length > 0) {
				int docId = hits[0].doc;
				Document d = searcher.doc(docId);
				return d.get("value");
			} else
				return null;

		} catch (IOException e2) {
			throw new IndexFolderDoNotExistsException(e2);
		}

	}

	@Override
	public void createIndex(String kpi) {

		File baseFolder = new File(this.indexesFolder);

		if (!baseFolder.exists() || !baseFolder.isDirectory()) {
			throw new IndexFolderDoNotExistsException("Base indexes folder do not exists");
		}

		if (kpi.indexOf('/') != -1) {
			throw new IndexFolderDoNotExistsException("Invalid index name");
		}

		File indexFolder = new File(indexesFolder, kpi);

		if (!indexFolder.exists()) {
			indexFolder.mkdirs();
		}

	}

	private void deleteFolder(File file) {

		try {
			Files.walk(file.toPath()).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
		} catch (IOException e) {
			// ignore exception
		}

	}

	@Override
	public String createReplaceIndex(String kpi) {

		File baseFolder = new File(this.indexesFolder);

		if (!baseFolder.exists() || !baseFolder.isDirectory()) {
			throw new IndexFolderDoNotExistsException("Base indexes folder do not exists");
		}

		if (kpi.indexOf('/') != -1) {
			throw new IndexFolderDoNotExistsException("Invalid index name");
		}

		File indexFolder = new File(indexesFolder, kpi);

		if (indexFolder.exists()) {
			deleteFolder(indexFolder);
		}

		indexFolder.mkdirs();

		return indexFolder.getAbsolutePath();

	}

	@Override
	public String getIndexesFolder() {

		return null;
	}

	private List<String> findFoldersInDirectory(String directoryPath) {

		if (!this.isValidPath(directoryPath)) {
			throw new InvalidPathException();
		}

		File directory = new File(directoryPath);
		FileFilter directoryFileFilter = File::isDirectory;

		File[] directoryListAsFile = directory.listFiles(directoryFileFilter);

		List<String> foldersInDirectory = new ArrayList<>(directoryListAsFile.length);
		for (File directoryAsFile : directoryListAsFile) {
			foldersInDirectory.add(directoryAsFile.getName());
		}

		return foldersInDirectory;
	}

	@Override
	public Map<String, String> getAllKpis(String rut) {

		Map<String, String> userKpis = new HashMap<>();
		List<String> directories = findFoldersInDirectory(indexesFolder);

		for (String temp : directories) {

			userKpis.put(temp, getValue(temp, rut));
		}

		return userKpis;
	}

	@Override
	public Map<String, String> getKpis(String rut, List<String> directories) {

		Map<String, String> userKpis = new HashMap<>();

		for (String temp : directories) {

			userKpis.put(temp, getValue(temp, rut));
		}

		return userKpis;
	}

	@Override
	public void loadKpis(String kpi, String path) {

		try (BufferedReader br = new BufferedReader(new FileReader(path));) {
			String line = br.readLine();
			line = br.readLine();

			while (line != null) {
				String[] buffer = line.split(";");

				if (buffer.length == 2) {
					addKpi(kpi, buffer[0], buffer[1]);
				} else {
					addKpi(kpi, buffer[0], "");
				}

				line = br.readLine();
			}

			this.closeWriter(writer);

		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Index folder do not exists", e);
		}

	}

	@Override
	public void loadKpis(String kpi, String path, String header) {

		this.writer = getWriter(kpi);

		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String line = br.readLine();

			if (!line.equalsIgnoreCase(header)) {
				throw new WrongHeaderException();
			}

			line = br.readLine();

			while (line != null) {
				String[] buffer = line.split(";");

				if (buffer.length == 2) {
					addSimpleKpi(kpi, buffer[0].replace("\"", ""), buffer[1].replace("\"", ""));
				} else {
					addSimpleKpi(kpi, buffer[0].replace("\"", ""), "");
				}

				line = br.readLine();
			}

			this.closeWriter(this.writer);

		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException("Index folder do not exists", e);
		}

	}

}
