package cl.equifax.kpi.kpiservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KpiServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(KpiServicesApplication.class, args);
	}
}
