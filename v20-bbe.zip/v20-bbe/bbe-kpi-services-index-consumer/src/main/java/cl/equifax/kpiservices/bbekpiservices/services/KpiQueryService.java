package cl.equifax.kpiservices.bbekpiservices.services;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;

@Service
@FeignClient(name = "kpiQueryService", url = "${kpi.services.kpiurl}" + "/v1/kpis")
public interface KpiQueryService {

	@PostMapping
	KpiResponse getKpiByRut(@RequestBody KpiRequest request);

}
