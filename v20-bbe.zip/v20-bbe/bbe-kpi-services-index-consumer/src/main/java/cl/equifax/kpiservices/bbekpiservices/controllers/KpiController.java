package cl.equifax.kpiservices.bbekpiservices.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.KpiResponse;
import cl.equifax.kpiservices.bbekpiservices.services.KpiQueryService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1 + "/kpis")
public class KpiController {

	private KpiQueryService service;

	@Autowired
	public KpiController(KpiQueryService service) {
		this.service = service;
	}

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@ApiOperation(value = "Permite consultar por el o los kpis de un rut determinado")
	@PostMapping
	@ResponseBody
	public KpiResponse kpisByRut(@RequestBody KpiRequest request) {

		return this.service.getKpiByRut(request);
	}

}
