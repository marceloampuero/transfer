package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.entities.StructureRequest;
import io.swagger.annotations.ApiOperation;

@Service
@FeignClient(name = "kpiStructureService", url = "${kpi.services.kpiurl}" + "/v1/structure")

public interface StructureService {

	@GetMapping("/all")
	List<StructureRequest> findAll();

	// blah

	@GetMapping
	@ResponseBody
	PageDetail findPaginated(@RequestParam(name = "filter", required = false) String filter,
			@RequestParam(name = "page", defaultValue = "0", required = false) Integer page,
			@RequestParam(name = "size", defaultValue = "10", required = false) Integer size);

	@PostMapping
	@ResponseBody
	StructureRequest create(@RequestBody StructureRequest structure);

	@PutMapping("/{id}")
	@ResponseBody
	StructureRequest update(@PathVariable(value = "id") Integer id, @RequestBody StructureRequest structure);

	@DeleteMapping("/{id}")
	void delete(@PathVariable(value = "id") Integer id,
			@RequestParam(name = "user", required = true, defaultValue = "") String user);

	@GetMapping("/{id}")
	@ResponseBody
	Optional<StructureRequest> findById(@PathVariable(value = "id") Integer id);

	@ApiOperation(value = "Cambia el archivo de indices de una estructura")
	@PutMapping("/{id}/{fileId}")
	@ResponseBody
	StructureRequest changeFileIndex(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId,
			@RequestParam(name = "user", required = true, defaultValue = "") String user);

}
