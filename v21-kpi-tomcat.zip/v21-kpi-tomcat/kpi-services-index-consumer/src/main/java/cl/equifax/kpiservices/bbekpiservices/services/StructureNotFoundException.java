package cl.equifax.kpiservices.bbekpiservices.services;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class StructureNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 8462390506581302295L;

	private static final String MESSAGE = "Structure not found";

	public StructureNotFoundException() {
		super(MESSAGE);
	}

	public StructureNotFoundException(String message) {
		super(message);

	}

	public StructureNotFoundException(Throwable cause) {
		super(cause);

	}

	public StructureNotFoundException(String message, Throwable cause) {
		super(message, cause);

	}

	public StructureNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
