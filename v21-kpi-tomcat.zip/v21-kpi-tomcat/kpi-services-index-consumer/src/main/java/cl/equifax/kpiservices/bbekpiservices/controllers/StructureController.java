package cl.equifax.kpiservices.bbekpiservices.controllers;

import java.util.Calendar;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import cl.equifax.kpiservices.bbekpiservices.domain.EndPoint;
import cl.equifax.kpiservices.bbekpiservices.domain.StructureRequest;
import cl.equifax.kpiservices.bbekpiservices.entities.PageDetail;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.libs.Paginator;
import cl.equifax.kpiservices.bbekpiservices.services.StructureNotFoundException;
import cl.equifax.kpiservices.bbekpiservices.services.StructureService;
import cl.equifax.kpiservices.bbekpiservices.utils.XssSanitizerUtil;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(EndPoint.VERSION_1 + "/structure")
public class StructureController {

	private StructureService service;

	@Autowired
	public StructureController(StructureService service) {

		this.service = service;
	}

	@InitBinder
	public void binder(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] {});
	}

	@ApiOperation(value = "Obtiene la lista paginada filtradas por kpi de estructuras de KPIs")
	@GetMapping
	@ResponseBody
	public PageDetail home(@RequestParam(required = false) String filter,
			@RequestParam(defaultValue = "0", required = false) Integer page,
			@RequestParam(defaultValue = "10", required = false) Integer size) {

		Pageable pageable = PageRequest.of(page, size);

		if (filter != null && !filter.isEmpty()) {
			Page<Structure> result = this.service.findByKpi(filter, pageable);
			return Paginator.buildSerializablePage(result);
		}

		Page<Structure> result = this.service.findAll(pageable);
		return Paginator.buildSerializablePage(result);
	}

	@ApiOperation(value = "Obtiene la lista actualizada de estructuras de KPIs")
	@GetMapping("/all")
	@ResponseBody
	public List<Structure> getAll() {

		return this.service.findAll();
	}

	@ApiOperation(value = "Obtiene una estructura de kpi por Id ")
	@GetMapping("/{id}")
	@ResponseBody
	public Structure getById(@PathVariable(value = "id") Integer id) {

		return this.service.findById(id);
	}

	@ApiOperation(value = "Actualiza una estructura")
	@PutMapping("/{id}")
	@ResponseBody
	public ResponseEntity<Structure> update(@PathVariable(value = "id") Integer id,
			@Valid @RequestBody StructureRequest structureRequest) {

		Structure structure = structureRequest.toStructure();
		Structure savedStructure = service.findById(id);

		if (savedStructure == null) {
			throw new StructureNotFoundException();
		}

		if (!Strings.isNullOrEmpty(structure.getDescription())) {
			savedStructure.setDescription(XssSanitizerUtil.stripXSS(structure.getDescription()));
		}

		if (!Strings.isNullOrEmpty(structure.getHeader())) {
			savedStructure.setHeader(XssSanitizerUtil.stripXSS(structure.getHeader()));
		}

		if (!Strings.isNullOrEmpty(structure.getKpi())) {
			savedStructure.setKpi(XssSanitizerUtil.stripXSS(structure.getKpi()));
		}

		savedStructure.setActive(structure.isActive());
		savedStructure.setModifiedBy(XssSanitizerUtil.stripXSS(structure.getModifiedBy()));
		savedStructure.setModifiedAt(Calendar.getInstance().getTime());

		this.service.update(savedStructure);

		return new ResponseEntity<>(xssSanitization(savedStructure), HttpStatus.OK);

	}

	private Structure xssSanitization(Structure structure) {

		structure.setCreatedBy(XssSanitizerUtil.stripXSS(structure.getCreatedBy()));
		structure.setDescription(XssSanitizerUtil.stripXSS(structure.getDescription()));
		structure.setHeader(XssSanitizerUtil.stripXSS(structure.getHeader()));
		structure.setKpi(XssSanitizerUtil.stripXSS(structure.getKpi()));
		structure.setModifiedBy(XssSanitizerUtil.stripXSS(structure.getModifiedBy()));

		return structure;

	}

	@ApiOperation(value = "Cambia el archivo de índices de una estructura")
	@PutMapping("/{id}/{fileId}")
	@ResponseBody
	public Structure updateIndexFile(@PathVariable(value = "id") Integer id,
			@PathVariable(value = "fileId") Integer fileId,
			@RequestParam(name = "user", required = true, defaultValue = "") String user) {

		return this.service.changeFileIndex(id, fileId, user);

	}

	@ApiOperation(value = "Crea una estructura para un KPI")
	@PostMapping
	@ResponseBody
	public ResponseEntity<Structure> create(@Valid @RequestBody StructureRequest structureRequest) {
		Structure structure = structureRequest.toStructure();
		structure.setKpi(structure.getKpi().toUpperCase());
		Structure savedStructure = service.save(structure);

		return new ResponseEntity<>(savedStructure, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Elimina una estructura de KPI")
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void delete(@PathVariable(value = "id") Integer id,
			@RequestParam(name = "user", required = true, defaultValue = "") String user) {

		this.service.delete(id, user);

	}

}
