package cl.equifax.kpiservices.bbekpiservices.kpi;

import java.util.List;
import java.util.Map;

public interface KpiService {

	String getValue(String kpi, String rut);

	// String createReplaceIndex(String kpi);

	Map<String, String> getKpis(String rut, List<String> kpis);

	// void loadKpis(String kpi, String path, String header);

}
