package cl.equifax.kpiservices.bbekpiservices.services;

public interface LogService {

	void info(String details, String user);

	void error(String details, String user, Throwable error);

}
