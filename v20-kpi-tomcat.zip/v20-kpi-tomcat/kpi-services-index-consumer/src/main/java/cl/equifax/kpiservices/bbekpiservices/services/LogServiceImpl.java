package cl.equifax.kpiservices.bbekpiservices.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.equifax.kpiservices.bbekpiservices.entities.KpiLog;
import cl.equifax.kpiservices.bbekpiservices.repositories.KpiLogRepository;

@Service
public class LogServiceImpl implements LogService {

	KpiLogRepository repository;

	private static final String LOG_INFO = "info";
	private static final String LOG_ERROR = "error";

	@Autowired
	public LogServiceImpl(KpiLogRepository repository) {

		this.repository = repository;
	}

	@Override
	public void info(String details, String user) {
		KpiLog log = new KpiLog();
		log.setLogType(LOG_INFO);
		log.setDetails(details);
		log.setKpiUser(user);

		this.repository.save(log);

	}

	@Override
	public void error(String details, String user, Throwable error) {
		KpiLog log = new KpiLog();
		log.setLogType(LOG_ERROR);

		String allDetails = details + "\n" + error.getMessage();

		log.setDetails(allDetails);
		log.setKpiUser(user);

		this.repository.save(log);

	}

}
