package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;
import cl.equifax.kpiservices.bbekpiservices.repositories.FilesIndexRepository;
import cl.equifax.kpiservices.bbekpiservices.repositories.StructureRepository;

@Service
public class StructureServiceImpl implements StructureService {

	private StructureRepository repository;
	private FilesIndexRepository filesIndexRepository;

	private LogService logService;

	@Autowired
	public StructureServiceImpl(StructureRepository repository, FilesIndexRepository filesIndexRepository,
			LogService logService) {
		this.repository = repository;
		this.filesIndexRepository = filesIndexRepository;
		this.logService = logService;

	}

	@Override
	public List<Structure> findAll() {

		return this.repository.findAll();
	}

	@Override
	public Structure save(Structure structure) {

		Structure savedStructure = this.repository.save(structure);
		String details = String.format("Created structure %s", structure.getKpi());

		this.logService.info(details, structure.getCreatedBy());

		return savedStructure;

	}

	@Override
	public Structure update(Structure structure) {

		Structure savedStructure = this.repository.save(structure);
		String details = String.format("Updated structure %s", savedStructure.getKpi());

		this.logService.info(details, structure.getModifiedBy());

		return savedStructure;
	}

	@Override
	public void delete(Integer id, String user) {

		this.repository.deleteById(id);
		String details = String.format("Removed structure with id %s", id);
		this.logService.info(details, user);
	}

	@Override
	public Structure findById(Integer id) {

		return this.repository.findById(id).orElse(null);
	}

	@Override
	public Structure findByKpi(String kpi) {

		return this.repository.findByKpi(kpi);
	}

	private String getLastPartFromPath(String path) {

		return path.substring(path.lastIndexOf('/') + 1);

	}

	@Override
	public Structure changeFileIndex(Integer id, Integer fileId, String user) {

		Structure structure = this.findById(id);
		FilesIndex filesIndex = this.filesIndexRepository.findById(fileId).orElse(null);

		if (structure == null || filesIndex == null) {
			return null;
		}

		String fromIndex = structure.getLastIndexPath();

		structure.setLastIndexPath(filesIndex.getIndexPath());
		structure.setKpiCurrentVersion(this.getLastPartFromPath(filesIndex.getIndexPath()));

		Structure savedStructure = this.repository.save(structure);

		String details = String.format("Changed kpi index from %s to %s", fromIndex, filesIndex.getIndexPath());
		this.logService.info(details, user);

		return savedStructure;
	}

	@Override
	public Page<Structure> findAll(Pageable pageable) {

		return this.repository.findAll(pageable);
	}

	@Override
	public Page<Structure> findByKpi(String kpi, Pageable pageable) {

		return this.repository.findByKpiContainingIgnoreCase(kpi, pageable);
	}

	@Override
	public List<Structure> findActiveKpis() {

		return this.repository.findByKpiCurrentVersionNotNullAndActiveTrueAndLastIndexPathNotNull();
	}

}
