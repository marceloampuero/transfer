package cl.equifax.kpiservices.bbekpiservices.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import cl.equifax.kpiservices.bbekpiservices.entities.FilesIndex;
import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

@Repository
public interface FilesIndexRepository extends CrudRepository<FilesIndex, Integer> {
	List<FilesIndex> findAll();

	Page<FilesIndex> findAll(Pageable pageable);

	List<FilesIndex> findByStructure(Structure structure);

	Page<FilesIndex> findByStructure(Structure structure, Pageable pageable);

	Page<FilesIndex> findByStructureAndFilePathContainingIgnoreCase(Structure structure, String filePath,
			Pageable pageable);

	Page<FilesIndex> findByStructureAndFilePath(Structure structure, String filePath, Pageable pageable);

	Page<FilesIndex> findByFilePath(String filePath, Pageable pageable);

	Page<FilesIndex> findByFilePathContainingIgnoreCase(String filePath, Pageable pageable);

}
