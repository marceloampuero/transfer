package cl.equifax.kpiservices.bbekpiservices.kpi;

public class InvalidPathException extends RuntimeException {

	private static final long serialVersionUID = -568279980948622157L;

	public InvalidPathException() {
		super("Invalid or insecure path");
	}

	public InvalidPathException(String message) {
		super(message);

	}

	public InvalidPathException(Throwable cause) {
		super(cause);

	}

	public InvalidPathException(String message, Throwable cause) {
		super(message, cause);

	}

	public InvalidPathException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
