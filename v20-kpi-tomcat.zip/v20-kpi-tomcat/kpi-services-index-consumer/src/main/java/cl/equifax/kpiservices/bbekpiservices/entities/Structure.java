package cl.equifax.kpiservices.bbekpiservices.entities;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "kpistructure")
public class Structure {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "KPISTRUCTURE_SEQ")
	@SequenceGenerator(sequenceName = "kpistructure_seq", allocationSize = 1, name = "KPISTRUCTURE_SEQ")
	private Integer id;

	@NotNull
	@Size(max = 50)
	@Column(unique = true)
	private String kpi;
	private String description;

	private String kpiCurrentVersion;

	private Date createdAt = Calendar.getInstance().getTime();
	private Date modifiedAt = Calendar.getInstance().getTime();
	private String createdBy;
	private String modifiedBy;

	@NotNull
	@Size(max = 50)
	private String header;

	private boolean active = true;

	private String lastIndexPath;

	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Structure [id=" + id + ", kpi=" + kpi + ", description=" + description + ", kpiCurrentVersion="
				+ kpiCurrentVersion + ", createdAt=" + createdAt + ", modifiedAt=" + modifiedAt + ", createdBy="
				+ createdBy + ", modifiedBy=" + modifiedBy + ", header=" + header + ", active=" + active
				+ ", lastIndexPath=" + lastIndexPath + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLastIndexPath() {
		return lastIndexPath;
	}

	public void setLastIndexPath(String lastIndexPath) {
		this.lastIndexPath = lastIndexPath;
	}

	public String getKpiCurrentVersion() {
		return kpiCurrentVersion;
	}

	public void setKpiCurrentVersion(String kpiCurrentVersion) {
		this.kpiCurrentVersion = kpiCurrentVersion;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
