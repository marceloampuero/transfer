package cl.equifax.kpiservices.bbekpiservices.entities;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KpiRequest {

	@JsonProperty(required = true)
	@Valid
	private KpiServicesRequest kpiServices;

	public KpiServicesRequest getKpiServices() {
		return kpiServices;
	}

	public void setKpiServices(KpiServicesRequest kpiServices) {
		this.kpiServices = kpiServices;
	}

	@Override
	public String toString() {
		return "KpiRequest [kpiServices=" + kpiServices + "]";
	}

}
