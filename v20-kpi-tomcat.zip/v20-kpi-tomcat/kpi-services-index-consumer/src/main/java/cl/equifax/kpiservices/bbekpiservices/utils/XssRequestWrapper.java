package cl.equifax.kpiservices.bbekpiservices.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;

public class XssRequestWrapper extends HttpServletRequestWrapper {

	private byte[] body;

	public XssRequestWrapper(HttpServletRequest servletRequest) throws IOException {
		super(servletRequest);

		body = IOUtils.toByteArray(servletRequest.getInputStream());

		String json = XssSanitizerUtil.stripXSS(new String(body, "UTF-8"));

		body = json.getBytes();

	}

	@Override
	public String[] getParameterValues(String parameter) {
		String[] values = super.getParameterValues(parameter);

		if (values == null) {
			return null;
		}

		int count = values.length;
		String[] encodedValues = new String[count];
		for (int i = 0; i < count; i++) {
			encodedValues[i] = XssSanitizerUtil.stripXSS(values[i]);
		}

		return encodedValues;
	}

	@Override
	public String getParameter(String parameter) {
		String value = super.getParameter(parameter);
		if (value != null) {
			value = XssSanitizerUtil.stripXSS(value);
		}
		return value;
	}

	@Override
	public String getHeader(String name) {
		String value = super.getHeader(name);
		if (value != null) {
			value = XssSanitizerUtil.stripXSS(value);
		}
		return value;
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		return new ServletInputStream() {
			ByteArrayInputStream bais = new ByteArrayInputStream(body);

			@Override
			public int read() throws IOException {
				return bais.read();
			}

			@Override
			public boolean isFinished() {

				return false;
			}

			@Override
			public boolean isReady() {

				return false;
			}

			@Override
			public void setReadListener(ReadListener listener) {

			}
		};
	}

}
