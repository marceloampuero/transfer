package cl.equifax.kpiservices.bbekpiservices.services;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cl.equifax.kpiservices.bbekpiservices.entities.Structure;

public interface StructureService {
	List<Structure> findAll();

	List<Structure> findActiveKpis();

	Page<Structure> findAll(Pageable pageable);

	Page<Structure> findByKpi(String kpi, Pageable pageable);

	Structure findByKpi(String kpi);

	Structure save(Structure structure);

	Structure update(Structure structure);

	Structure findById(Integer id);

	void delete(Integer id, String user);

	Structure changeFileIndex(Integer id, Integer fileId, String user);

}
