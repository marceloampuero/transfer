package cl.equifax.kpiservices.bbekpiservices.kpi;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;

import cl.equifax.kpiservices.bbekpiservices.formatters.Rutformatter;
import cl.equifax.kpiservices.bbekpiservices.validators.RutValidator;

public class KpiServiceImpl implements KpiService {

	private String indexesFolder;

	private StandardAnalyzer analyzer;
	//
	// private IndexWriter writer;

	public KpiServiceImpl(String indexesFolder) {

		if (!isValidPath(indexesFolder)) {
			throw new InvalidPathException();
		}

		this.indexesFolder = indexesFolder;
		this.analyzer = new StandardAnalyzer();
	}

	private boolean isValidPath(String path) {

		if (path.indexOf("..") != -1) {
			return false;
		}

		try {
			Paths.get(path);
		} catch (InvalidPathException | NullPointerException ex) {
			return false;
		}

		return true;

	}

	private String transformValidate(String rut) {
		String newRut = Rutformatter.format(rut);

		if (!RutValidator.validate(newRut)) {
			throw new InvalidRutException("Rut invalido");
		}
		return newRut;
	}

	
	private IndexReader getReader(String folder) {
		if (!this.isValidPath(folder)) {
			throw new IndexFolderDoNotExistsException();
		}

		try {
			return DirectoryReader.open(FSDirectory.open(Paths.get(indexesFolder, folder)));
		} catch (IOException e) {
			throw new IndexFolderDoNotExistsException(e);
		}
	}

	private Query getQuery(String field, String value) {

		try {
			return new QueryParser(field, this.analyzer).parse(value);
		} catch (ParseException e1) {
			throw new QueryException("Query Error", e1);
		}

	}

	private BooleanQuery getBooleanQuery(Query q, Query q2) {
		BooleanQuery.Builder bqb = new BooleanQuery.Builder();
		return bqb.add(q, BooleanClause.Occur.MUST).add(q2, BooleanClause.Occur.MUST).build();

	}

	@Override
	public String getValue(String kpi, String rut) {

		String newRut = transformValidate(rut);

		// indexesFolder and its security is checked in the constructor
		// Please ignore security warning
		File f = new File(indexesFolder, kpi);
		if (!f.exists() || !f.isDirectory()) {
			return null;
		}

		IndexReader reader = getReader(kpi);

		try {

			IndexSearcher searcher = new IndexSearcher(reader);

			Query q = this.getQuery("rut", newRut);

			Query q2 = this.getQuery("kpi", kpi);

			BooleanQuery finalQuery = getBooleanQuery(q, q2);

			int hitsPerPage = 10;
			TopDocs docs = searcher.search(finalQuery, hitsPerPage);
			ScoreDoc[] hits = docs.scoreDocs;

			if (hits.length > 0) {
				int docId = hits[0].doc;
				Document d = searcher.doc(docId);
				return d.get("value");
			} else
				return null;

		} catch (IOException e2) {
			throw new IndexFolderDoNotExistsException(e2);
		}

	}

	// private void deleteFolder(File file) {
	//
	// try {
	// Files.walk(file.toPath()).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
	// } catch (IOException e) {
	// // ignore exception
	// }
	//
	// }

	// @Override
	// public String createReplaceIndex(String kpi) {
	//
	// File baseFolder = new File(this.indexesFolder);
	//
	// if (!baseFolder.exists() || !baseFolder.isDirectory()) {
	// throw new IndexFolderDoNotExistsException("Base indexes folder do not
	// exists");
	// }
	//
	// if (kpi.indexOf('/') != -1) {
	// throw new IndexFolderDoNotExistsException("Invalid index name");
	// }
	//
	// File indexFolder = new File(indexesFolder, kpi);
	//
	// if (indexFolder.exists()) {
	// deleteFolder(indexFolder);
	// }
	//
	// indexFolder.mkdirs();
	//
	// return indexFolder.getAbsolutePath();
	//
	// }

	@Override
	public Map<String, String> getKpis(String rut, List<String> directories) {

		Map<String, String> userKpis = new HashMap<>();

		for (String temp : directories) {

			userKpis.put(temp, getValue(temp, rut));
		}

		return userKpis;
	}

	// @Override
	// public void loadKpis(String kpi, String path, String header) {
	//
	// this.writer = getWriter(kpi);
	//
	// try (BufferedReader br = new BufferedReader(new FileReader(path))) {
	// String line = br.readLine();
	//
	// if (!line.equalsIgnoreCase(header)) {
	// throw new WrongHeaderException();
	// }
	//
	// line = br.readLine();
	//
	// while (line != null) {
	// String[] buffer = line.split(";");
	//
	// if (buffer.length == 2) {
	// addSimpleKpi(kpi, buffer[0].replace("\"", ""), buffer[1].replace("\"",
	// ""));
	// } else {
	// addSimpleKpi(kpi, buffer[0].replace("\"", ""), "");
	// }
	//
	// line = br.readLine();
	// }
	//
	// this.closeWriter(this.writer);
	//
	// } catch (IOException e) {
	// throw new IndexFolderDoNotExistsException("Index folder do not exists",
	// e);
	// }
	//
	// }

}
